import json
import os
import subprocess
import threading
import time
from ipaddress import ip_network
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from time import time_ns
from urllib.error import HTTPError, URLError
from urllib.request import urlopen


PREFIX_COUNT = int(os.environ.get("ROV_PREFIX_COUNT", "1"))
if PREFIX_COUNT not in (1, 2):
    raise ValueError("ROV_PREFIX_COUNT must be 1 or 2")
PREFIXES = ("198.18.0.0/24", "198.18.1.0/24")[:PREFIX_COUNT]
TARGETS = {
    prefix: f"http://{ip_network(prefix).network_address + 10}:8080/"
    for prefix in PREFIXES
}
events = []
events_lock = threading.Lock()
probe_threads = []
stop_event = threading.Event()
probe_config = {"interval_ms": 100, "timeout_s": 0.4}
latest_by_prefix = {}

for prefix in PREFIXES:
    subprocess.run(
        ["ip", "route", "replace", prefix, "via", "198.18.2.10"],
        check=True,
    )


def emit_probe(record):
    with events_lock:
        events.append(record)
        latest_by_prefix[record["prefix"]] = record


def probe_loop(prefix, target):
    next_probe = time.monotonic()
    while not stop_event.is_set():
        started_ns = time_ns()
        record = {
            "type": "probe",
            "prefix": prefix,
            "target": target,
            "started_ns": started_ns,
            "finished_ns": None,
            "service": None,
            "result": "timeout",
        }
        try:
            with urlopen(target, timeout=probe_config["timeout_s"]) as response:
                body = json.loads(response.read())
                record["service"] = body.get("service")
                record["result"] = (
                    "response" if response.status == 200 else "http_error"
                )
                record["status"] = response.status
        except HTTPError as exc:
            record["result"] = "http_error"
            record["status"] = exc.code
        except (TimeoutError, URLError, OSError) as exc:
            record["error"] = str(exc)
        except json.JSONDecodeError as exc:
            record["result"] = "invalid_response"
            record["error"] = str(exc)
        record["finished_ns"] = time_ns()
        emit_probe(record)
        interval = probe_config["interval_ms"] / 1000
        next_probe = max(next_probe + interval, time.monotonic() + interval)
        stop_event.wait(max(0, next_probe - time.monotonic()))


class Handler(BaseHTTPRequestHandler):
    def _respond(self, status, value):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._respond(200, {"ok": True})
        elif self.path == "/status":
            with events_lock:
                latest = events[-1] if events else None
                latest_by_prefix_snapshot = {
                    prefix: record.copy()
                    for prefix, record in latest_by_prefix.items()
                }
            self._respond(
                200,
                {
                    "running": any(thread.is_alive() for thread in probe_threads),
                    "latest": latest,
                    "latest_by_prefix": latest_by_prefix_snapshot,
                },
            )
        elif self.path == "/events":
            with events_lock:
                snapshot = list(events)
            self._respond(200, {"events": snapshot})
        else:
            self._respond(404, {"error": "not found"})

    def do_POST(self):
        global probe_threads
        size = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(size) if size else b"{}"
        request = json.loads(body)
        if self.path == "/start":
            if any(thread.is_alive() for thread in probe_threads):
                self._respond(409, {"error": "probes already running"})
                return
            probe_config["interval_ms"] = max(
                50, int(request.get("interval_ms", 100))
            )
            probe_config["timeout_s"] = float(request.get("timeout_s", 0.4))
            stop_event.clear()
            with events_lock:
                events.clear()
                latest_by_prefix.clear()
            probe_threads = [
                threading.Thread(
                    target=probe_loop,
                    args=(prefix, target),
                    name=f"http-probe-{prefix}",
                    daemon=True,
                )
                for prefix, target in TARGETS.items()
            ]
            for thread in probe_threads:
                thread.start()
            self._respond(
                200,
                {
                    "started": True,
                    **probe_config,
                    "targets": TARGETS,
                },
            )
        elif self.path == "/stop":
            stop_event.set()
            for thread in probe_threads:
                thread.join(timeout=2)
            with events_lock:
                count = len(events)
            self._respond(200, {"stopped": True, "probe_count": count})
        else:
            self._respond(404, {"error": "not found"})

    def log_message(self, _format, *_args):
        return


ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
