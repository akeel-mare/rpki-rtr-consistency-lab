$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Work = Join-Path $Root "tmp\pr24131"
$Source = Join-Path $Work "src"
$BuildRepo = Join-Path $Work "build-src"
$BaseSource = Join-Path $Work "base-src-lf"
$PatchedSource = Join-Path $Work "patched-src-lf"
$PatchFile = Join-Path $Work "pr24131.patch"
$ManifestFile = Join-Path $Work "image-manifest.json"
$Base = "ce548b0d3354bb78f58137b11ed9ce1ebab8259a"
$Patch = "c78f874369aed652fade980cf3f6c4f1b39d912b"
$BaseBuilderImage = "rov-frr-pr24131:builder-base-ce548b0d"
$PatchedBuilderImage = "rov-frr-pr24131:builder-patched-c78f8743"
$BaseImage = "rov-frr-pr24131:base-ce548b0d"
$PatchedImage = "rov-frr-pr24131:patched-c78f8743"

New-Item -ItemType Directory -Force $Work | Out-Null
$CreatedSource = $false
if (-not (Test-Path (Join-Path $Source ".git"))) {
    git clone --filter=blob:none --no-checkout https://github.com/FRRouting/frr.git $Source
    if ($LASTEXITCODE -ne 0) { throw "Could not clone FRRouting" }
    $CreatedSource = $true
}
git -C $Source fetch --depth=1 origin $Base
if ($LASTEXITCODE -ne 0) { throw "Could not fetch PR base commit" }
if ($CreatedSource) {
    git -C $Source checkout --detach $Base
    if ($LASTEXITCODE -ne 0) { throw "Could not select the pinned base in the fresh source checkout" }
}
git -C $Source fetch --depth=50 origin $Patch
if ($LASTEXITCODE -ne 0) { throw "Could not fetch PR head commit" }
git -C $Source fetch --deepen=1000 origin $Base
if ($LASTEXITCODE -ne 0) { throw "Could not fetch base ancestry" }
$MergeOutput = git -C $Source merge-base $Patch $Base
if ($LASTEXITCODE -ne 0 -or -not $MergeOutput) {
    throw "Could not determine PR branch merge base."
}
$PrMergeBase = ($MergeOutput -join "").Trim()
$BuildFilesDiffer = git -C $Source diff --quiet $Base $Patch -- docker/ubuntu-ci
if ($LASTEXITCODE -ne 0) {
    throw "PR changes the CI Docker build context; refusing a non-identical build."
}

$Head = (git -C $Source rev-parse HEAD).Trim()
if ($Head -ne $Base) {
    throw "Source checkout must be at base $Base (found $Head); use a fresh tmp\pr24131 workspace."
}
$Dirty = git -C $Source status --porcelain
if ($Dirty) { throw "Base source checkout is not clean; refusing to overwrite it." }

git -C $Source diff --binary --output=$PatchFile $PrMergeBase $Patch
if ($LASTEXITCODE -ne 0) { throw "Could not export PR #24131 patch" }
$ExpectedChanges = @(git -C $Source diff --name-only $PrMergeBase $Patch | Sort-Object)

if (-not (Test-Path (Join-Path $BuildRepo ".git"))) {
    git clone --filter=blob:none --no-checkout https://github.com/FRRouting/frr.git $BuildRepo
    if ($LASTEXITCODE -ne 0) { throw "Could not create LF build-source repository" }
    git -C $BuildRepo config core.autocrlf false
}
if ((git -C $BuildRepo config --get core.autocrlf) -ne "false") {
    throw "Build-source repository must use core.autocrlf=false."
}
git -C $BuildRepo fetch --depth=1 origin $Base
if ($LASTEXITCODE -ne 0) { throw "Could not fetch base for LF build source" }

if (-not (Test-Path (Join-Path $BaseSource ".git"))) {
    git -C $BuildRepo worktree add --detach $BaseSource $Base
    if ($LASTEXITCODE -ne 0) { throw "Could not create base build worktree" }
}
if ((git -C $BaseSource rev-parse HEAD).Trim() -ne $Base) {
    throw "Base build worktree is not at the pinned base commit."
}
if (git -C $BaseSource status --porcelain) {
    throw "Base build worktree is not clean."
}

if (-not (Test-Path (Join-Path $PatchedSource ".git"))) {
    git -C $BuildRepo worktree add --detach $PatchedSource $Base
    if ($LASTEXITCODE -ne 0) { throw "Could not create patched build worktree" }
}
if ((git -C $PatchedSource rev-parse HEAD).Trim() -ne $Base) {
    throw "Patched worktree must start at base $Base."
}
$PatchedDirty = git -C $PatchedSource status --porcelain
if (-not $PatchedDirty) {
    git -C $PatchedSource apply --check $PatchFile
    if ($LASTEXITCODE -ne 0) {
        throw "PR patch does not apply cleanly to the pinned base."
    }
    git -C $PatchedSource apply $PatchFile
    if ($LASTEXITCODE -ne 0) { throw "Could not apply PR #24131 to the pinned base." }
}
else {
    git -C $PatchedSource apply --reverse --check $PatchFile
    if ($LASTEXITCODE -ne 0) {
        throw "Patched worktree has unrelated changes or an incomplete PR patch."
    }
}
$PatchedChanges = @(
    git -C $PatchedSource diff --name-only $Base
    git -C $PatchedSource ls-files --others --exclude-standard
) | Sort-Object -Unique
if (Compare-Object $ExpectedChanges $PatchedChanges) {
    throw "Patched worktree contains changes outside the PR patch."
}

$Engine = docker info --format "{{.OSType}}"
if ($LASTEXITCODE -ne 0 -or ($Engine -join "").Trim() -ne "linux") {
    throw "Docker Linux engine is required."
}

docker build --progress=plain `
    --file (Join-Path $BaseSource "docker\ubuntu-ci\Dockerfile") `
    --build-arg UBUNTU_VERSION=22.04 `
    --build-arg APT_RETRIES=3 `
    --build-arg ENABLE_LTTNG=false `
    --build-arg "FRR_SOURCE_REV=$Base" `
    --tag $BaseBuilderImage $BaseSource
if ($LASTEXITCODE -ne 0) { throw "Base FRR image build failed." }

docker build --progress=plain `
    --file (Join-Path $PatchedSource "docker\ubuntu-ci\Dockerfile") `
    --build-arg UBUNTU_VERSION=22.04 `
    --build-arg APT_RETRIES=3 `
    --build-arg ENABLE_LTTNG=false `
    --build-arg "FRR_SOURCE_REV=base-$Base+pr24131-$Patch" `
    --tag $PatchedBuilderImage $PatchedSource
if ($LASTEXITCODE -ne 0) { throw "Patched FRR image build failed." }

docker build --file (Join-Path $Root "pr24131-runtime\Dockerfile") `
    --build-arg "FRR_BUILD_IMAGE=$BaseBuilderImage" `
    --tag $BaseImage (Join-Path $Root "pr24131-runtime")
if ($LASTEXITCODE -ne 0) { throw "Base FRR runtime image build failed." }

docker build --file (Join-Path $Root "pr24131-runtime\Dockerfile") `
    --build-arg "FRR_BUILD_IMAGE=$PatchedBuilderImage" `
    --tag $PatchedImage (Join-Path $Root "pr24131-runtime")
if ($LASTEXITCODE -ne 0) { throw "Patched FRR runtime image build failed." }

$BaseId = (docker image inspect --format "{{.Id}}" $BaseImage).Trim()
$PatchedId = (docker image inspect --format "{{.Id}}" $PatchedImage).Trim()
if ($LASTEXITCODE -ne 0) { throw "Could not inspect built FRR images." }
$BaseBuilderId = (docker image inspect --format "{{.Id}}" $BaseBuilderImage).Trim()
$PatchedBuilderId = (docker image inspect --format "{{.Id}}" $PatchedBuilderImage).Trim()
$BaseLayers = @(docker image inspect --format "{{json .RootFS.Layers}}" $BaseImage | ConvertFrom-Json)
$PatchedLayers = @(docker image inspect --format "{{json .RootFS.Layers}}" $PatchedImage | ConvertFrom-Json)
$SharedLayerPrefix = 0
while (
    $SharedLayerPrefix -lt $BaseLayers.Count -and
    $SharedLayerPrefix -lt $PatchedLayers.Count -and
    $BaseLayers[$SharedLayerPrefix] -eq $PatchedLayers[$SharedLayerPrefix]
) {
    $SharedLayerPrefix++
}
if ($SharedLayerPrefix -lt 10) {
    throw "Only $SharedLayerPrefix image layers are shared; expected the common dependency layers."
}

$DockerfileHash = (Get-FileHash (Join-Path $BaseSource "docker\ubuntu-ci\Dockerfile") -Algorithm SHA256).Hash
$Manifest = [ordered]@{
    base_commit = $Base
    patched_commit = $Patch
    patched_tree_base = $Base
    pr_branch_merge_base = $PrMergeBase
    patched_changed_files = $PatchedChanges
    patch_sha256 = (Get-FileHash $PatchFile -Algorithm SHA256).Hash
    ubuntu_version = "22.04"
    apt_retries = 3
    enable_lttng = $false
    dockerfile_sha256 = $DockerfileHash
    runtime_dockerfile_sha256 = (Get-FileHash (Join-Path $Root "pr24131-runtime\Dockerfile") -Algorithm SHA256).Hash
    base_builder_image = $BaseBuilderImage
    base_builder_image_id = $BaseBuilderId
    patched_builder_image = $PatchedBuilderImage
    patched_builder_image_id = $PatchedBuilderId
    base_image = $BaseImage
    base_image_id = $BaseId
    patched_image = $PatchedImage
    patched_image_id = $PatchedId
    base_rootfs_layers = $BaseLayers
    patched_rootfs_layers = $PatchedLayers
    shared_rootfs_layer_prefix_count = $SharedLayerPrefix
}
$Json = $Manifest | ConvertTo-Json -Depth 8
[System.IO.File]::WriteAllText(
    $ManifestFile,
    $Json + [Environment]::NewLine,
    (New-Object System.Text.UTF8Encoding -ArgumentList $false)
)

Write-Output "Base image: $BaseImage"
Write-Output "Patched image: $PatchedImage"
Write-Output "PR patch: $PatchFile"
Write-Output "PR branch merge base: $PrMergeBase"
Write-Output "Patched source tree base: $Base"
Write-Output "Shared dependency/base layers: $SharedLayerPrefix"
Write-Output "Image manifest: $ManifestFile"
