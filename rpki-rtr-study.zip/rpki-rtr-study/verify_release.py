"""Verify the saved public-artifact inventory without changing experiments."""
import hashlib,json
from pathlib import Path

root=Path(__file__).resolve().parent
inventory=json.loads((root/'SHA256SUMS.json').read_text())
failures=[]
for name,expected in inventory.items():
    path=(root/name).resolve()
    if not path.is_relative_to(root):raise RuntimeError('Inventory path escapes the release')
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:failures.append(name)
if failures:raise RuntimeError('Artifact integrity mismatch: '+', '.join(failures))
print(f'Verified {len(inventory)} saved artifact files')
