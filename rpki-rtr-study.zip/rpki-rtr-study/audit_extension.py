"""Read-only audit of the expanded study's saved evidence; never starts containers."""
import argparse, hashlib, json,re
from pathlib import Path
import run_signed_roa as signed
import run_lab as lab
from rtr_timer_audit import verify_timers

def audit(batch,allow_partial=False):
    manifest=json.loads((batch/'manifest.json').read_text())
    assert not manifest.get('pilot_suite'), 'Pilot data are excluded'
    complete=manifest['completed']==manifest['planned_trials']
    assert complete or allow_partial, 'Incomplete measurement batch'
    seen=set(); hashes=set(); reports=[];image_sets={};copied_source_sets={}
    for trial in manifest['trials']:
        if not trial['valid']:continue
        assert trial['index'] not in seen, 'Duplicate accepted schedule position'
        seen.add(trial['index']); case=batch.parent/trial['case']
        out=json.loads((case/'outcome.json').read_text())
        assert out['scenario_valid'] and not out['invalid_reason']
        assert out.get('rtr_timer_compliance_verified'), 'Run predates the RTR timer-ordering validity gate'
        assert verify_timers(case/'rtr.pcap')==out['captured_rtr_timers']
        hashes.add(json.dumps(out['source_sha256'],sort_keys=True))
        for role,implementation in [('router',out['router']),('rp',out['rp']),('krill','krill')]:
            image_sets.setdefault(role+':'+implementation,set()).add(out['image_ids'][role])
        for name in ['app_server.py','client_agent.py','Dockerfile']:
            copied_source_sets.setdefault(name,set()).add(hashlib.sha256((case/name).read_bytes()).hexdigest())
        assert hashlib.sha256((case/'study_runner.py').read_bytes()).hexdigest()==out['source_sha256']['run_extended_study.py']
        events=[json.loads(line) for line in (case/'evidence.jsonl').read_text().splitlines()]
        start,end=out['exposure_start_ns'],out['exposure_end_ns']
        assert out['intervention_ns']<=start<end<=out['recovery_requested_ns']
        probes=[x for x in events if x['type']=='probe' and start<=x['started_ns']<end]
        counts=[sum(x.get('status')==200 and x.get('service')==service for x in probes) for service in ['AS-A','AS-B']]
        counts.append(len(probes)-sum(counts))
        assert counts==[out['http_A'],out['http_B'],out['http_other']]
        assert len(probes)==out['http_total'] and len(probes)>=5
        assert all(x['finished_ns']>=x['started_ns'] for x in probes)
        snaps=[x for x in events if x['type']=='snapshot' and start<=x['timestamp_ns']<end]
        assert len(snaps)>=2 and all(x['bgp_sessions_established'] for x in snaps)
        assert out['DUT_eth0_send_redirects']=='0'
        assert all(out[k][0].get('gateway')=='198.18.2.10' for k in ['client_route_before_intervention','client_route_after_exposure'])
        for snap in snaps:
            if out['router']!='bird':
                decoded=sorted(lab.parse_origin_asns(snap['raw']['vrps']['output']))
                assert decoded==snap['state_by_prefix'][lab.PREFIX]['installed_vrp_origins']
            else:
                for peer in ['bgpa','bgpb']:
                    assert re.search(r'^'+peer+r'\s+BGP\s+[^\n]*\bEstablished\b',snap['raw']['protocols'],re.M), 'BGP peer continuity not proven for '+peer
        actual={hashlib.sha256(p.read_bytes()).hexdigest() for p in case.rglob('*.roa')}
        expected={v for e in events for v in e.get('sha256_by_path',{}).values()}
        assert expected and expected<=actual, 'Signed publication snapshot hash missing'
        packet_verified=False
        gate_block_verified=False
        if out.get('end_of_data_ns'):
            cut,reset,eod,vrps=signed.verify_packets(case/'rtr.pcap',out['intervention_ns'])
            assert [cut,reset,eod]==[out['cut_ns'],out['reset_query_ns'],out['end_of_data_ns']]
            assert vrps==out['backup_transfer_vrps']
            packet_verified=True
        if out['mechanism']=='gate':
            packets=list(signed.read_packets(case/'rtr.pcap'))
            closures=[p for p in packets if out['intervention_ns']<=p[0]<end and p[1]==signed.PRIMARY_IP and p[2]==signed.DUT_IP and p[3]==3323 and p[5]&5]
            resets=[p for p in packets if out['preflight_start_ns']<=p[0]<end and p[1]==signed.DUT_IP and p[2]==signed.BACKUP_IP and p[4]==3323 and len(p[7])==8 and p[7][1]==2]
            assert closures and not resets and out.get('mechanism_applied'), 'Gate intervention/source block was not proven'
            gate_block_verified=True
        if out['scenario'] in ['no-rtr-outage','concurrent-inconsistent']:
            closures=[p for p in signed.read_packets(case/'rtr.pcap') if out['intervention_ns']<=p[0]<end and p[1]==signed.PRIMARY_IP and p[2]==signed.DUT_IP and p[3]==3323 and p[5]&5]
            assert not closures, 'Unexpected primary closure in uninterrupted condition'
            assert all(s['cache_connected_primary'] for s in snaps)
        reports.append({'index':trial['index'],'case':case.name,'probes_recounted':len(probes),'snapshots_reparsed':len(snaps),'signed_roa_hashes_checked':len(expected),'verified_transfer_reparsed':packet_verified,'gate_source_block_verified':gate_block_verified,'observer_errors':sum(e.get('event')=='observer_error' for e in events)})
    assert len(seen)==manifest['completed']
    assert len(hashes)==1, 'Experimental sources changed during measurement'
    assert all(len(values)==1 for values in image_sets.values()), 'A component image changed during measurement'
    assert all(len(values)==1 for values in copied_source_sets.values()), 'Copied service source changed during measurement'
    return {'batch':batch.name,'passed':complete,'completed_evidence_checks_passed':True,'partial':not complete,'runs_checked':len(reports),'checks':reports,'invalid_attempts_retained':sum(not x['valid'] for x in manifest['trials']),'source_sets':len(hashes),'image_identities':{key:sorted(values) for key,values in image_sets.items()},'copied_service_source_hashes':{key:sorted(values) for key,values in copied_source_sets.items()}}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('batch',type=Path);p.add_argument('--partial',action='store_true');args=p.parse_args()
    result=audit(args.batch.resolve(),args.partial)
    output=args.batch/'analysis'/('partial_raw_evidence_audit.json' if result['partial'] else 'raw_evidence_audit.json');output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
