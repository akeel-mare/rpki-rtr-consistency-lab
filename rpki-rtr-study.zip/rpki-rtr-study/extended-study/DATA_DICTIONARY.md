# Evidence and metric conventions

The measurement batch is separate from exploratory pilots. A completed run is the replication unit. Requests, routing snapshots, and repeated views within a run are dependent observations.

## Files

- `manifest.json` and `schedule.json`: fixed conditions, randomized replication blocks, source identities, accepted and failed attempts, and completion count. An unfinished schedule is not a completed dataset.
- `outcome.json`: assigned condition, component versions/image identities, input checks, phase boundaries, outcome counts, and censoring indicators.
- `evidence.jsonl`: runner events, batched routing observations, and the probe stream. Probe records are appended after collection; sort by each record type's timestamp before reconstructing a timeline.
- `rtr.pcap`: Ethernet/IPv4/TCP capture at the DUT. The parser reads its timestamp resolution from the PCAP header and reconstructs the backup response. A successful transfer requires primary closure, backup Reset Query and End of Data, and the assigned payload.
- `captured_rtr_timers` and `rtr_timer_compliance_verified`: complete captured RTR v1 End-of-Data timer sets and the RFC 8210 Section 6 input check. Expiration must exceed refresh and retry. The corrected cohort uses 7200-second expiration and nominal 600-second RP validation refresh; earlier 600-second-expiration batches are diagnostic and excluded.
- `publication-AS*`, `tals`, and `ta.cer`: public signed objects, test trust-anchor locator, and public trust-anchor certificate. Private authority state is excluded. A new experiment generates fresh keys and consequently different object hashes.
- `environment.json`: recorded engine, guest-kernel, Python, and resource information. Resources are shared, not exclusive allocations.
- `clock_alignment.json`: diagnostic host/guest clock offset intervals bounded by a host round trip. These observations do not prove retrospective clock stability for the whole campaign.

## Phases and clocks

Timestamps ending in `_ns` represent Unix-epoch nanoseconds. The number of digits is a storage unit, not achieved timing accuracy. Runner and routing timestamps use the Windows host clock; the probe agent and packet capture use the Docker Linux guest clock. Batched CLI observations are not atomic.

`intervention_ns` precedes the assigned control operation. Ordinary standby activation is observed for up to 40 seconds before the controlled hold. `exposure_start_ns` and `exposure_end_ns` delimit the requested eight-second hold (650 seconds for the two descriptive automatic-refresh observations). `recovery_requested_ns` starts the actual restoration operation. Activation and restoration request outcomes are also counted separately in the analysis.

Requests are assigned to a phase by `started_ns`; `finished_ns` is separate. A first successful B request-start interval is not response-completion latency. A gap between successful B request starts is not a continuous-uptime measurement. The serial probe waits after each attempt, so timeouts change sampling density; request fractions are not packet-loss rates or fractions of continuous time.

The raw legacy-named field `backup_transfer_during_exposure` actually tests whether End of Data was observed **by the hold's end**, including activation before the hold. Its analysis counterpart is deliberately named `verified_backup_transfer_by_hold_end`. Consult `end_of_data_ns` and phase boundaries for exact phase assignment.

The analysis also reports a conservative sensitivity of A-presence to any constant phase offset within +/-250 ms: a positive result needs an A response in the inner window, and a negative result needs no A response in the expanded window. This is a sensitivity assumption, not a claim that every campaign timestamp has a proven 250 ms bound.

## States and outcomes

Installed VRPs, accepted routes, selected BGP route, selected forwarding next hop, and HTTP service marker are distinct observations. The classification derived from the VRP table is valid for this exact /24 experiment with maximum length /24; it is not a general-purpose implementation of all covering-prefix ROV cases.

The final audit checks both named BIRD BGP peers in the raw protocol output. The collector's aggregate `Established` count alone is insufficient because RPKI protocols also use that state label.

`AS-A` and `AS-B` identify HTTP 200 responders. Every error, timeout, or unexpected result remains an `other` outcome. A denotes the superseded origin relative to the planned migration; it is not necessarily Invalid under the dataset installed at that instant. In the authorization-empty condition, both candidates can be NotFound.

A missing observed recovery or transfer has a finite right-censoring horizon and is not assigned zero latency. Input/measurement failures invalidate a run; failure to obtain the desired outcome does not. No trial is retried solely to obtain redirection.

Three independently initialized short runs per condition support descriptive run-level comparisons and explicitly qualified exact binomial intervals. The two long observations have one run per deployment and are not pooled into those intervals. No campaign result estimates Internet prevalence.
