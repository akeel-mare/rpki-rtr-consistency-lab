# Extension plan, fixed before measurement

The existing 18-run batch is frozen. New runs use a separate results directory and do not overwrite it. No new evidence is claimed until validity gates pass.

## Factors

* Router implementations: patched FRR, unpatched matching-base FRR (implementation control), BIRD.
* RP implementations: Routinator 0.15.2; FORT 1.6.7. Actual image IDs and router versions are recorded. Different refresh mechanisms are reported rather than compared as equal-cost operations.
* Route preferences: A higher, equal, B higher; an additional runtime announcement-withdrawal scenario.
* Authorization states: replacement A to B; covering unrelated origin (Invalid for both candidates); no covering VRP (NotFound). `Unknown` is not used as a fourth ROV state.
* Scenarios: current standby, previous standby, concurrent inconsistent sources, primary blackhole, uninterrupted control.
* Mechanisms: ordinary immediate use; gate on expected per-prefix origin set; conservative deny if the active view disagrees with current intent. These mechanisms explicitly rely on an operator-supplied expected authorization and must not be advertised as globally monotonic RTR serial-number comparison.

## Comparability

BIRD has one RTR source per RPKI protocol. Any externally controlled handoff is labeled controller-mediated, separately from FRR's native cache preference. Concurrent sessions/combined datasets are measured as their own case. An unpatched router failing to establish the post-change baseline is an implementation finding, not silently discarded until a favorable run appears.

## Metrics and gates

Signed ROA provenance, RP-validated outputs, actual RTR transfer/connection state, accepted/selected routes, Linux forwarding result, HTTP destination, errors/timeouts, transition times and actual observer gaps. Request-start and response-completion times are distinct. Baseline, intervention, recovery, and cleanup are recorded even for invalid runs. No claims of natural stale-state lifetime from a fixed hold.

Replication is by a newly initialized run; requests and prefixes are dependent within a run. Randomized order uses a recorded seed. Run-level intervals and censored events are retained. Small sample confidence intervals are explicitly labeled; no packet-level pseudo-replication.

## Final measurement allocation

Before starting the non-pilot batch, the allocation is fixed at 114 short runs (38 conditions, three independently initialized repetitions), plus two 650-second automatic-refresh observations, one per router deployment. The latter are descriptive long-horizon checks with n=1 per deployment, not additional replicates for the short-run confidence intervals. The short runs use an eight-second exposure; long runs do not force a standby refresh during their observation.

The 38 short conditions comprise: 18 router/policy/scenario combinations (two routers × three policies × stale, updated, and dual-available conditions); 10 additional router/scenario combinations (uninterrupted, blackhole, no covering ROA, unrelated origin, and runtime A withdrawal); four FORT/router stale/current combinations; four router/mitigation combinations; and two matching-base FRR stale/current controls.

Pilot-informed initialization amendment, before final measurement: start both validators and verify the initial A view before starting the DUT, avoiding initial RTR No Data Available responses as an uncontrolled startup factor. For an assigned handoff (except a gate that deliberately blocks it), observe backup connection for at most 40 seconds before the controlled hold. The hold does not require A admission or redirection. All probes and snapshots continue through this activation interval; its delay and outcomes are reported separately from the hold. A connection not observed by the limit remains a censored outcome, rather than an invalid run or a reason to retry for a desired result. The four-second early pilots that lacked a transfer are retained and excluded from submission results with the rest of the pilots.

Pilot attempts are not pooled into submission results. Every invalid attempt and protocol-control correction is retained. An unsuccessful handoff or restoration is not itself an invalidity criterion when input conditions and observation coverage are proven: its time is right-censored. Rejected control commands, missing baseline, unintended direct forwarding, or missing packet evidence of the primary closure are invalid input/measurement conditions.

On BIRD a low-preference blackhole route prevents fallback to the shared connected subnet when both BGP candidates are rejected. Both router deployments disable per-interface ICMP redirects and verify that the probe's next hop remains the DUT. These checks are required before freezing the measurement runner.

## RTR timer-ordering correction, 20 November 2026

The batch `extension-batch-20261120T020048Z` was stopped and excluded after raw End-of-Data inspection found Routinator advertising refresh intervals above 600 seconds while expiration was 600 seconds. RFC 8210 Section 6 requires expiration to exceed both refresh and retry. Its earlier `scenario_valid` flags did not check this condition and must not be treated as standards-conforming submission evidence. All attempts remain as diagnostic records; the corrected cohort is a fresh batch, not a continuation or pool with those attempts.

The corrected allocation remains 114 short runs plus two descriptive 650-second automatic-refresh observations. RP validation refresh remains nominally 600 seconds; RTR expiration is 7200 seconds. BIRD accepts the server's timer values instead of forcing one-second polling. FRR's initial client settings are refresh 600, retry 2, expire 7200; FORT advertises the same nominal RTR values. Every corrected run reparses captured complete RTR v1 End-of-Data messages and requires RFC timer ranges and expire strictly greater than refresh/retry before validity can pass. The long checks observe automatic validation refresh, not expiration.

## Release and submission

Prepare a reproducible, secret-screened local release first. Publishing requires a concrete destination/account; no repository or DOI is invented. Actual journal submission must use author-approved declarations and the portal's required information. The manuscript is updated only with completed validated results.
