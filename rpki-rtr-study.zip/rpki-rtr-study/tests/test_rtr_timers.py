import struct
import unittest
from unittest.mock import patch
from ipaddress import IPv4Address
from rtr_timer_audit import verify_timers

class CapturedTimerTests(unittest.TestCase):
    def packets(self,expire):
        server=IPv4Address('198.18.2.21').packed;dut=IPv4Address('198.18.2.10').packed
        response=struct.pack('!BBHI',1,3,1,8)
        eod=struct.pack('!BBHIIIII',1,7,1,24,2,620,2,expire)
        data=response+eod
        def packet(seq,flags,payload):return (1,server,dut,3323,40000,flags,seq,payload)
        return [packet(1000,18,b''),packet(1001,16,data[:11]),packet(1012,16,data[11:]),packet(1001,16,data[:11])]

    def test_reassembled_compliant_timer_set_with_retransmission(self):
        with patch('rtr_timer_audit.read_packets',return_value=iter(self.packets(7200))):
            records=verify_timers('unused.pcap')
        self.assertEqual([(r['refresh_seconds'],r['retry_seconds'],r['expire_seconds']) for r in records],[(620,2,7200)])

    def test_expiration_below_refresh_is_rejected(self):
        with patch('rtr_timer_audit.read_packets',return_value=iter(self.packets(600))):
            with self.assertRaisesRegex(ValueError,'RFC 8210'):
                verify_timers('unused.pcap')

    def test_missing_end_of_data_is_not_accepted(self):
        with patch('rtr_timer_audit.read_packets',return_value=iter([])):
            with self.assertRaisesRegex(ValueError,'No captured'):
                verify_timers('unused.pcap')

if __name__=='__main__':unittest.main()
