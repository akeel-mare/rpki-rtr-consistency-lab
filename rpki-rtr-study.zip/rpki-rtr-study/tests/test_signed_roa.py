import struct
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from run_lab import AS_A, AS_B, RTR_BACKUP, SnapshotMonitor
from run_signed_roa import (
    baseline_sample_if_valid,
    configure_prefix_case,
    interval_summary,
    measure_timeline,
    parse_ipv4_prefix_pdu,
    stale_state_is_installed,
    verify_packets,
    verify_uninterrupted_packets,
)


class SignedRoaMeasurementTests(unittest.TestCase):
    def test_records_http_and_rib_fib_recovery_times(self):
        cut_ns = 1_000_000_000
        exposure_end_ns = 9_000_000_000
        rows = [
            {
                "type": "snapshot",
                "timestamp_ns": cut_ns + 500_000_000,
                "accepted_as_a": True,
                "selected_rib_as": AS_A,
                "selected_fib_as": AS_A,
            },
            {
                "type": "runner",
                "timestamp_ns": exposure_end_ns + 3_950_000_000,
                "event": "validator_vrps_verified",
                "validator": RTR_BACKUP,
                "origin": AS_B,
            },
            {
                "type": "snapshot",
                "timestamp_ns": exposure_end_ns + 2_000_000_000,
                "accepted_as_a": False,
                "selected_rib_as": AS_B,
                "selected_fib_as": AS_B,
            },
        ]
        probes = [
            {
                "type": "probe",
                "started_ns": cut_ns + 50_000_000,
                "service": "AS-B",
                "status": 200,
            },
            {
                "type": "probe",
                "started_ns": cut_ns + 100_000_000,
                "service": "AS-A",
                "status": 200,
            },
            {
                "type": "probe",
                "started_ns": exposure_end_ns + 4_000_000_000,
                "service": "AS-B",
                "status": 200,
            },
        ]

        measured = measure_timeline(rows, probes, cut_ns, exposure_end_ns)

        self.assertEqual(measured["exposure_duration_ms"], 8000)
        self.assertEqual(measured["first_as_a_accepted_after_cut_ms"], 500)
        self.assertEqual(measured["first_as_a_selected_after_cut_ms"], 500)
        self.assertEqual(measured["as_a_accepted_duration_ms"], 9500)
        self.assertEqual(measured["as_a_fib_selected_duration_ms"], 9500)
        self.assertEqual(measured["first_as_b_after_exposure_ms"], 4000)
        self.assertEqual(measured["first_as_b_after_backup_validation_ms"], 50)
        self.assertEqual(measured["as_a_to_as_b_recovery_ms"], 11900)
        self.assertEqual(measured["as_b_probe_success_gap_around_as_a_ms"], 11950)
        self.assertEqual(measured["first_as_b_selected_after_exposure_ms"], 2000)

    def test_unrecovered_as_a_durations_are_reported_as_observed_minima(self):
        cut_ns = 1_000_000_000
        exposure_end_ns = 9_000_000_000
        measured = measure_timeline(
            [
                {
                    "type": "snapshot",
                    "timestamp_ns": cut_ns + 500_000_000,
                    "accepted_as_a": True,
                    "selected_rib_as": AS_A,
                    "selected_fib_as": AS_A,
                }
            ],
            [],
            cut_ns,
            exposure_end_ns,
        )

        self.assertIsNone(measured["as_a_accepted_duration_ms"])
        self.assertEqual(measured["as_a_accepted_minimum_observed_ms"], 7500)
        self.assertIsNone(measured["as_a_fib_selected_duration_ms"])
        self.assertEqual(measured["as_a_fib_selected_minimum_observed_ms"], 7500)

    def test_two_prefix_trial_config_announces_both_prefixes_and_keeps_policy(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            case = Path(temporary_directory) / "case"
            case.mkdir()
            configure_prefix_case(case, 2)

            as_a = (case / "frr" / "as-a.conf").read_text(encoding="utf-8")
            dut = (case / "frr" / "dut.conf").read_text(encoding="utf-8")
            compose = (case / "compose.yaml").read_text(encoding="utf-8")

        self.assertIn("ip address 198.18.1.10/32", as_a)
        self.assertIn("network 198.18.1.0/24", as_a)
        self.assertIn("ip route 198.18.1.0/24 Null0", as_a)
        self.assertIn("ip route 198.18.1.0/24 Null0 254", dut)
        self.assertIn("ROV_PREFIX_COUNT: ${ROV_PREFIX_COUNT:-1}", compose)
        self.assertIn("match rpki invalid", dut)
        self.assertIn("set local-preference 200", dut)
        self.assertIn("neighbor 198.18.2.11 route-map ROV-PREFER-A in", dut)

    def test_baseline_validation_returns_snapshot_not_boolean(self):
        prefix = "198.18.0.0/24"
        sample = {
            "cache_connected_primary": True,
            "cache_connected_backup": False,
            "bgp_sessions_established": True,
            "state_by_prefix": {
                prefix: {
                    "installed_vrp_origins": [AS_B],
                    "rov_by_asn": {
                        str(AS_A): "invalid",
                        str(AS_B): "valid",
                    },
                    "accepted_asns": [AS_B],
                    "selected_rib_as": AS_B,
                    "selected_fib_as": AS_B,
                }
            },
        }

        validated = baseline_sample_if_valid(
            sample,
            {prefix: "AS-B"},
            (prefix,),
        )

        self.assertIs(validated, sample)
        self.assertIsNone(
            baseline_sample_if_valid(sample, {prefix: "AS-A"}, (prefix,))
        )

    def test_idle_control_capture_does_not_require_rtr_payload_packets(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            capture = Path(temporary_directory) / "idle.pcap"
            capture.write_bytes(
                b"\xd4\xc3\xb2\xa1"
                + struct.pack("<HHIIII", 2, 4, 0, 0, 65535, 1)
            )

            evidence = verify_uninterrupted_packets(capture, 0, 10)

        self.assertEqual(evidence["primary_packets_in_interval"], 0)
        self.assertEqual(evidence["primary_closures"], 0)
        self.assertEqual(evidence["backup_reset_queries"], 0)

    def test_parses_vrp_prefix_from_ipv4_prefix_pdu(self):
        pdu = struct.pack(
            "!BBHIBBBx4sI",
            1,
            4,
            0,
            20,
            1,
            24,
            24,
            bytes((198, 18, 1, 0)),
            AS_A,
        )

        self.assertEqual(
            parse_ipv4_prefix_pdu(pdu),
            {
                "prefix": "198.18.1.0/24",
                "flags": 1,
                "max_length": 24,
                "origin": AS_A,
            },
        )

    def test_stale_backup_accepts_union_of_primary_and_backup_vrps(self):
        sample = {
            "bgp_sessions_established": True,
            "state_by_prefix": {
                "198.18.0.0/24": {
                    "installed_vrp_origins": [AS_A, AS_B],
                    "rov_by_asn": {
                        str(AS_A): "valid",
                        str(AS_B): "valid",
                    },
                }
            },
        }

        self.assertTrue(stale_state_is_installed(sample))

    def test_snapshot_monitor_recovers_from_transient_startup_failure(self):
        rows = []
        monitor = SnapshotMonitor(rows)
        attempts = 0

        def collect_snapshot():
            nonlocal attempts
            attempts += 1
            if attempts == 1:
                raise RuntimeError("FRR daemons are still starting")
            monitor.stop_event.set()
            return {"type": "snapshot", "timestamp_ns": 1}

        with (
            mock.patch("run_lab.collect_snapshot", side_effect=collect_snapshot),
            mock.patch("run_lab.POLL_SECONDS", 0),
        ):
            monitor._run()

        events = [row.get("event") for row in rows]
        self.assertIn("snapshot_monitor_startup_retry", events)
        self.assertIn("snapshot_monitor_startup_recovered", events)
        self.assertEqual(sum(row.get("type") == "snapshot" for row in rows), 1)

    def test_verifies_backup_vrp_in_rtr_capture_before_end_of_data(self):
        primary_ip = bytes((198, 18, 2, 21))
        dut_ip = bytes((198, 18, 2, 10))
        backup_ip = bytes((198, 18, 2, 22))
        client_port = 50000

        def packet(source, destination, source_port, destination_port, sequence, flags, payload):
            tcp = struct.pack(
                "!HHIIHHHH",
                source_port,
                destination_port,
                sequence,
                0,
                (5 << 12) | flags,
                0,
                0,
                0,
            ) + payload
            ip = struct.pack(
                "!BBHHHBBH4s4s",
                0x45,
                0,
                20 + len(tcp),
                0,
                0,
                64,
                6,
                0,
                source,
                destination,
            ) + tcp
            frame = bytes(12) + b"\x08\x00" + ip
            return frame

        frames = [
            (
                1700000000,
                100000,
                packet(primary_ip, dut_ip, 3323, 50001, 1, 0x11, b""),
            ),
            (
                1700000000,
                200000,
                packet(dut_ip, backup_ip, client_port, 3323, 1, 0x10,
                       struct.pack("!BBHI", 1, 2, 0, 8)),
            ),
            (
                1700000000,
                300000,
                packet(
                    backup_ip,
                    dut_ip,
                    3323,
                    client_port,
                    1,
                    0x10,
                    struct.pack(
                        "!BBHIBBBx4sI",
                        1,
                        4,
                        0,
                        20,
                        1,
                        24,
                        24,
                        bytes((198, 18, 1, 0)),
                        AS_A,
                    )
                    + struct.pack("!BBHII", 1, 7, 0, 12, 1),
                ),
            ),
        ]
        with tempfile.TemporaryDirectory() as temporary_directory:
            capture = Path(temporary_directory) / "handoff.pcap"
            with capture.open("wb") as stream:
                stream.write(
                    b"\xd4\xc3\xb2\xa1"
                    + struct.pack("<HHIIII", 2, 4, 0, 0, 65535, 1)
                )
                for second, fraction, frame in frames:
                    stream.write(
                        struct.pack("<IIII", second, fraction, len(frame), len(frame))
                    )
                    stream.write(frame)

            cut, reset, eod, vrps = verify_packets(
                capture,
                1_700_000_000_000_000_000,
            )

        self.assertEqual(cut, 1_700_000_000_100_000_000)
        self.assertEqual(reset, 1_700_000_000_200_000_000)
        self.assertEqual(eod, 1_700_000_000_300_000_000)
        self.assertEqual(vrps, [{
            "prefix": "198.18.1.0/24",
            "flags": 1,
            "max_length": 24,
            "origin": AS_A,
        }])

    def test_no_as_a_probe_leaves_switch_and_recovery_times_empty(self):
        cut_ns = 1_000_000_000
        exposure_end_ns = 9_000_000_000
        measured = measure_timeline(
            [],
            [
                {
                    "type": "probe",
                    "started_ns": exposure_end_ns + 100_000_000,
                    "service": "AS-B",
                    "status": 200,
                }
            ],
            cut_ns,
            exposure_end_ns,
        )

        self.assertIsNone(measured["first_as_a_http_ns"])
        self.assertIsNone(measured["as_a_to_as_b_recovery_ms"])
        self.assertEqual(measured["first_as_b_after_exposure_ms"], 100)


if __name__ == "__main__":
    unittest.main()
