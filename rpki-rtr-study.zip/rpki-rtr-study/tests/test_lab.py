import struct
import unittest

from run_lab import (
    AS_A,
    AS_B,
    cache_connected,
    cache_connected_group,
    expected_as_b_vrp_state,
    expected_new_state,
    expected_stale_backup_data,
    parse_vtysh_batch_output,
    parse_origin_asns,
    parse_vrp_origins,
    selected_fib_as,
    selected_rib_as,
)
from rtr_server import RtrServer


class FakeWriter:
    def __init__(self):
        self.data = bytearray()

    def write(self, payload):
        self.data.extend(payload)

    async def drain(self):
        return None


class LabParsingTests(unittest.TestCase):
    def test_backup_socket_connected_even_if_connected_group_is_unchanged(self):
        state = (
            '{"connectedGroup":1,"connections":['
            '{"host":"198.18.2.21","preference":1,"state":"disconnected"},'
            '{"host":"198.18.2.22","preference":2,"state":"connected"}]}'
        )
        self.assertFalse(cache_connected(state, "198.18.2.21"))
        self.assertTrue(cache_connected(state, "198.18.2.22"))
        self.assertEqual(cache_connected_group(state), 1)

    def test_selected_rib_as_is_taken_from_best_path_block(self):
        output = (
            "Paths: (2 available, best #1, table default)\n"
            "  65002\n"
            "    198.18.2.12 from 198.18.2.12\n"
            "      valid, external, best (First path received)\n"
            "  65001\n"
            "    198.18.2.11 from 198.18.2.11\n"
            "      valid, external\n"
        )
        self.assertEqual(selected_rib_as(output), AS_B)
        self.assertNotEqual(selected_rib_as(output), AS_A)

    def test_vrp_and_fib_parsers_match_frr_output(self):
        vrps = (
            "RPKI/RTR prefix table\n"
            "Prefix                                   Prefix Length  Origin-AS\n"
            "198.18.0.0                                  24 -  24   65001\n"
        )
        fib = (
            "Routing entry for 198.18.0.0/24\n"
            "  Known via \"bgp\", distance 20, metric 0, best\n"
            "  * 198.18.2.11, via eth1, weight 1\n"
        )
        self.assertEqual(parse_origin_asns(vrps), {AS_A})
        self.assertEqual(selected_fib_as(fib), AS_A)

    def test_vrp_parser_keeps_prefixes_separate(self):
        vrps = (
            "198.18.0.0                                  24 -  24   65001\n"
            "198.18.1.0                                  24 -  24   65002\n"
        )
        self.assertEqual(
            parse_vrp_origins(vrps, ("198.18.0.0/24", "198.18.1.0/24")),
            {"198.18.0.0/24": {AS_A}, "198.18.1.0/24": {AS_B}},
        )

    def test_unrelated_origin_is_not_mistaken_for_no_covering_vrp(self):
        observed = parse_origin_asns(
            "198.18.0.0                                  24 -  24   65003\n"
        )
        self.assertEqual(observed, {65003})
        self.assertTrue(observed)
        self.assertNotIn(AS_A, observed)
        self.assertNotIn(AS_B, observed)

    def test_stale_backup_is_proven_by_installed_data_not_route_outcome(self):
        snapshot = {
            "state_by_prefix": {
                "198.18.0.0/24": {
                    "installed_vrp_origins": [AS_A, AS_B],
                    "accepted_asns": [AS_B],
                    "selected_rib_as": AS_B,
                    "selected_fib_as": AS_B,
                }
            },
            "bgp_sessions_established": True,
        }
        self.assertTrue(expected_stale_backup_data(snapshot))

    def test_primary_update_state_is_not_invalidated_by_route_outcome(self):
        snapshot = {
            "bgp_sessions_established": True,
            "state_by_prefix": {
                "198.18.0.0/24": {
                    "installed_vrp_origins": [AS_B],
                    "accepted_asns": [AS_A],
                    "selected_rib_as": AS_A,
                    "selected_fib_as": AS_A,
                }
            },
        }
        self.assertTrue(expected_as_b_vrp_state(snapshot))
        self.assertFalse(expected_new_state(snapshot))

    def test_batched_vtysh_output_preserves_command_output_and_status(self):
        commands = {"cache": "show rpki cache-connection json", "peers": "show bgp neighbors"}
        output = (
            "__ROV_SNAPSHOT_BEGIN_cache__\n"
            '{"connections":[]}\n'
            "__ROV_SNAPSHOT_STATUS_cache__=0\n"
            "__ROV_SNAPSHOT_BEGIN_peers__\n"
            "BGP state = Established\n"
            "__ROV_SNAPSHOT_STATUS_peers__=1\n"
        )

        raw = parse_vtysh_batch_output(commands, output, "diagnostic", 0)

        self.assertEqual(raw["cache"]["output"], '{"connections":[]}')
        self.assertEqual(raw["cache"]["returncode"], 0)
        self.assertEqual(raw["peers"]["output"], "BGP state = Established")
        self.assertEqual(raw["peers"]["returncode"], 1)
        self.assertEqual(raw["_batch"]["stderr"], "diagnostic")

    def test_batched_vtysh_output_rejects_missing_status_marker(self):
        with self.assertRaisesRegex(RuntimeError, "Could not parse"):
            parse_vtysh_batch_output(
                {"cache": "show rpki cache-connection json"},
                "__ROV_SNAPSHOT_BEGIN_cache__\n{}",
                "",
                0,
            )


class RtrProtocolTests(unittest.IsolatedAsyncioTestCase):
    async def test_full_response_ends_with_complete_eod(self):
        server = RtrServer()
        writer = FakeWriter()
        await server.send_full(writer)

        offset = 0
        last_pdu = None
        while offset < len(writer.data):
            pdu_length = struct.unpack("!I", writer.data[offset + 4 : offset + 8])[0]
            last_pdu = bytes(writer.data[offset : offset + pdu_length])
            offset += pdu_length

        self.assertIsNotNone(last_pdu)
        self.assertEqual(last_pdu[1], 7)
        self.assertEqual(struct.unpack("!I", last_pdu[4:8])[0], 24)
        self.assertEqual(struct.unpack("!I", last_pdu[8:12])[0], server.serial)

    async def test_null_serial_update_starts_with_cache_response(self):
        server = RtrServer()
        writer = FakeWriter()
        await server.send_delta(writer, set(server.vrps))

        self.assertEqual(writer.data[1], 3)
        self.assertEqual(writer.data[8 + 1], 7)
        self.assertEqual(struct.unpack("!I", writer.data[12:16])[0], 24)

    async def test_serial_update_contains_withdraw_add_and_complete_eod(self):
        server = RtrServer()
        server.vrps = server.make_vrps(AS_B)
        writer = FakeWriter()
        await server.send_delta(writer, server.make_vrps(AS_A))

        pdus = []
        offset = 0
        while offset < len(writer.data):
            pdu_length = struct.unpack("!I", writer.data[offset + 4 : offset + 8])[0]
            pdus.append(bytes(writer.data[offset : offset + pdu_length]))
            offset += pdu_length

        self.assertEqual([pdu[1] for pdu in pdus], [3, 4, 4, 7])
        self.assertEqual(pdus[1][8], 0)
        self.assertEqual(pdus[2][8], 1)
        self.assertEqual(struct.unpack("!I", pdus[-1][4:8])[0], 24)
        self.assertEqual(struct.unpack("!I", pdus[-1][8:12])[0], server.serial)
        self.assertEqual(struct.unpack("!III", pdus[-1][12:24]), (1, 2, 600))

    async def test_ipv4_prefix_pdu_has_wire_length_and_origin_asn(self):
        pdu = RtrServer.prefix_pdu(("198.18.0.0/24", 24, AS_A))
        self.assertEqual(len(pdu), 20)
        self.assertEqual(struct.unpack("!I", pdu[4:8])[0], 20)
        self.assertEqual(pdu[2:4], b"\x00\x00")
        self.assertEqual(pdu[8], 1)
        self.assertEqual(pdu[9:11], b"\x18\x18")
        self.assertEqual(struct.unpack("!I", pdu[16:20])[0], AS_A)


if __name__ == "__main__":
    unittest.main()
