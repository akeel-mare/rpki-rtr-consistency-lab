"""Replay an RTR failover using signed Krill ROAs and two Routinator instances."""

import argparse
import csv
import hashlib
import json
import os
import secrets
import shutil
import struct
import subprocess
import sys
import time
from datetime import datetime, timezone
from ipaddress import IPv4Address
from pathlib import Path

import run_lab as lab
from run_pr24131_comparison import PATCHED_IMAGE, copy_lab, image_id, load_preparation_manifest


ROOT = Path(__file__).resolve().parent
CA_IMAGE = "nlnetlabs/krill:v0.16.2"
RP_IMAGE = "nlnetlabs/routinator:v0.15.2"
REPO = "/rpki/repo/rsync/current"
DUT_IP = IPv4Address("198.18.2.10").packed
PRIMARY_IP = IPv4Address("198.18.2.21").packed
BACKUP_IP = IPv4Address("198.18.2.22").packed


def krill(*args):
    return lab.compose(
        "exec", "-T", "krill", "sh", "-c",
        'export KRILL_CLI_TOKEN="$KRILL_ADMIN_TOKEN"; exec krillc "$@"',
        "krillc", *args,
    ).stdout


def publication_hashes():
    report = lab.compose(
        "exec", "-T", "labrepo", "find", REPO, "-name", "*.roa",
        "-exec", "sha256sum", "{}", "+",
    ).stdout.splitlines()
    return {
        parts[1].strip(): parts[0]
        for line in report
        if len(parts := line.split(maxsplit=1)) == 2
    }


def publish(case, rows, origin, previous=None, previous_hashes=None, prefixes=None):
    prefixes = tuple(prefixes or lab.PREFIXES)
    lab.log_event(
        rows,
        "signed_roa_update_requested",
        origin=origin,
        previous_origin=previous,
        prefixes=list(prefixes),
    )
    args = ["roas", "update", "--ca", "testbed"]
    for prefix in prefixes:
        args.extend(("--add", f"{prefix} => {origin}"))
    if previous is not None:
        for prefix in prefixes:
            args.extend(("--remove", f"{prefix} => {previous}"))
    krill(*args)
    output = krill("--format", "json", "roas", "list", "--ca", "testbed")

    def published_roa():
        hashes = publication_hashes()
        if hashes and hashes != previous_hashes:
            return hashes
        return None

    hashes = await_value("newly published signed ROAs on the rsync server", published_roa)
    lab.log_event(
        rows,
        "signed_roa_updated",
        origin=origin,
        prefixes=list(prefixes),
        sha256_by_path=hashes,
        krill_roas=json.loads(output),
    )
    lab.compose("cp", f"labrepo:{REPO}", str(case / f"publication-AS{origin}"))
    return hashes


def validator_vrps(service):
    data = lab.compose("exec", "-T", service, "wget", "-qO-", "http://127.0.0.1:8323/json")
    return json.loads(data.stdout)["roas"]


def expected_vrps(service, origin, prefixes=None):
    try:
        actual = validator_vrps(service)
    except (RuntimeError, ValueError):
        return None
    expected = {(origin, prefix, 24) for prefix in (prefixes or lab.PREFIXES)}
    observed = {
        (int(str(row["asn"]).removeprefix("AS")), row["prefix"], row["maxLength"])
        for row in actual
    }
    return actual if observed == expected else None


def await_value(description, predicate, timeout=40):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if value := predicate():
            return value
        time.sleep(0.25)
    raise RuntimeError(f"Timed out waiting for {description}")


def verify_validator(rows, service, origin, refresh=False, prefixes=None):
    if refresh:
        lab.compose("kill", "-s", "SIGUSR1", service)
    vrps = await_value(
        f"{service} to validate AS{origin}",
        lambda: expected_vrps(service, origin, prefixes),
    )
    lab.log_event(
        rows,
        "validator_vrps_verified",
        validator=service,
        origin=origin,
        prefixes=list(prefixes or lab.PREFIXES),
        vrps=vrps,
    )


def measure_timeline(rows, probes, cut_ns, exposure_end_ns, prefix=None):
    snapshots = []
    for row in rows:
        if row.get("type") != "snapshot":
            continue
        snapshot = row
        if prefix is not None:
            state = row.get("state_by_prefix", {}).get(prefix)
            if state is None:
                continue
            snapshot = {
                **row,
                "accepted_as_a": lab.AS_A in state["accepted_asns"],
                "selected_rib_as": state["selected_rib_as"],
                "selected_fib_as": state["selected_fib_as"],
            }
        snapshots.append(snapshot)
    if prefix is not None:
        probes = [probe for probe in probes if probe.get("prefix") == prefix]
    snapshots.sort(key=lambda row: row["timestamp_ns"])
    probes = sorted(
        (row for row in probes if row.get("type") == "probe"),
        key=lambda row: row["started_ns"],
    )
    first_a_probe = next(
        (
            probe for probe in probes
            if cut_ns <= probe["started_ns"] < exposure_end_ns
            and probe.get("service") == "AS-A"
            and probe.get("status") == 200
        ),
        None,
    )
    first_b_after_exposure = next(
        (
            probe for probe in probes
            if probe["started_ns"] >= exposure_end_ns
            and probe.get("service") == "AS-B"
            and probe.get("status") == 200
        ),
        None,
    )
    backup_b_validation = next(
        (
            row for row in sorted(rows, key=lambda item: item.get("timestamp_ns", 0))
            if row.get("event") == "validator_vrps_verified"
            and row.get("validator") == lab.RTR_BACKUP
            and row.get("origin") == lab.AS_B
            and row.get("timestamp_ns", 0) >= exposure_end_ns
        ),
        None,
    )
    first_b_after_validation = next(
        (
            probe for probe in probes
            if backup_b_validation is not None
            and probe["started_ns"] >= backup_b_validation["timestamp_ns"]
            and probe.get("service") == "AS-B"
            and probe.get("status") == 200
        ),
        None,
    )
    first_b_after_a = next(
        (
            probe for probe in probes
            if first_a_probe is not None
            and probe["started_ns"] > first_a_probe["started_ns"]
            and probe.get("service") == "AS-B"
            and probe.get("status") == 200
        ),
        None,
    )
    last_b_before_a = next(
        (
            probe for probe in reversed(probes)
            if first_a_probe is not None
            and cut_ns <= probe["started_ns"] < first_a_probe["started_ns"]
            and probe.get("service") == "AS-B"
            and probe.get("status") == 200
        ),
        None,
    )
    exposure_snapshots = [
        row for row in snapshots
        if cut_ns <= row["timestamp_ns"] < exposure_end_ns
    ]
    post_exposure_snapshots = [
        row for row in snapshots if row["timestamp_ns"] >= exposure_end_ns
    ]
    first_a_accepted = next(
        (row for row in exposure_snapshots if row["accepted_as_a"]), None
    )
    first_a_selected = next(
        (
            row for row in exposure_snapshots
            if row["selected_rib_as"] == row["selected_fib_as"] == lab.AS_A
        ),
        None,
    )
    first_a_rejected = next(
        (
            row for row in snapshots
            if first_a_accepted is not None
            and row["timestamp_ns"] > first_a_accepted["timestamp_ns"]
            and not row["accepted_as_a"]
        ),
        None,
    )
    first_a_route_changed = next(
        (
            row for row in snapshots
            if first_a_selected is not None
            and row["timestamp_ns"] > first_a_selected["timestamp_ns"]
            and row["selected_fib_as"] != lab.AS_A
        ),
        None,
    )
    first_b_selected = next(
        (
            row for row in post_exposure_snapshots
            if row["selected_rib_as"] == row["selected_fib_as"] == lab.AS_B
        ),
        None,
    )
    snapshot_gaps_ms = [
        (right["timestamp_ns"] - left["timestamp_ns"]) / 1_000_000
        for left, right in zip(snapshots, snapshots[1:])
    ]
    probe_starts = [probe["started_ns"] for probe in probes]
    probe_gaps_ms = [
        (right - left) / 1_000_000
        for left, right in zip(probe_starts, probe_starts[1:])
    ]

    def p95(values):
        if not values:
            return None
        return sorted(values)[(95 * len(values) + 99) // 100 - 1]

    return {
        "exposure_duration_ms": (exposure_end_ns - cut_ns) / 1_000_000,
        "first_as_a_http_ns": (
            first_a_probe["started_ns"] if first_a_probe else None
        ),
        "first_as_a_accepted_after_cut_ms": (
            (first_a_accepted["timestamp_ns"] - cut_ns) / 1_000_000
            if first_a_accepted else None
        ),
        "first_as_a_accepted_ns": (
            first_a_accepted["timestamp_ns"] if first_a_accepted else None
        ),
        "first_as_a_selected_after_cut_ms": (
            (first_a_selected["timestamp_ns"] - cut_ns) / 1_000_000
            if first_a_selected else None
        ),
        "first_as_a_selected_ns": (
            first_a_selected["timestamp_ns"] if first_a_selected else None
        ),
        "first_as_a_acceptance_cleared_after_cut_ms": (
            (first_a_rejected["timestamp_ns"] - cut_ns) / 1_000_000
            if first_a_rejected else None
        ),
        "first_as_a_acceptance_cleared_ns": (
            first_a_rejected["timestamp_ns"] if first_a_rejected else None
        ),
        "as_a_accepted_duration_ms": (
            (first_a_rejected["timestamp_ns"]
             - first_a_accepted["timestamp_ns"]) / 1_000_000
            if first_a_accepted and first_a_rejected else None
        ),
        "as_a_accepted_minimum_observed_ms": (
            (first_a_rejected["timestamp_ns"] - first_a_accepted["timestamp_ns"]) / 1_000_000
            if first_a_accepted and first_a_rejected
            else (exposure_end_ns - first_a_accepted["timestamp_ns"]) / 1_000_000
            if first_a_accepted else None
        ),
        "first_as_a_route_cleared_after_cut_ms": (
            (first_a_route_changed["timestamp_ns"] - cut_ns) / 1_000_000
            if first_a_route_changed else None
        ),
        "first_as_a_route_cleared_ns": (
            first_a_route_changed["timestamp_ns"] if first_a_route_changed else None
        ),
        "as_a_fib_selected_duration_ms": (
            (first_a_route_changed["timestamp_ns"]
             - first_a_selected["timestamp_ns"]) / 1_000_000
            if first_a_selected and first_a_route_changed else None
        ),
        "as_a_fib_selected_minimum_observed_ms": (
            (first_a_route_changed["timestamp_ns"] - first_a_selected["timestamp_ns"]) / 1_000_000
            if first_a_selected and first_a_route_changed
            else (exposure_end_ns - first_a_selected["timestamp_ns"]) / 1_000_000
            if first_a_selected else None
        ),
        "as_b_probe_success_gap_around_as_a_ms": (
            (first_b_after_a["started_ns"] - last_b_before_a["started_ns"]) / 1_000_000
            if first_b_after_a and last_b_before_a else None
        ),
        "last_as_b_http_before_as_a_ns": (
            last_b_before_a["started_ns"] if last_b_before_a else None
        ),
        "first_as_b_http_after_as_a_ns": (
            first_b_after_a["started_ns"] if first_b_after_a else None
        ),
        "first_as_b_http_after_exposure_ns": (
            first_b_after_exposure["started_ns"]
            if first_b_after_exposure else None
        ),
        "first_as_b_after_exposure_ms": (
            (first_b_after_exposure["started_ns"] - exposure_end_ns) / 1_000_000
            if first_b_after_exposure else None
        ),
        "backup_b_validation_after_exposure_ns": (
            backup_b_validation["timestamp_ns"] if backup_b_validation else None
        ),
        "first_as_b_after_backup_validation_ms": (
            (first_b_after_validation["started_ns"]
             - backup_b_validation["timestamp_ns"]) / 1_000_000
            if first_b_after_validation and backup_b_validation else None
        ),
        "as_a_to_as_b_recovery_ms": (
            (first_b_after_exposure["started_ns"]
             - first_a_probe["started_ns"]) / 1_000_000
            if first_a_probe and first_b_after_exposure else None
        ),
        "first_as_b_selected_after_exposure_ms": (
            (first_b_selected["timestamp_ns"] - exposure_end_ns) / 1_000_000
            if first_b_selected else None
        ),
        "snapshot_count": len(snapshots),
        "snapshot_gap_p95_ms": p95(snapshot_gaps_ms),
        "snapshot_gap_max_ms": max(snapshot_gaps_ms) if snapshot_gaps_ms else None,
        "probe_count": len(probes),
        "probe_gap_p95_ms": p95(probe_gaps_ms),
        "probe_gap_max_ms": max(probe_gaps_ms) if probe_gaps_ms else None,
    }


def interval_summary(timestamps_ns):
    timestamps_ns = sorted(timestamps_ns)
    gaps_ms = [
        (right - left) / 1_000_000
        for left, right in zip(timestamps_ns, timestamps_ns[1:])
    ]
    if not gaps_ms:
        return {"p95_ms": None, "max_ms": None, "count": len(timestamps_ns)}
    ordered = sorted(gaps_ms)
    p95_index = max(0, (95 * len(ordered) + 99) // 100 - 1)
    return {
        "p95_ms": ordered[p95_index],
        "max_ms": max(gaps_ms),
        "count": len(timestamps_ns),
    }


def init_authority(case, rows):
    lab.compose("up", "-d", "krill", "labrepo")

    def tal():
        result = lab.compose(
            "exec", "-T", "krill", "wget", "-qO-", "--no-check-certificate",
            "https://127.0.0.1:3000/ta/ta.tal", check=False,
        )
        return result.stdout if not result.returncode else None

    raw_tal = await_value("Krill test trust anchor", tal)
    _, public_key = raw_tal.strip().split("\n\n", 1)
    (case / "tals" / "lab.tal").write_text(
        "rsync://labrepo/ta/ta.cer\n\n" + public_key + "\n", encoding="ascii", newline="\n"
    )
    lab.compose(
        "exec", "-T", "krill", "sh", "-ec",
        "mkdir -p /var/krill/data/ta-export; "
        "wget -q --no-check-certificate -O /var/krill/data/ta-export/ta.cer "
        "https://127.0.0.1:3000/ta/ta.cer; chmod 644 /var/krill/data/ta-export/ta.cer",
    )
    lab.compose("cp", "labrepo:/rpki/ta-export/ta.cer", str(case / "ta.cer"))
    return publish(case, rows, lab.AS_A)


def capture(case):
    lab.compose("stop", "-t", "2", "rtr-capture")
    lab.compose("cp", "rtr-capture:/tmp/rtr.pcap", str(case / "rtr.pcap"))
    return case / "rtr.pcap"


def read_packets(path):
    with path.open("rb") as stream:
        header = stream.read(24)
        formats = {
            b"\xd4\xc3\xb2\xa1": ("<", 1_000), b"\xa1\xb2\xc3\xd4": (">", 1_000),
            b"\x4d\x3c\xb2\xa1": ("<", 1), b"\xa1\xb2\x3c\x4d": (">", 1),
        }
        if header[:4] not in formats:
            raise ValueError("Unsupported or empty RTR capture")
        order, fraction_ns = formats[header[:4]]
        if struct.unpack_from(order + "I", header, 20)[0] & 0xFFFF != 1:
            raise ValueError("RTR capture must use Ethernet framing")
        while record := stream.read(16):
            second, fraction, size, _ = struct.unpack(order + "IIII", record)
            frame = stream.read(size)
            ip = frame[14:]
            if frame[12:14] != b"\x08\x00" or len(ip) < 40 or ip[9] != 6:
                continue
            tcp = ip[(ip[0] & 15) * 4 : int.from_bytes(ip[2:4], "big")]
            if len(tcp) < 20:
                continue
            source_port, destination_port, sequence = struct.unpack_from("!HHI", tcp)
            yield (
                second * 1_000_000_000 + fraction * fraction_ns, ip[12:16], ip[16:20],
                source_port, destination_port, tcp[13], sequence, tcp[(tcp[12] >> 4) * 4 :],
            )


def verify_packets(path, requested):
    cut = reset = client_port = next_sequence = None
    buffered = b""
    backup_vrps = []
    for stamp, source, destination, src_port, dst_port, flags, sequence, payload in read_packets(path):
        if stamp < requested:
            continue
        if cut is None and (source, destination, src_port) == (PRIMARY_IP, DUT_IP, 3323) and flags & 5:
            cut = stamp
        if cut is None:
            continue
        if reset is None and (source, destination, dst_port) == (DUT_IP, BACKUP_IP, 3323):
            if len(payload) == 8 and payload[1] == 2 and int.from_bytes(payload[4:], "big") == 8:
                reset, client_port = stamp, src_port
        if reset is None or (source, destination, src_port, dst_port) != (
            BACKUP_IP, DUT_IP, 3323, client_port,
        ) or not payload:
            continue
        if next_sequence is None:
            next_sequence = sequence
        if sequence > next_sequence:
            raise ValueError("Gap in captured backup RTR response")
        buffered += payload[next_sequence - sequence :]
        next_sequence = max(next_sequence, sequence + len(payload))
        while len(buffered) >= 8:
            length = int.from_bytes(buffered[4:8], "big")
            if length < 8:
                raise ValueError("Malformed RTR PDU in capture")
            if len(buffered) < length:
                break
            pdu = buffered[:length]
            if pdu[1] == 4:
                prefix_vrp = parse_ipv4_prefix_pdu(pdu)
                if prefix_vrp is None:
                    raise ValueError("Malformed IPv4 Prefix PDU in backup RTR response")
                backup_vrps.append(prefix_vrp)
            if buffered[1] == 7 and length in (12, 24):
                return cut, reset, stamp, backup_vrps
            buffered = buffered[length:]
    raise RuntimeError("Packet capture did not verify primary closure and backup Reset Query/End of Data")


def parse_ipv4_prefix_pdu(pdu):
    if (
        len(pdu) != 20
        or pdu[0] != 1
        or pdu[1] != 4
        or int.from_bytes(pdu[4:8], "big") != 20
    ):
        return None
    prefix_length = pdu[9]
    max_length = pdu[10]
    if prefix_length > max_length or max_length > 32:
        return None
    return {
        "prefix": f"{IPv4Address(pdu[12:16])}/{prefix_length}",
        "flags": pdu[8],
        "max_length": max_length,
        "origin": int.from_bytes(pdu[16:20], "big"),
    }


def verify_uninterrupted_packets(path, requested, completed):
    primary_closures = 0
    backup_reset_queries = 0
    primary_packets = 0
    for stamp, source, destination, _src_port, dst_port, flags, _sequence, payload in read_packets(path):
        if not requested <= stamp <= completed:
            continue
        if (source, destination, dst_port) == (PRIMARY_IP, DUT_IP, 3323):
            primary_packets += 1
            primary_closures += bool(flags & 5)
        if (source, destination, dst_port) == (DUT_IP, BACKUP_IP, 3323):
            backup_reset_queries += bool(
                len(payload) == 8 and payload[1] == 2
                and int.from_bytes(payload[4:8], "big") == 8
            )
    if primary_closures or backup_reset_queries:
        raise RuntimeError(
            "uninterrupted-RTR PCAP contains a primary close or backup Reset Query"
        )
    return {
        "primary_packets_in_interval": primary_packets,
        "primary_closures": primary_closures,
        "backup_reset_queries": backup_reset_queries,
    }


def configure_prefix_case(case, prefix_count):
    copy_lab(case, prefix_count)
    if prefix_count == 2:
        for router in ("as-a", "as-b"):
            path = case / "frr" / f"{router}.conf"
            config = path.read_text(encoding="utf-8")
            lo_address = " ip address 198.18.0.10/32\n"
            if config.count(lo_address) != 1:
                raise RuntimeError(f"Could not add the second service address to {path.name}")
            path.write_text(
                config.replace(
                    lo_address,
                    lo_address + " ip address 198.18.1.10/32\n",
                ),
                encoding="utf-8",
                newline="\n",
            )
    dut = case / "frr" / "dut.conf"
    config = dut.read_text(encoding="utf-8")
    default_policy = "neighbor 198.18.2.11 route-map ROV-IN in"
    if config.count(default_policy) != 1:
        raise RuntimeError("Could not set the controlled AS-A inbound policy")
    config = config.replace(default_policy, default_policy.replace("ROV-IN", "ROV-PREFER-A"))
    config += (
        "\nroute-map ROV-PREFER-A deny 10\n match rpki invalid\n"
        "route-map ROV-PREFER-A permit 20\n set local-preference 200\n"
    )
    dut.write_text(config, encoding="utf-8", newline="\n")


def probe_services_by_prefix():
    return lab.last_probe_services_by_prefix()


def initial_state_is_as_a(sample):
    return (
        sample is not None
        and sample["bgp_sessions_established"]
        and sample["cache_connected_primary"] is True
        and sample["cache_connected_backup"] is False
        and all(
            state["installed_vrp_origins"] == [lab.AS_A]
            and state["accepted_asns"] == [lab.AS_A]
            and state["selected_rib_as"] == lab.AS_A
            and state["selected_fib_as"] == lab.AS_A
            for state in sample["state_by_prefix"].values()
        )
    )


def stale_state_is_installed(sample):
    return (
        sample is not None
        and sample["bgp_sessions_established"]
        and all(
            lab.AS_A in state["installed_vrp_origins"]
            and state["rov_by_asn"].get(str(lab.AS_A)) == "valid"
            for state in sample["state_by_prefix"].values()
        )
    )


def baseline_sample_if_valid(sample, probe_services, prefixes):
    if (
        sample is None
        or sample["cache_connected_primary"] is not True
        or sample["cache_connected_backup"] is not False
        or not lab.expected_new_state(sample)
        or not all(
            state["rov_by_asn"].get(str(lab.AS_A)) == "invalid"
            and state["rov_by_asn"].get(str(lab.AS_B)) == "valid"
            and lab.AS_A not in state["accepted_asns"]
            and state["selected_rib_as"] == lab.AS_B
            and state["selected_fib_as"] == lab.AS_B
            for state in sample["state_by_prefix"].values()
        )
        or not all(probe_services.get(prefix) == "AS-B" for prefix in prefixes)
    ):
        return None
    return sample


def run_trial(case, stale, hold_seconds):
    rows = []
    probes = []
    case.mkdir()
    copy_lab(case, 1)
    shutil.copytree(ROOT / "signed-rpki", case / "signed-rpki")
    (case / "tals").mkdir()
    dut = case / "frr" / "dut.conf"
    config = dut.read_text(encoding="utf-8").replace(
        "neighbor 198.18.2.11 route-map ROV-IN in",
        "neighbor 198.18.2.11 route-map ROV-PREFER-A in",
    )
    dut.write_text(
        config + "\nroute-map ROV-PREFER-A deny 10\n match rpki invalid\n"
        "route-map ROV-PREFER-A permit 20\n set local-preference 200\n",
        encoding="utf-8", newline="\n",
    )
    lab.ROOT = case
    monitor = None
    result = {"case": case.name, "backup": "stale" if stale else "current", "valid": False}

    try:
        lab.compose("build", timeout=600)
        first_roa = init_authority(case, rows)
        lab.compose("up", "-d", timeout=180)
        for service in (lab.RTR_PRIMARY, lab.RTR_BACKUP):
            verify_validator(rows, service, lab.AS_A)
        lab.container_json("client", 8080, "/start", {"interval_ms": 100, "timeout_s": 0.4})
        monitor = lab.SnapshotMonitor(rows)
        monitor.start()
        lab.ACTIVE_SNAPSHOT_MONITOR = monitor
        lab.ensure_bgp_and_initial_state(rows)

        publish(
            case, rows, lab.AS_B, previous=lab.AS_A, previous_hashes=first_roa
        )
        verify_validator(rows, lab.RTR_PRIMARY, lab.AS_B, refresh=True)
        verify_validator(rows, lab.RTR_BACKUP, lab.AS_A if stale else lab.AS_B, refresh=not stale)

        def baseline():
            sample = lab.snapshot()
            return (sample and sample["cache_connected_primary"] and not sample["cache_connected_backup"]
                    and lab.expected_new_state(sample) and lab.last_probe_service() == "AS-B")

        await_value("AS-B alone in the routing and forwarding tables and reachable over HTTP", baseline)
        lab.log_event(rows, "as_b_baseline_verified")
        requested = lab.now_ns()
        lab.compose("stop", "-t", "2", lab.RTR_PRIMARY)
        lab.log_event(rows, "primary_stop_completed", requested_ns=requested)

        def failover():
            sample = lab.snapshot()
            if not sample or sample["cache_connected_primary"] or not sample["cache_connected_backup"]:
                return None
            verify_vrp = lab.expected_stale_backup_data if stale else lab.expected_as_b_vrp_state
            return sample if verify_vrp(sample) else None

        handoff = await_value("Routinator backup session and its expected VRPs in FRR", failover)
        lab.log_event(rows, "backup_in_use", sample_ns=handoff["timestamp_ns"])
        time.sleep(hold_seconds)
        exposure_end = lab.now_ns()
        lab.log_event(rows, "backup_exposure_completed", exposure_end_ns=exposure_end)
        verify_validator(rows, lab.RTR_BACKUP, lab.AS_A if stale else lab.AS_B)
        if stale:
            verify_validator(rows, lab.RTR_BACKUP, lab.AS_B, refresh=True)
        await_value("AS-B after the exposure window", lambda: lab.expected_new_state(lab.snapshot())
                    and lab.last_probe_service() == "AS-B")
        lab.log_event(rows, "as_b_final_verified")
        lab.container_json("client", 8080, "/stop", {})
        probes = lab.probe_events()
        cut, reset, eod, backup_vrps = verify_packets(capture(case), requested)
        pre = [probe for probe in probes if requested - 1_000_000_000 <= probe["started_ns"]
               and probe["finished_ns"] <= cut]
        during = [probe for probe in probes if cut <= probe["started_ns"] < exposure_end]
        samples = [row for row in rows if row["type"] == "snapshot"
                   and cut <= row["timestamp_ns"] < exposure_end]
        if not pre or any(probe["service"] != "AS-B" or probe.get("status") != 200 for probe in pre):
            raise RuntimeError("HTTP baseline immediately before the cut was not continuously AS-B")
        if not during or not samples or not all(row["bgp_sessions_established"] for row in samples):
            raise RuntimeError("Missing active probes or continuous BGP evidence")
        reached_a = [probe for probe in during if probe["service"] == "AS-A" and probe.get("status") == 200]
        timeline_metrics = measure_timeline(rows, probes, cut, exposure_end)
        result.update(
            valid=True, cut_ns=cut, reset_query_ns=reset, end_of_data_ns=eod,
            backup_rtr_vrps=backup_vrps,
            exposure_end_ns=exposure_end, as_a_accepted=any(row["accepted_as_a"] for row in samples),
            as_a_selected=any(row["selected_rib_as"] == row["selected_fib_as"] == lab.AS_A
                              for row in samples),
            http_as_a=len(reached_a),
            http_as_b=sum(probe["service"] == "AS-B" and probe.get("status") == 200 for probe in during),
            other_probes=sum(probe.get("status") != 200 or probe["service"] not in ("AS-A", "AS-B")
                             for probe in during),
            first_as_a_after_cut_ms=(reached_a[0]["started_ns"] - cut) / 1e6 if reached_a else None,
        )
        result.update(timeline_metrics)
    except (RuntimeError, OSError, ValueError, KeyError, struct.error) as exc:
        result["invalid_reason"] = str(exc)
    finally:
        if monitor is not None:
            monitor.stop()
        lab.ACTIVE_SNAPSHOT_MONITOR = None
        log = lab.compose("logs", "--no-color", "--timestamps", check=False)
        (case / "containers.log").write_text(log.stdout + log.stderr, encoding="utf-8")
        if not probes:
            try:
                probes = lab.probe_events()
            except (RuntimeError, ValueError):
                pass
        try:
            lab.compose("down", "--volumes", "--remove-orphans", check=False)
        except Exception as exc:
            if not result["invalid_reason"]:
                result["invalid_reason"] = (
                    f"compose cleanup: {type(exc).__name__}: {exc}"
                )
        evidence = sorted(rows + probes, key=lambda row: row.get("timestamp_ns", row.get("started_ns")))
        (case / "evidence.jsonl").write_text(
            "".join(json.dumps(row) + "\n" for row in evidence), encoding="utf-8"
        )
        (case / "outcome.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def run_matrix_trial(case, scenario, prefix_count, repetition, hold_seconds, post_update_seconds):
    rows = []
    probes = []
    monitor = None
    client_started = False
    capture_started = False
    phase = {}
    result = {
        "case": case.name,
        "scenario": scenario,
        "prefix_count": prefix_count,
        "prefixes": list(lab.ALL_PREFIXES[:prefix_count]),
        "repetition": repetition,
        "scenario_valid": False,
        "failover_verified": False,
        "invalid_reason": "",
    }

    lab.PREFIX_COUNT = prefix_count
    lab.PREFIXES = lab.ALL_PREFIXES[:prefix_count]
    lab.ROOT = case
    os.environ["ROV_PREFIX_COUNT"] = str(prefix_count)
    case.mkdir()

    try:
        configure_prefix_case(case, prefix_count)
        shutil.copytree(ROOT / "signed-rpki", case / "signed-rpki")
        (case / "tals").mkdir()
        lab.compose("down", "--volumes", "--remove-orphans", timeout=60)
        lab.compose("build", timeout=600)
        first_hashes = init_authority(case, rows)
        lab.compose("up", "-d", timeout=180)
        capture_started = True
        for service in (lab.RTR_PRIMARY, lab.RTR_BACKUP):
            verify_validator(rows, service, lab.AS_A)

        lab.container_json(
            "client",
            8080,
            "/start",
            {"interval_ms": lab.PROBE_INTERVAL_MS, "timeout_s": 0.4},
        )
        client_started = True
        monitor = lab.SnapshotMonitor(rows)
        monitor.start()
        lab.ACTIVE_SNAPSHOT_MONITOR = monitor
        await_value(
            "initial AS-A routing and HTTP service for every prefix",
            lambda: initial_state_is_as_a(lab.snapshot())
            and all(
                probe_services_by_prefix().get(prefix) == "AS-A"
                for prefix in lab.PREFIXES
            ),
        )
        lab.log_event(
            rows,
            "initial_as_a_state_verified",
            state_by_prefix=lab.snapshot()["state_by_prefix"],
        )

        primary_hashes = publish(
            case,
            rows,
            lab.AS_B,
            previous=lab.AS_A,
            previous_hashes=first_hashes,
        )
        verify_validator(rows, lab.RTR_PRIMARY, lab.AS_B, refresh=True)
        if scenario == "updated-backup":
            phase["backup_update_requested_ns"] = lab.now_ns()
            lab.log_event(
                rows,
                "backup_update_requested",
                requested_ns=phase["backup_update_requested_ns"],
                origin=lab.AS_B,
                trigger="SIGUSR1",
                stage="before-primary-cut",
            )
            verify_validator(rows, lab.RTR_BACKUP, lab.AS_B, refresh=True)
        else:
            verify_validator(rows, lab.RTR_BACKUP, lab.AS_A)

        def baseline():
            sample = lab.snapshot()
            return baseline_sample_if_valid(
                sample,
                probe_services_by_prefix(),
                lab.PREFIXES,
            )

        baseline_sample = await_value(
            "AS-B reachability, AS-A Invalid rejection, and BGP/RIB/FIB baseline",
            baseline,
        )
        phase["baseline_ns"] = baseline_sample["timestamp_ns"]
        phase["baseline_state_by_prefix"] = baseline_sample["state_by_prefix"]
        update_request = next(
            (
                row for row in rows
                if row.get("event") == "signed_roa_update_requested"
                and row.get("origin") == lab.AS_B
            ),
            None,
        )
        primary_installed = next(
            (
                row for row in sorted(
                    (entry for entry in rows if entry.get("type") == "snapshot"),
                    key=lambda entry: entry["timestamp_ns"],
                )
                if row["timestamp_ns"] >= (update_request or {}).get("timestamp_ns", 0)
                and all(
                    state["installed_vrp_origins"] == [lab.AS_B]
                    and state["rov_by_asn"] == {
                        str(lab.AS_A): "invalid",
                        str(lab.AS_B): "valid",
                    }
                    and lab.AS_A not in state["accepted_asns"]
                    and state["selected_rib_as"] == lab.AS_B
                    and state["selected_fib_as"] == lab.AS_B
                    for state in row["state_by_prefix"].values()
                )
            ),
            baseline_sample,
        )
        phase["primary_update_requested_ns"] = (
            update_request["timestamp_ns"] if update_request else None
        )
        phase["primary_vrp_installed_ns"] = primary_installed["timestamp_ns"]
        phase["primary_validator_verified_ns"] = next(
            (
                row["timestamp_ns"] for row in rows
                if row.get("event") == "validator_vrps_verified"
                and row.get("validator") == lab.RTR_PRIMARY
                and row.get("origin") == lab.AS_B
            ),
            None,
        )
        lab.log_event(
            rows,
            "as_b_baseline_verified",
            state_by_prefix=baseline_sample["state_by_prefix"],
            probe_services_by_prefix=probe_services_by_prefix(),
            backup_scenario=scenario,
        )

        transition_request_ns = None
        if scenario in ("stale-backup", "updated-backup"):
            transition_request_ns = lab.now_ns()
            lab.log_event(
                rows,
                "primary_stop_requested",
                requested_ns=transition_request_ns,
            )
            lab.compose("stop", "-t", "2", lab.RTR_PRIMARY)
            lab.log_event(rows, "primary_stop_completed")

            def backup_in_use():
                sample = lab.snapshot()
                if (
                    sample is None
                    or sample["cache_connected_primary"] is not False
                    or sample["cache_connected_backup"] is not True
                    or not sample["bgp_sessions_established"]
                ):
                    return None
                if scenario == "stale-backup":
                    return sample if stale_state_is_installed(sample) else None
                return sample if lab.expected_as_b_vrp_state(sample) else None

            handoff = await_value(
                "FRR using the expected Routinator standby data",
                backup_in_use,
            )
            phase["failover_verified"] = True
            phase["backup_in_use_ns"] = handoff["timestamp_ns"]
            phase["exposure_start_ns"] = handoff["timestamp_ns"]
            phase["backup_in_use_state_by_prefix"] = handoff["state_by_prefix"]
            lab.log_event(
                rows,
                "backup_in_use_verified",
                state_by_prefix=handoff["state_by_prefix"],
                connected_cache_group=handoff["connected_cache_group"],
            )
        else:
            control_sample = lab.snapshot()
            if (
                control_sample is None
                or control_sample["cache_connected_primary"] is not True
                or control_sample["cache_connected_backup"] is not False
                or not lab.expected_new_state(control_sample)
            ):
                raise RuntimeError(
                    "uninterrupted-RTR control did not retain the primary AS-B state"
                )
            phase["exposure_start_ns"] = lab.now_ns()
            lab.log_event(
                rows,
                "uninterrupted_exposure_started",
                state_by_prefix=control_sample["state_by_prefix"],
            )

        time.sleep(hold_seconds)
        phase["exposure_end_ns"] = lab.now_ns()
        lab.log_event(
            rows,
            "backup_exposure_completed",
            exposure_start_ns=phase["exposure_start_ns"],
            exposure_end_ns=phase["exposure_end_ns"],
            requested_hold_seconds=hold_seconds,
        )

        if scenario in ("stale-backup", "no-rtr-outage"):
            phase["backup_update_requested_ns"] = lab.now_ns()
            lab.log_event(
                rows,
                "backup_update_requested",
                requested_ns=phase["backup_update_requested_ns"],
                origin=lab.AS_B,
                trigger="SIGUSR1",
                stage="after-exposure",
            )
            verify_validator(rows, lab.RTR_BACKUP, lab.AS_B, refresh=True)

        def restored():
            sample = lab.snapshot()
            if sample is None or not lab.expected_new_state(sample):
                return None
            if scenario == "no-rtr-outage":
                if (
                    sample["cache_connected_primary"] is not True
                    or sample["cache_connected_backup"] is not False
                ):
                    return None
            elif (
                sample["cache_connected_primary"] is not False
                or sample["cache_connected_backup"] is not True
            ):
                return None
            if not all(
                probe_services_by_prefix().get(prefix) == "AS-B"
                for prefix in lab.PREFIXES
            ):
                return None
            return sample

        restored_sample = await_value(
            "AS-B RIB/FIB and HTTP service for every prefix after the scenario",
            restored,
        )
        phase["as_b_final_verified_ns"] = lab.now_ns()
        phase["as_b_final_state_by_prefix"] = restored_sample["state_by_prefix"]
        lab.log_event(
            rows,
            "as_b_final_verified",
            state_by_prefix=restored_sample["state_by_prefix"],
            probe_services_by_prefix=probe_services_by_prefix(),
        )
        time.sleep(post_update_seconds)
        phase["measurement_end_ns"] = lab.now_ns()
        lab.log_event(
            rows,
            "post_update_observation_completed",
            measurement_end_ns=phase["measurement_end_ns"],
            requested_seconds=post_update_seconds,
        )
    except Exception as exc:
        result["invalid_reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        if monitor is not None:
            try:
                monitor.stop()
            except Exception as exc:
                if not result["invalid_reason"]:
                    result["invalid_reason"] = f"snapshot monitor: {type(exc).__name__}: {exc}"
        lab.ACTIVE_SNAPSHOT_MONITOR = None
        if client_started:
            try:
                lab.container_json("client", 8080, "/stop", {})
                probes = lab.probe_events()
            except Exception as exc:
                if not result["invalid_reason"]:
                    result["invalid_reason"] = f"probe collection: {type(exc).__name__}: {exc}"

        if capture_started:
            try:
                capture(case)
            except Exception as exc:
                if not result["invalid_reason"]:
                    result["invalid_reason"] = f"RTR PCAP capture: {type(exc).__name__}: {exc}"
        try:
            logs = lab.compose(
                "logs", "--no-color", "--timestamps", check=False, timeout=30
            )
            (case / "containers.log").write_text(
                logs.stdout + logs.stderr,
                encoding="utf-8",
            )
        except Exception as exc:
            if not result["invalid_reason"]:
                result["invalid_reason"] = f"container logs: {type(exc).__name__}: {exc}"

        if not result["invalid_reason"]:
            try:
                required_prefixes = set(lab.PREFIXES)
                if scenario in ("stale-backup", "updated-backup"):
                    cut_ns, reset_ns, eod_ns, backup_vrps = verify_packets(
                        case / "rtr.pcap", transition_request_ns
                    )
                    expected_origin = (
                        lab.AS_A if scenario == "stale-backup" else lab.AS_B
                    )
                    expected_backup_vrps = {
                        (prefix, expected_origin) for prefix in lab.PREFIXES
                    }
                    observed_backup_vrps = {
                        (vrp["prefix"], vrp["origin"])
                        for vrp in backup_vrps
                        if vrp["flags"] == 1
                    }
                    result["backup_rtr_vrps"] = backup_vrps
                    result["backup_vrp_check_passed"] = (
                        expected_backup_vrps <= observed_backup_vrps
                    )
                    if not result["backup_vrp_check_passed"]:
                        raise RuntimeError(
                            "backup RTR response did not contain the expected VRP for every prefix"
                        )
                    result.update(
                        cut_ns=cut_ns,
                        reset_query_ns=reset_ns,
                        end_of_data_ns=eod_ns,
                        failover_verified=True,
                    )
                    evidence_start_ns = cut_ns
                else:
                    evidence_start_ns = phase["exposure_start_ns"]
                    result["uninterrupted_rtr_pcap"] = verify_uninterrupted_packets(
                        case / "rtr.pcap",
                        evidence_start_ns,
                        phase["measurement_end_ns"],
                    )
                    result["failover_verified"] = False

                exposure_start_ns = phase["exposure_start_ns"]
                exposure_end_ns = phase["exposure_end_ns"]
                baseline_cut_ns = result.get("cut_ns", exposure_start_ns)
                pre_probes = [
                    probe for probe in probes
                    if baseline_cut_ns - 1_000_000_000
                    <= probe["started_ns"]
                    and probe["finished_ns"] <= baseline_cut_ns
                    and probe.get("status") == 200
                ]
                last_pre_by_prefix = {}
                for probe in pre_probes:
                    if probe.get("prefix") in required_prefixes:
                        previous_probe = last_pre_by_prefix.get(probe["prefix"])
                        if previous_probe is None or probe["started_ns"] > previous_probe["started_ns"]:
                            last_pre_by_prefix[probe["prefix"]] = probe
                if set(last_pre_by_prefix) != required_prefixes or any(
                    probe.get("service") != "AS-B"
                    for probe in last_pre_by_prefix.values()
                ):
                    raise RuntimeError(
                        "AS-B HTTP baseline was not proven for each prefix immediately before the transition"
                    )

                exposure_probes = [
                    probe for probe in probes
                    if exposure_start_ns <= probe["started_ns"] < exposure_end_ns
                ]
                if any(
                    not any(probe.get("prefix") == prefix for probe in exposure_probes)
                    for prefix in lab.PREFIXES
                ):
                    raise RuntimeError("no HTTP probe for every prefix during exposure")
                exposure_samples = [
                    row for row in rows
                    if row.get("type") == "snapshot"
                    and exposure_start_ns <= row["timestamp_ns"] < exposure_end_ns
                ]
                if not exposure_samples or not all(
                    row["bgp_sessions_established"] for row in exposure_samples
                ):
                    raise RuntimeError("BGP sessions were not continuously observed during exposure")
                if scenario == "stale-backup" and not any(
                    all(
                        lab.AS_A in state["installed_vrp_origins"]
                        and state["rov_by_asn"].get(str(lab.AS_A)) == "valid"
                        for state in row["state_by_prefix"].values()
                    )
                    for row in exposure_samples
                ):
                    raise RuntimeError("stale signed AS-A VRPs were not observed in FRR")
                if scenario == "updated-backup" and not any(
                    all(
                        state["installed_vrp_origins"] == [lab.AS_B]
                        for state in row["state_by_prefix"].values()
                    )
                    for row in exposure_samples
                ):
                    raise RuntimeError("updated signed AS-B VRPs were not observed in FRR")
                if scenario == "no-rtr-outage" and not all(
                    row["cache_connected_primary"] is True
                    and row["cache_connected_backup"] is False
                    for row in exposure_samples
                ):
                    raise RuntimeError("the primary RTR session did not remain active in control")

                after_update_start_ns = phase.get(
                    "backup_update_requested_ns", exposure_end_ns
                )
                trailing_probes = [
                    probe for probe in probes
                    if probe["started_ns"] >= phase["as_b_final_verified_ns"]
                ]
                if any(
                    not any(
                        probe.get("prefix") == prefix
                        and probe.get("service") == "AS-B"
                        and probe.get("status") == 200
                        for probe in trailing_probes
                    )
                    for prefix in lab.PREFIXES
                ):
                    raise RuntimeError("post-update AS-B HTTP reachability was not sustained per prefix")

                by_prefix = {}
                for prefix in lab.PREFIXES:
                    prefix_probes = [
                        probe for probe in probes
                        if probe.get("prefix") == prefix
                    ]
                    exposure_prefix_probes = [
                        probe for probe in exposure_probes
                        if probe.get("prefix") == prefix
                    ]
                    timeline_start_ns = result.get("cut_ns", exposure_start_ns)
                    timeline = measure_timeline(
                        rows,
                        prefix_probes,
                        timeline_start_ns,
                        exposure_end_ns,
                        prefix=prefix,
                    )
                    timeline["cut_to_exposure_end_ms"] = timeline["exposure_duration_ms"]
                    timeline["exposure_duration_ms"] = (
                        exposure_end_ns - exposure_start_ns
                    ) / 1_000_000
                    sampling_snapshots = [
                        row for row in rows
                        if row.get("type") == "snapshot"
                        and exposure_start_ns <= row["timestamp_ns"] < exposure_end_ns
                    ]
                    probe_intervals = interval_summary(
                        [probe["started_ns"] for probe in exposure_prefix_probes]
                    )
                    snapshot_intervals = interval_summary(
                        [row["timestamp_ns"] for row in sampling_snapshots]
                    )
                    first_http_b_after_update = next(
                        (
                            probe for probe in prefix_probes
                            if probe["started_ns"] >= after_update_start_ns
                            and probe.get("service") == "AS-B"
                            and probe.get("status") == 200
                        ),
                        None,
                    )
                    first_fib_b_after_update = next(
                        (
                            row for row in rows
                            if row.get("type") == "snapshot"
                            and row["timestamp_ns"] >= after_update_start_ns
                            and row.get("state_by_prefix", {}).get(prefix, {}).get("selected_fib_as") == lab.AS_B
                        ),
                        None,
                    )
                    by_prefix[prefix] = {
                        **timeline,
                        "http_as_a_during_exposure": sum(
                            probe.get("service") == "AS-A"
                            and probe.get("status") == 200
                            for probe in exposure_prefix_probes
                        ),
                        "http_as_b_during_exposure": sum(
                            probe.get("service") == "AS-B"
                            and probe.get("status") == 200
                            for probe in exposure_prefix_probes
                        ),
                        "other_probe_count_during_exposure": sum(
                            probe.get("status") != 200
                            or probe.get("service") not in ("AS-A", "AS-B")
                            for probe in exposure_prefix_probes
                        ),
                        "probe_count_during_exposure": len(exposure_prefix_probes),
                        "probe_gap_p95_ms_during_exposure": probe_intervals["p95_ms"],
                        "probe_gap_max_ms_during_exposure": probe_intervals["max_ms"],
                        "snapshot_count_during_exposure": len(sampling_snapshots),
                        "snapshot_gap_p95_ms_during_exposure": snapshot_intervals["p95_ms"],
                        "snapshot_gap_max_ms_during_exposure": snapshot_intervals["max_ms"],
                        "first_as_b_after_backup_update_ms": (
                            (first_http_b_after_update["started_ns"] - after_update_start_ns) / 1_000_000
                            if first_http_b_after_update else None
                        ),
                        "first_fib_as_b_after_backup_update_ms": (
                            (first_fib_b_after_update["timestamp_ns"] - after_update_start_ns) / 1_000_000
                            if first_fib_b_after_update else None
                        ),
                    }

                result.update(
                    exposure_start_ns=exposure_start_ns,
                    exposure_end_ns=exposure_end_ns,
                    exposure_duration_ms=(exposure_end_ns - exposure_start_ns) / 1_000_000,
                    primary_update_requested_ns=phase.get("primary_update_requested_ns"),
                    primary_vrp_installed_ns=phase.get("primary_vrp_installed_ns"),
                    primary_validator_verified_ns=phase.get(
                        "primary_validator_verified_ns"
                    ),
                    transition_request_ns=transition_request_ns,
                    backup_update_requested_ns=phase.get("backup_update_requested_ns"),
                    baseline_state_by_prefix=phase.get("baseline_state_by_prefix"),
                    as_b_final_state_by_prefix=phase.get("as_b_final_state_by_prefix"),
                    as_b_final_verified_ns=phase.get("as_b_final_verified_ns"),
                    measurement_end_ns=phase.get("measurement_end_ns"),
                    per_prefix=by_prefix,
                    total_http_as_a_during_exposure=sum(
                        data["http_as_a_during_exposure"] for data in by_prefix.values()
                    ),
                    total_http_as_b_during_exposure=sum(
                        data["http_as_b_during_exposure"] for data in by_prefix.values()
                    ),
                    total_other_probes_during_exposure=sum(
                        data["other_probe_count_during_exposure"] for data in by_prefix.values()
                    ),
                    total_probe_count=len(probes),
                    scenario_valid=True,
                )
            except Exception as exc:
                result["scenario_valid"] = False
                result["invalid_reason"] = f"{type(exc).__name__}: {exc}"

        try:
            lab.compose("down", "--volumes", "--remove-orphans", check=False)
        except Exception as exc:
            if not result["invalid_reason"]:
                result["invalid_reason"] = (
                    f"compose cleanup: {type(exc).__name__}: {exc}"
                )
        result["failover_verified"] = bool(
            result.get("failover_verified")
            and result.get("backup_vrp_check_passed")
            and result.get("reset_query_ns")
            and result.get("end_of_data_ns")
        )
        result["attempt"] = 1
        evidence = sorted(
            rows + probes,
            key=lambda row: row.get("timestamp_ns", row.get("started_ns", 0)),
        )
        (case / "evidence.jsonl").write_text(
            "".join(json.dumps(row, sort_keys=True) + "\n" for row in evidence),
            encoding="utf-8",
        )
        (case / "outcome.json").write_text(
            json.dumps(result, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def save_matrix_summary(batch, results):
    columns = list(dict.fromkeys(key for result in results for key in result))
    with (batch / "matrix_summary.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for result in results:
            writer.writerow(
                {
                    key: json.dumps(value, sort_keys=True)
                    if isinstance(value, (dict, list))
                    else value
                    for key, value in result.items()
                }
            )


def run_final_matrix(args, preparation):
    if args.repetitions != 3:
        raise ValueError("the final matrix is fixed at three repetitions per condition")
    if not 1 <= args.post_update_seconds <= 60:
        raise ValueError("post-update observation must be from 1 to 60 seconds")

    router_id = image_id(PATCHED_IMAGE)
    if router_id != preparation["patched_image_id"]:
        raise ValueError("the patched FRR image changed after preparation")
    ca_id = image_id(CA_IMAGE)
    rp_id = image_id(RP_IMAGE)
    peer_id = image_id("quay.io/frrouting/frr:10.4.1")
    probe_id = image_id("python:3.12-alpine")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    batch = ROOT / "results" / f"final-roa-handoff-matrix-{stamp}"
    batch.mkdir(parents=True, exist_ok=False)
    os.environ.update(
        ROV_DUT_IMAGE=PATCHED_IMAGE,
        ROV_COMPOSE_PROJECT=f"rov-final-{stamp.lower()}",
        ROV_COMPOSE_OVERLAY="signed-rpki/compose.yaml",
        SIGNED_CA_IMAGE=CA_IMAGE,
        SIGNED_RP_IMAGE=RP_IMAGE,
        SIGNED_CA_TOKEN=secrets.token_hex(24),
    )

    scenario_orders = (
        ("stale-backup", "updated-backup", "no-rtr-outage"),
        ("updated-backup", "no-rtr-outage", "stale-backup"),
        ("no-rtr-outage", "stale-backup", "updated-backup"),
    )
    schedule = []
    for repetition in range(1, args.repetitions + 1):
        prefix_order = (1, 2) if repetition % 2 else (2, 1)
        for prefix_count in prefix_order:
            order_index = (repetition - 1 + prefix_count - 1) % len(scenario_orders)
            for scenario in scenario_orders[order_index]:
                schedule.append(
                    {
                        "scenario": scenario,
                        "prefix_count": prefix_count,
                        "repetition": repetition,
                        "case": f"p{prefix_count}-{scenario}-r{repetition:02d}",
                    }
                )

    source_files = (
        "run_signed_roa.py",
        "run_lab.py",
        "run_pr24131_comparison.py",
        "client_agent.py",
        "app_server.py",
        "rtr_server.py",
        "compose.yaml",
        "Dockerfile",
        "frr/daemons",
        "frr/dut.conf",
        "frr/as-a.conf",
        "frr/as-b.conf",
        "signed-rpki/compose.yaml",
        "signed-rpki/Dockerfile",
        "signed-rpki/krill.conf",
        "signed-rpki/rsyncd.conf",
    )
    manifest = {
        "run_id": stamp,
        "planned_runs": len(schedule),
        "completed_runs": 0,
        "repetitions_per_condition": args.repetitions,
        "hold_seconds_requested": args.hold_seconds,
        "post_update_observation_seconds": args.post_update_seconds,
        "prefixes": list(lab.ALL_PREFIXES),
        "scenarios": [
            "stale-backup",
            "updated-backup",
            "no-rtr-outage",
        ],
        "scenario_order": schedule,
        "frr_dut_image": PATCHED_IMAGE,
        "frr_dut_image_id": router_id,
        "frr_pr": 24131,
        "frr_base_commit": preparation["base_commit"],
        "frr_patched_commit": preparation["patched_commit"],
        "frr_peer_image": "quay.io/frrouting/frr:10.4.1",
        "frr_peer_image_id": peer_id,
        "krill_image": CA_IMAGE,
        "krill_image_id": ca_id,
        "routinator_image": RP_IMAGE,
        "routinator_image_id": rp_id,
        "probe_image": "python:3.12-alpine",
        "probe_image_id": probe_id,
        "host_python_version": sys.version,
        "host_platform": sys.platform,
        "as_numbers": {"as_a": lab.AS_A, "as_b": lab.AS_B, "dut": 65010},
        "refresh_seconds": 600,
        "rtr_min_refresh_seconds": 600,
        "rtr_expire_seconds": 600,
        "probe_interval_ms_requested_per_prefix": 100,
        "snapshot_interval_ms_requested": int(lab.POLL_SECONDS * 1000),
        "as_a_local_preference": 200,
        "invalid_policy": "deny match rpki invalid",
        "repository_transport": "local rsync",
        "isolation": "Docker internal network 198.18.0.0/16; sequential isolated compose projects",
        "source_sha256": {
            name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            for name in source_files
        },
        "trials": [],
    }
    manifest_path = batch / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (batch / "schedule.json").write_text(json.dumps(schedule, indent=2) + "\n", encoding="utf-8")

    results = []
    for index, item in enumerate(schedule, start=1):
        case = batch / item["case"]
        print(
            f"[{index}/{len(schedule)}] {item['case']}",
            flush=True,
        )
        result = run_matrix_trial(
            case,
            item["scenario"],
            item["prefix_count"],
            item["repetition"],
            args.hold_seconds,
            args.post_update_seconds,
        )
        results.append(result)
        manifest["completed_runs"] = index
        manifest["trials"].append(
            {
                "case": result["case"],
                "scenario_valid": result["scenario_valid"],
                "failover_verified": result["failover_verified"],
                "invalid_reason": result["invalid_reason"],
            }
        )
        manifest_path.write_text(
            json.dumps(manifest, indent=2) + "\n",
            encoding="utf-8",
        )
        save_matrix_summary(batch, results)
        print(
            f"{item['case']}: valid={result['scenario_valid']} "
            f"failover_verified={result['failover_verified']} "
            f"reason={result['invalid_reason'] or '-'}",
            flush=True,
        )

    print(f"Final matrix results: {batch}", flush=True)
    valid_count = sum(result["scenario_valid"] for result in results)
    print(f"Valid runs: {valid_count}/{len(schedule)}", flush=True)
    return 0 if valid_count == len(schedule) else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--final-matrix",
        action="store_true",
        help="run the final 18-trial signed-ROA scenario and prefix matrix",
    )
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--hold-seconds", type=float, default=8)
    parser.add_argument("--post-update-seconds", type=float, default=3)
    args = parser.parse_args()
    if args.repetitions < 1 or not 1 <= args.hold_seconds <= 60:
        parser.error("Use at least one repetition and an observation period from 1 to 60 seconds.")
    if shutil.which("docker") is None:
        parser.error("Docker CLI not found; install Docker Desktop and enable Linux containers.")
    engine = subprocess.run(
        ["docker", "info", "--format", "{{.OSType}}"],
        capture_output=True,
        text=True,
        timeout=15,
        check=False,
    )
    if engine.returncode or engine.stdout.strip() != "linux":
        parser.error("Docker Linux container engine is unavailable.")
    preparation = load_preparation_manifest()
    router_id = image_id(PATCHED_IMAGE)
    if router_id != preparation["patched_image_id"]:
        parser.error("The patched FRR image does not match its preparation manifest.")
    if args.final_matrix:
        try:
            return run_final_matrix(args, preparation)
        except (RuntimeError, ValueError, OSError) as exc:
            parser.error(str(exc))
    if lab.PREFIX_COUNT != 1:
        parser.error("This test requires ROV_PREFIX_COUNT=1.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    batch = ROOT / "results" / f"pr24131-signed-roa-{stamp}"
    batch.mkdir()
    os.environ.update(
        ROV_DUT_IMAGE=PATCHED_IMAGE, ROV_COMPOSE_PROJECT=f"rov-signed-{stamp.lower()}",
        ROV_COMPOSE_OVERLAY="signed-rpki/compose.yaml", SIGNED_CA_IMAGE=CA_IMAGE,
        SIGNED_RP_IMAGE=RP_IMAGE, SIGNED_CA_TOKEN=secrets.token_hex(24),
    )
    manifest = {
        "frr": router_id, "krill": image_id(CA_IMAGE), "routinator": image_id(RP_IMAGE),
        "krill_tag": CA_IMAGE, "routinator_tag": RP_IMAGE, "refresh_seconds": 600,
        "hold_seconds": args.hold_seconds, "prefix": lab.PREFIX,
        "as_a_local_preference": 200, "repository_transport": "rsync",
    }
    (batch / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    results = []
    for repetition in range(1, args.repetitions + 1):
        for stale in ((False, True) if repetition % 2 else (True, False)):
            variant = "stale" if stale else "current"
            case = batch / f"{variant}-{repetition:02d}"
            print(f"Starting {case.name}", flush=True)
            result = run_trial(case, stale, args.hold_seconds)
            results.append(result)
            print(f"{case.name}: {result}", flush=True)
            if not result["valid"]:
                print(f"Diagnostic evidence: {case}", flush=True)
                break
        if not result["valid"]:
            break
    columns = list(dict.fromkeys(key for result in results for key in result))
    with (batch / "comparison_summary.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(results)
    print(f"Results: {batch}", flush=True)
    return 0 if all(result["valid"] for result in results) else 2


if __name__ == "__main__":
    sys.exit(main())
