"""Isolated extension of the signed-ROA study. Original batches remain untouched."""
import argparse,csv,hashlib,json,os,random,re,secrets,shutil,subprocess,sys,time,threading
from pathlib import Path
from datetime import datetime,timezone
import run_lab as lab
import run_signed_roa as signed
from rtr_timer_audit import verify_timers

ROOT=Path(__file__).resolve().parent
IMAGES={'patched':'rov-frr-pr24131:patched-c78f8743','base':'rov-frr-pr24131:base-ce548b0d','bird':'rov-study-bird:local'}
FORT='nicmx/fort-validator:1.6.7'
CURRENT_MONITOR=None

def event(rows,name,**kw):lab.log_event(rows,name,**kw)
def wait(fn,label,timeout=50):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        v=fn()
        if v:return v
        time.sleep(.2)
    raise RuntimeError('Timed out: '+label)
def cmd(service,*args,check=True):return lab.compose('exec','-T',service,*args,check=check).stdout
def cli(*commands):
    text=cmd('dut','vtysh',*[z for c in commands for z in ['-c',c]])
    if any(w in text for w in ['is already configured','% Command incomplete','% Unknown command','Could not create new rpki cache']):raise RuntimeError('FRR rejected an experimental control command: '+text)
    return text
def birdcli(command):return cmd('dut','birdc',command)

def bird_config(pref,deny=False,backup=False):
    pa,pb={'prefer-a':(200,100),'equal':(100,100),'prefer-b':(100,200)}[pref]
    filt='reject;' if deny else 'if roa_check(r4, net, bgp_path.last) = ROA_INVALID then reject; accept;'
    return f'''log stderr all;
router id 198.18.2.10;
roa4 table r4;
protocol device {{ scan time 1; }}
protocol kernel {{ ipv4 {{ import none; export all; }}; scan time 1; }}
protocol static safety {{ ipv4 {{ preference 10; }}; route 198.18.0.0/24 blackhole; }}
protocol rpki primary {{ roa4 {{ table r4; }}; remote 198.18.2.21 port 3323; refresh 600; retry 2; expire 7200; max version 1; }}
protocol rpki backup {{ disabled {'off' if backup else 'on'}; roa4 {{ table r4; }}; remote 198.18.2.22 port 3323; refresh 600; retry 2; expire 7200; max version 1; }}
protocol bgp bgpa {{ local as 65010; neighbor 198.18.2.11 as 65001; ipv4 {{ import table on; import filter {{ bgp_local_pref={pa}; {filt} }}; export none; }}; }}
protocol bgp bgpb {{ local as 65010; neighbor 198.18.2.12 as 65002; ipv4 {{ import table on; import filter {{ bgp_local_pref={pb}; {filt} }}; export none; }}; }}
'''

def setup(case,router,rp,policy):
    signed.configure_prefix_case(case,1)
    shutil.copytree(ROOT/'signed-rpki',case/'signed-rpki')
    (case/'tals').mkdir()
    d=case/'frr/dut.conf';s=d.read_text();pa,pb={'prefer-a':(200,100),'equal':(100,100),'prefer-b':(100,200)}[policy]
    s=s.replace('rpki polling_period 1\n','rpki polling_period 600\n').replace('rpki expire_interval 600\n','rpki expire_interval 7200\n')
    s=s.replace('set local-preference 200',f'set local-preference {pa}')
    s=s.replace('neighbor 198.18.2.12 route-map ROV-IN in','neighbor 198.18.2.12 route-map ROV-PREFER-B in')
    s+=f'\nroute-map ROV-PREFER-B deny 10\n match rpki invalid\nroute-map ROV-PREFER-B permit 20\n set local-preference {pb}\n'
    d.write_text(s,newline='\n')
    overlay=(case/'signed-rpki/compose.yaml').read_text()
    overlay=overlay.replace('--expire=600','--expire=7200')
    if router=='bird':
        (case/'bird.conf').write_text(bird_config(policy),newline='\n')
        overlay+='''\n  dut:
    entrypoint: ["bird"]
    command: ["-f", "-c", "/etc/bird.conf"]
    volumes: !override
      - ./bird.conf:/etc/bird.conf:ro
'''
        # Insert DUT under services, not under the volumes mapping.
        tail=overlay[overlay.rfind('\n  dut:'):];overlay=overlay[:overlay.rfind('\n  dut:')]
        overlay=overlay.replace('\nvolumes:\n',tail+'\nvolumes:\n')
    if rp=='fort':
        # Replace the RP anchor; both instances remain independent validator processes.
        anchor='''x-routinator: &routinator
  image: '''+FORT+'''
  command:
    - --tal=/tals
    - --local-repository=/tmp/fort-repo
    - --server.address=0.0.0.0
    - --server.port=3323
    - --server.interval.validation=600
    - --server.interval.refresh=600
    - --server.interval.retry=2
    - --server.interval.expire=7200
    - --http.enabled=false
    - --output.roa=/tmp/vrps.json
    - --output.format=json
  build: !reset null
  environment: !reset {}
  volumes:
    - ./tals:/tals:ro
'''
        overlay=anchor+'\n'+overlay[overlay.index('services:'):]
    (case/'signed-rpki/compose.yaml').write_text(overlay,newline='\n')

def vrps(service,rp):
    try:
        if rp=='routinator':return signed.validator_vrps(service)
        data=json.loads(cmd(service,'cat','/tmp/vrps.json'))
        return data.get('roas',[]) if isinstance(data,dict) else data
    except (RuntimeError,ValueError):return None
def view(service,rp):
    v=vrps(service,rp)
    if v is None:return None
    return {(int(str(x.get('asn',x.get('as'))).removeprefix('AS')),x['prefix'],int(x.get('maxLength',x.get('max_length',24)))) for x in v}
def validate(service,rp,origin,rows,refresh=False):
    if refresh:
        event(rows,'validator_refresh_requested',service=service,method='SIGUSR1' if rp=='routinator' else 'restart')
        if rp=='routinator':lab.compose('kill','-s','SIGUSR1',service)
        else:lab.compose('restart',service)
    expected={(origin,lab.PREFIX,24)} if origin is not None else set()
    def ready():
        v=view(service,rp)
        return {'view':sorted(v)} if v==expected else None
    found=wait(ready,'validator view '+service,70)
    event(rows,'validator_view_verified',service=service,origin=origin,view=found['view'])
    return found

def snapshot(router,rows,force=False):
    if not force and CURRENT_MONITOR is not None and CURRENT_MONITOR.get('latest') is not None:return CURRENT_MONITOR['latest']
    if router!='bird':s=lab.collect_snapshot()
    else:
        start=lab.now_ns()
        script="import json,subprocess; commands={'protocols':'show protocols all','routes':'show route all','vrps':'show route table r4 all','bgpa':'show route protocol bgpa all','bgpb':'show route protocol bgpb all'}; out={k:subprocess.check_output(['birdc',v],text=True) for k,v in commands.items()}; route=subprocess.run(['ip','-j','route','get','198.18.0.10'],capture_output=True,text=True); out['kernel']=json.loads(route.stdout) if route.returncode==0 else []; out['kernel_error']=route.stderr; print(json.dumps(out))"
        raw=json.loads(cmd('dut','python','-c',script));kernel=raw['kernel']
        accepted=[]
        for peer,asn in [('bgpa',65001),('bgpb',65002)]:
            text=raw[peer]
            if '198.18.0.0/24' in text:accepted.append(asn)
        route=raw['routes'];selected=None
        for m in re.finditer(r'\[(bgpa|bgpb) [^\n]*\*',route):selected=65001 if m[1]=='bgpa' else 65002;break
        gateway=kernel[0].get('gateway') if kernel else None
        fib={'198.18.2.11':65001,'198.18.2.12':65002}.get(gateway)
        origins=sorted({int(x) for x in re.findall(r'AS(\d+)',raw['vrps'])})
        def up(name):return bool(re.search(r'^'+name+r'\s+RPKI\s+[^\n]*\bup\b',raw['protocols'],re.M|re.I))
        state={'accepted_asns':accepted,'installed_vrp_origins':origins,'selected_rib_as':selected,'selected_fib_as':fib,'rov_by_asn':{str(a):'valid' if a in origins else 'invalid' if origins else 'notfound' for a in [65001,65002]}}
        s={'type':'snapshot','timestamp_ns':lab.now_ns(),'collection_duration_ms':(lab.now_ns()-start)/1e6,'raw':raw,'state_by_prefix':{lab.PREFIX:state},'cache_connected_primary':up('primary'),'cache_connected_backup':up('backup'),'bgp_sessions_established':raw['protocols'].count('Established')>=2,**{'selected_rib_as':selected,'selected_fib_as':fib}}
    rows.append(s);return s
def current_service():return lab.last_probe_services_by_prefix().get(lab.PREFIX)
def state_b(s):
    x=s['state_by_prefix'][lab.PREFIX]
    return x['selected_fib_as']==65002 and x['selected_rib_as']==65002 and 65001 not in x['accepted_asns']
def reconfigure_bird(case,policy,deny=False,backup=False):
    (case/'bird.conf').write_text(bird_config(policy,deny,backup),newline='\n');birdcli('configure');birdcli('reload filters in all')
def deny_routes(router,case,policy,deny):
    if router=='bird':reconfigure_bird(case,policy,deny,backup=not deny)
    else:
        if deny:cli('configure terminal','route-map EXT-DENY deny 1','router bgp 65010','address-family ipv4 unicast','neighbor 198.18.2.11 route-map EXT-DENY in','neighbor 198.18.2.12 route-map EXT-DENY in')
        else:cli('configure terminal','router bgp 65010','address-family ipv4 unicast','neighbor 198.18.2.11 route-map ROV-PREFER-A in','neighbor 198.18.2.12 route-map ROV-PREFER-B in')
        cli('clear bgp * soft in')

def trial(case,router,rp,policy,scenario,mechanism,hold,repetition):
    global CURRENT_MONITOR
    rows=[];out={'case':case.name,'router':router,'rp':rp,'policy':policy,'scenario':scenario,'mechanism':mechanism,'repetition':repetition,'scenario_valid':False,'invalid_reason':''};started=False
    monitor_stop=threading.Event();monitor_thread=None;CURRENT_MONITOR=None
    lab.ROOT=case;lab.PREFIXES=(lab.PREFIX,);lab.PREFIX_COUNT=1;lab.ACTIVE_SNAPSHOT_MONITOR=None
    os.environ.update(ROV_DUT_IMAGE=IMAGES[router],ROV_PREFIX_COUNT='1',ROV_COMPOSE_PROJECT='ext-'+case.name.lower(),ROV_COMPOSE_OVERLAY='signed-rpki/compose.yaml',SIGNED_CA_IMAGE=signed.CA_IMAGE,SIGNED_RP_IMAGE=signed.RP_IMAGE,SIGNED_CA_TOKEN=secrets.token_hex(24))
    case.mkdir()
    out['source_sha256']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['run_extended_study.py','run_signed_roa.py','run_lab.py','client_agent.py','compose.yaml','extended-study/Dockerfile.bird','rtr_timer_audit.py']}
    out['rov_observation_method']='classification derived from installed VRP table for the exact /24 test prefix; admission and selection observed directly'
    shutil.copy2(ROOT/'run_extended_study.py',case/'study_runner.py')
    try:
        setup(case,router,rp,policy);lab.compose('build',timeout=600)
        hashes=signed.init_authority(case,rows)
        lab.compose('up','-d',lab.RTR_PRIMARY,lab.RTR_BACKUP,timeout=180);started=True
        for service in [lab.RTR_PRIMARY,lab.RTR_BACKUP]:validate(service,rp,65001,rows)
        out['initialization_order']='both validators have the initial signed view before the DUT starts'
        lab.compose('up','-d',timeout=180)
        cmd('dut','sysctl','-w','net.ipv4.conf.eth0.send_redirects=0')
        out['router_version']=birdcli('show status') if router=='bird' else cmd('dut','vtysh','-c','show version')
        out['rp_version']=cmd(lab.RTR_PRIMARY,'fort','--version') if rp=='fort' else cmd(lab.RTR_PRIMARY,'routinator','--version')
        out['image_ids']={k:subprocess.check_output(['docker','image','inspect','--format={{.Id}}',v],text=True).strip() for k,v in {'router':IMAGES[router],'rp':FORT if rp=='fort' else signed.RP_IMAGE,'krill':signed.CA_IMAGE}.items()}
        CURRENT_MONITOR={'latest':None}
        def observe():
            while not monitor_stop.is_set():
                try:CURRENT_MONITOR['latest']=snapshot(router,rows,force=True)
                except Exception as exc:event(rows,'observer_error',error=str(exc))
                monitor_stop.wait(.1)
        monitor_thread=threading.Thread(target=observe,daemon=True);monitor_thread.start()
        lab.container_json('client',8080,'/start',{'interval_ms':100,'timeout_s':.4})
        wait(lambda:snapshot(router,rows)['state_by_prefix'][lab.PREFIX]['selected_fib_as']==65001 and current_service()=='AS-A','initial A')
        signed.publish(case,rows,65002,previous=65001,previous_hashes=hashes)
        validate(lab.RTR_PRIMARY,rp,65002,rows,True)
        if scenario=='updated-backup':validate(lab.RTR_BACKUP,rp,65002,rows,True)
        else:validate(lab.RTR_BACKUP,rp,65001,rows)
        if rp=='fort' and router!='bird':
            event(rows,'prebaseline_cache_selection_reset',reason='FORT primary refresh restarts its RTR endpoint; reselect priority source before the intervention')
            cli('rpki reset')
        try:wait(lambda:state_b(snapshot(router,rows)) and current_service()=='AS-B','B baseline',12)
        except RuntimeError:
            if router!='base':raise
            event(rows,'unpatched_baseline_requires_operator_revalidation');out['operator_baseline_revalidation']=True;cli('clear bgp * soft in')
            wait(lambda:state_b(snapshot(router,rows)) and current_service()=='AS-B','base baseline after manual replay')
        event(rows,'baseline_verified',state=snapshot(router,rows))
        out['DUT_eth0_send_redirects']=cmd('dut','cat','/proc/sys/net/ipv4/conf/eth0/send_redirects').strip()
        if out['DUT_eth0_send_redirects']!='0':raise RuntimeError('DUT must not redirect probes around its forwarding decision')
        out['client_route_before_intervention']=json.loads(cmd('client','ip','-j','route','get','198.18.0.10'))
        if out['client_route_before_intervention'][0].get('gateway')!='198.18.2.10':raise RuntimeError('Client bypasses DUT before intervention')
        before=lab.now_ns();out['preflight_start_ns']=before;backup=view(lab.RTR_BACKUP,rp);disagree=backup!={(65002,lab.PREFIX,24)}
        event(rows,'preflight_consistency_check',backup_view=sorted(backup),expected=[[65002,lab.PREFIX,24]],disagrees=disagree,mechanism=mechanism)
        if mechanism=='gate' and disagree:
            if router=='bird':birdcli('disable backup')
            else:
                cli('configure terminal','rpki','no rpki cache tcp 198.18.2.22 3323 preference 2')
                if 'rpki cache tcp 198.18.2.22' in cli('show running-config'):raise RuntimeError('Gate did not remove the backup source')
            out['mechanism_applied']=True
        if mechanism=='fail-safe' and disagree:
            deny_routes(router,case,policy,True)
            wait(lambda:not snapshot(router,rows)['state_by_prefix'][lab.PREFIX]['accepted_asns'],'fail-safe denies both candidate routes',15)
            out['mechanism_applied']=True
        out['preflight_cost_ms']=(lab.now_ns()-before)/1e6
        out['intervention_ns']=lab.now_ns();event(rows,'intervention_requested',scenario=scenario)
        if scenario in ['stale-backup','updated-backup','route-withdrawal','natural-refresh']:
            lab.compose('stop','-t','2',lab.RTR_PRIMARY)
            if router=='bird':
                if not(mechanism=='gate' and disagree):
                    birdcli('disable primary');birdcli('enable backup');event(rows,'controller_mediated_bird_handoff')
                else:event(rows,'retain_current_primary_view_until_expiry_backup_blocked')
        elif scenario=='concurrent-inconsistent':
            if router=='bird':
                birdcli('enable backup');out['concurrent_consumption_mode']='two active RTR protocols, shared ROA table'
            else:
                out['concurrent_consumption_mode']='two available validators; native FRR priority selects one source'
                event(rows,'native_FRR_unique_preference_constraint',source='bgpd/bgp_rpki.c rpki_cache_tcp',note='No unsupported equal-preference configuration is attempted')
        elif scenario=='blackhole':
            cmd('dut','iptables','-I','OUTPUT','-d','198.18.2.21','-p','tcp','--dport','3323','-j','DROP');cmd('dut','iptables','-I','INPUT','-s','198.18.2.21','-p','tcp','--sport','3323','-j','DROP')
        elif scenario in ['authorization-empty','authorization-unrelated']:
            if scenario=='authorization-unrelated':signed.publish(case,rows,65003,previous=65002,previous_hashes=signed.publication_hashes())
            else:
                signed.krill('roas','update','--ca','testbed','--remove',lab.PREFIX+' => 65002')
                event(rows,'signed_authorization_removed',prefix=lab.PREFIX)
                wait(lambda:{'empty':True} if not signed.publication_hashes() else None,'empty signed ROA publication')
            validate(lab.RTR_PRIMARY,rp,65003 if scenario=='authorization-unrelated' else None,rows,True)
        if scenario in ['stale-backup','updated-backup','route-withdrawal','natural-refresh'] and mechanism!='gate':
            event(rows,'standby_activation_observation_started',limit_seconds=40)
            try:
                wait(lambda:snapshot(router,rows).get('cache_connected_backup'),'standby connection before controlled hold',40)
                out['standby_connection_before_hold']=True
            except RuntimeError:
                out['standby_connection_before_hold']=False
                event(rows,'standby_connection_not_observed_before_hold',limit_seconds=40)
        start=lab.now_ns();out['exposure_start_ns']=start
        withdrawn=False;last_heartbeat=0.0
        while lab.now_ns()-start<hold*1e9:
            if scenario=='route-withdrawal' and not withdrawn and lab.now_ns()-start>hold*.5e9:
                event(rows,'AS_A_BGP_announcement_withdrawal_requested');cmd('as-a','vtysh','-c','configure terminal','-c','router bgp 65001','-c','address-family ipv4 unicast','-c','no network '+lab.PREFIX);withdrawn=True
            sample=snapshot(router,rows);elapsed=(lab.now_ns()-start)/1e9
            if elapsed-last_heartbeat>=5:
                (case/'live_status.json').write_text(json.dumps({'phase':'exposure','elapsed_seconds':elapsed,'requested_seconds':hold,'state':sample['state_by_prefix'],'latest_service':current_service()}),encoding='utf-8');last_heartbeat=elapsed
            time.sleep(.1)
        end=lab.now_ns();out['exposure_end_ns']=end;event(rows,'exposure_completed')
        out['client_route_after_exposure']=json.loads(cmd('client','ip','-j','route','get','198.18.0.10'))
        if out['client_route_after_exposure'][0].get('gateway')!='198.18.2.10':raise RuntimeError('Client bypassed DUT during exposure')
        # Restore transport and current data; recovery includes this actual implementation's refresh operation.
        update=lab.now_ns();out['recovery_requested_ns']=update
        if scenario in ['authorization-empty','authorization-unrelated']:
            signed.publish(case,rows,65002,previous=65003 if scenario=='authorization-unrelated' else None,previous_hashes=signed.publication_hashes())
            validate(lab.RTR_PRIMARY,rp,65002,rows,True)
        if scenario=='blackhole':
            cmd('dut','iptables','-D','OUTPUT','-d','198.18.2.21','-p','tcp','--dport','3323','-j','DROP');cmd('dut','iptables','-D','INPUT','-s','198.18.2.21','-p','tcp','--sport','3323','-j','DROP')
        if scenario=='natural-refresh':
            current=view(lab.RTR_BACKUP,rp)
            out['natural_backup_view_after_hold']=sorted(current) if current is not None else None
            event(rows,'natural_backup_view_observed_after_hold',view=out['natural_backup_view_after_hold'],note='No forced update or success requirement; missing routing restoration remains censored')
        else:validate(lab.RTR_BACKUP,rp,65002,rows,True)
        if rp=='fort' and router!='bird':
            event(rows,'recovery_cache_selection_reset',reason='explicit controller resynchronization after FORT endpoint restart; included in recovery cost')
            cli('rpki reset')
        if router=='bird' and scenario!='natural-refresh':reconfigure_bird(case,policy,False,True);birdcli('disable primary')
        else:
            if mechanism=='gate' and disagree:cli('configure terminal','rpki','rpki cache tcp 198.18.2.22 3323 preference 2')
            if mechanism=='fail-safe':deny_routes(router,case,policy,False)
            if router=='base':cli('clear bgp * soft in')
        try:
            wait(lambda:state_b(snapshot(router,rows)) and current_service()=='AS-B','B recovery',50)
            out['recovery_verified_ns']=lab.now_ns();out['state_recovery_censored']=False
        except RuntimeError:
            out['state_recovery_censored']=True
            event(rows,'state_recovery_not_observed_before_deadline',observation_limit_seconds=50)
        out['recovery_observation_end_ns']=lab.now_ns()
        for _ in range(3):snapshot(router,rows);time.sleep(.2)
        lab.container_json('client',8080,'/stop',{});probes=lab.probe_events();rows.extend(probes)
        ep=[p for p in probes if start<=p['started_ns']<end]
        if len(ep)<5:raise RuntimeError('Insufficient exposure probes')
        exposure_samples=[s for s in rows if s.get('type')=='snapshot' and start<=s['timestamp_ns']<end]
        if not exposure_samples or not all(s['bgp_sessions_established'] for s in exposure_samples):raise RuntimeError('Missing state evidence or BGP adjacency loss during exposure')
        out.update(http_A=sum(p.get('service')=='AS-A' and p.get('status')==200 for p in ep),http_B=sum(p.get('service')=='AS-B' and p.get('status')==200 for p in ep),http_other=sum(p.get('status')!=200 or p.get('service') not in ['AS-A','AS-B'] for p in ep),http_total=len(ep))
        recovered=next((p for p in probes if p['started_ns']>=update and p.get('service')=='AS-B' and p.get('status')==200),None)
        out['first_B_request_start_after_recovery_ms']=(recovered['started_ns']-update)/1e6 if recovered else None
        out['first_B_response_completion_after_recovery_ms']=(recovered['finished_ns']-update)/1e6 if recovered else None
        samples=[s for s in rows if s.get('type')=='snapshot' and out['intervention_ns']<=s['timestamp_ns']<end]
        gaps=[(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(samples,samples[1:])]
        out['snapshot_gap_max_ms']=max(gaps) if gaps else None
        out['first_A_accept_ns']=next((s['timestamp_ns'] for s in samples if 65001 in s['state_by_prefix'][lab.PREFIX]['accepted_asns']),None)
        out['first_backup_connected_ns']=next((s['timestamp_ns'] for s in samples if s.get('cache_connected_backup')),None)
        out['observed_vrp_origin_sets']=sorted({tuple(s['state_by_prefix'][lab.PREFIX]['installed_vrp_origins']) for s in samples})
        out['handoff_observed']=out['first_backup_connected_ns'] is not None
        signed.capture(case)
        out['captured_rtr_timers']=verify_timers(case/'rtr.pcap');out['rtr_timer_compliance_verified']=True
        if scenario in ['stale-backup','updated-backup','route-withdrawal','natural-refresh'] and mechanism!='gate':
            try:
                cut,reset,eod,v=signed.verify_packets(case/'rtr.pcap',out['intervention_ns']);out.update(cut_ns=cut,reset_query_ns=reset,end_of_data_ns=eod,backup_transfer_vrps=v)
                out['backup_transfer_during_exposure']=eod<end
                supplied={(vrp['prefix'],vrp['origin']) for vrp in v if vrp['flags']==1}
                if scenario=='natural-refresh':
                    if supplied not in [{(lab.PREFIX,65001)},{(lab.PREFIX,65002)}]:raise ValueError('Natural-refresh transfer contains an unassigned authorization')
                else:
                    expected_origin=65002 if scenario=='updated-backup' or eod>=update else 65001
                    if supplied!={(lab.PREFIX,expected_origin)}:raise ValueError('Backup transfer disagrees with the assigned authorization condition')
            except RuntimeError:
                closures=[p[0] for p in signed.read_packets(case/'rtr.pcap') if p[0]>=out['intervention_ns'] and p[1]==signed.PRIMARY_IP and p[2]==signed.DUT_IP and p[3]==3323 and p[5]&5]
                if not closures:raise RuntimeError('Primary closure itself was not verified in PCAP')
                out['cut_ns']=closures[0];out['backup_transfer_during_exposure']=False
                event(rows,'backup_transfer_not_observed',note='Right-censored handoff outcome; not evidence of successful standby activation')
        out['previous_origin_installed_observed']=any(65001 in s['state_by_prefix'][lab.PREFIX]['installed_vrp_origins'] for s in samples)
        out['current_only_view_observed']=any(s['state_by_prefix'][lab.PREFIX]['installed_vrp_origins']==[65002] for s in samples)
        if scenario=='authorization-empty' and not any(not s['state_by_prefix'][lab.PREFIX]['installed_vrp_origins'] for s in samples):raise RuntimeError('NotFound input not observed')
        if scenario=='authorization-unrelated' and not any(s['state_by_prefix'][lab.PREFIX]['installed_vrp_origins']==[65003] for s in samples):raise RuntimeError('Unrelated-origin Invalid input not observed')
        out['handoff_right_censored']=(scenario=='blackhole' and not out['handoff_observed']) or (scenario in ['stale-backup','updated-backup','route-withdrawal','natural-refresh'] and mechanism!='gate' and not out.get('backup_transfer_during_exposure',False))
        out['scenario_valid']=True
    except Exception as exc:out['invalid_reason']=f'{type(exc).__name__}: {exc}'
    finally:
        monitor_stop.set()
        if monitor_thread:monitor_thread.join(timeout=15)
        CURRENT_MONITOR=None
        if started:
            try:
                if not any(r.get('type')=='probe' for r in rows):lab.container_json('client',8080,'/stop',{});rows.extend(lab.probe_events())
            except Exception:pass
            try:
                (case/'containers.log').write_text(lab.compose('logs','--no-color',check=False).stdout,encoding='utf-8')
                if not(case/'rtr.pcap').exists():signed.capture(case)
            except Exception:pass
        lab.compose('down','--volumes','--remove-orphans',check=False,timeout=60)
        (case/'evidence.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in rows),encoding='utf-8')
        (case/'outcome.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return out

def main():
    a=argparse.ArgumentParser();a.add_argument('--router',choices=IMAGES,default='patched');a.add_argument('--rp',choices=['routinator','fort'],default='routinator');a.add_argument('--policy',choices=['prefer-a','equal','prefer-b'],default='prefer-a');a.add_argument('--scenario',choices=['stale-backup','updated-backup','concurrent-inconsistent','blackhole','no-rtr-outage','authorization-empty','authorization-unrelated','route-withdrawal','natural-refresh'],default='stale-backup');a.add_argument('--mechanism',choices=['immediate','gate','fail-safe'],default='immediate');a.add_argument('--hold-seconds',type=float,default=8);a.add_argument('--repetition',type=int,default=1);args=a.parse_args()
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');case=ROOT/'results'/('extended-'+stamp+'-'+args.router+'-'+args.rp+'-'+args.policy+'-'+args.scenario+'-'+args.mechanism)
    out=trial(case,args.router,args.rp,args.policy,args.scenario,args.mechanism,args.hold_seconds,args.repetition);print(json.dumps(out,indent=2),flush=True);print(case,flush=True);return 0 if out['scenario_valid'] else 2
if __name__=='__main__':sys.exit(main())
