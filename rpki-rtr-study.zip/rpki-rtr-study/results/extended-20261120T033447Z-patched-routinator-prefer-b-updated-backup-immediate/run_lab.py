import argparse
import csv
import json
import os
import math
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
PREFIX = "198.18.0.0/24"
ALL_PREFIXES = (PREFIX, "198.18.1.0/24")
PREFIX_COUNT = int(os.environ.get("ROV_PREFIX_COUNT", "1"))
if PREFIX_COUNT not in (1, 2):
    raise ValueError("ROV_PREFIX_COUNT must be 1 or 2")
PREFIXES = ALL_PREFIXES[:PREFIX_COUNT]
ACTIVE_SNAPSHOT_MONITOR = None
AS_A = 65001
AS_B = 65002
RTR_PRIMARY = "rtr-primary"
RTR_BACKUP = "rtr-backup"
POLL_SECONDS = 0.5
PROBE_INTERVAL_MS = 100
SCENARIOS = ("stale-backup", "updated-backup", "no-rtr-outage")
EXPIRY_SCENARIOS = ("primary-expiry", "primary-blackhole", "expiry-control")

SUMMARY_FIELDS = [
    "trial_id",
    "scenario",
    "replication",
    "scenario_valid",
    "failover_verified",
    "invalid_reason",
    "primary_update_requested_ns",
    "primary_vrp_installed_ns",
    "service_b_ready_before_failover",
    "service_b_ready_before_failover_ns",
    "primary_update_accepted_as_a_by_prefix",
    "primary_update_selected_rib_as_by_prefix",
    "primary_update_selected_fib_as_by_prefix",
    "primary_rtr_stopped_ns",
    "failover_data_verified_ns",
    "backup_update_requested_ns",
    "service_b_restored_ns",
    "measurement_end_ns",
    "accepted_as_a_after_withdrawal_ms",
    "traffic_to_as_a_after_withdrawal_ms",
    "loss_of_service_b_ms",
    "probe_interval_ms_configured",
    "probe_gap_p95_ms",
    "probe_gap_max_ms",
    "probe_count",
    "snapshot_interval_ms_configured",
    "snapshot_gap_p95_ms",
    "snapshot_gap_max_ms",
    "snapshot_collection_p95_ms",
    "snapshot_collection_max_ms",
    "snapshot_count",
    "tested_prefix_count",
    "tested_prefixes",
    "accepted_as_a_by_prefix",
    "selected_rib_as_by_prefix",
    "selected_fib_as_by_prefix",
    "probe_left_as_b_ns",
    "probe_left_as_b_service",
    "probe_left_as_b_after_backup_ms",
]


def now_ns():
    return time.time_ns()


def log_event(rows, event, **fields):
    rows.append({"type": "runner", "timestamp_ns": now_ns(), "event": event, **fields})


def container_json(service, port, path, payload=None, timeout=10):
    script = (
        "import json,sys,urllib.request;"
        "url,data=sys.argv[1],sys.argv[2];"
        "body=None if data=='-' else data.encode();"
        "request=urllib.request.Request(url,data=body,"
        "headers={'Content-Type':'application/json'} if body is not None else {},"
        "method='GET' if body is None else 'POST');"
        "print(urllib.request.urlopen(request,timeout="
        f"{timeout}"
        ").read().decode())"
    )
    serialized = "-" if payload is None else json.dumps(payload)
    result = compose(
        "exec",
        "-T",
        service,
        "python",
        "-c",
        script,
        f"http://127.0.0.1:{port}{path}",
        serialized,
        check=False,
        timeout=timeout + 10,
    )
    if result.returncode:
        raise RuntimeError(
            f"Container control request failed for {service}{path}: "
            f"{result.stdout}{result.stderr}"
        )
    return json.loads(result.stdout)


def compose(*args, check=True, timeout=60):
    command = [
        "docker",
        "compose",
        "--project-name",
        os.environ.get("ROV_COMPOSE_PROJECT", "rov-rtr-handoff"),
        "-f",
        str(ROOT / "compose.yaml"),
    ]
    if overlay := os.environ.get("ROV_COMPOSE_OVERLAY"):
        command.extend(("-f", str(ROOT / overlay)))
    command.extend(args)
    result = subprocess.run(
        command,
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if check and result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {' '.join(command)}\n"
            f"{result.stdout}\n{result.stderr}"
        )
    return result


def vtysh(command):
    result = compose(
        "exec", "-T", "dut", "vtysh", "-c", command, check=False, timeout=15
    )
    return {
        "command": command,
        "returncode": result.returncode,
        "output": result.stdout,
        "stderr": result.stderr,
    }


def parse_vtysh_batch_output(commands, stdout, stderr, returncode):
    if returncode:
        raise RuntimeError(
            f"Batched vtysh command failed ({returncode}):\n{stdout}\n{stderr}"
        )

    lines = stdout.splitlines()
    raw = {}
    cursor = 0
    for key, command in commands.items():
        begin_marker = f"__ROV_SNAPSHOT_BEGIN_{key}__"
        status_marker = f"__ROV_SNAPSHOT_STATUS_{key}__="
        try:
            begin = lines.index(begin_marker, cursor)
            status = next(
                index
                for index in range(begin + 1, len(lines))
                if lines[index].startswith(status_marker)
            )
            command_returncode = int(lines[status][len(status_marker) :])
        except (ValueError, StopIteration) as error:
            raise RuntimeError(
                f"Could not parse batched vtysh output for {key}:\n"
                f"{stdout}\n{stderr}"
            ) from error

        raw[key] = {
            "command": command,
            "returncode": command_returncode,
            "output": "\n".join(lines[begin + 1 : status]).rstrip("\r"),
            "stderr": "",
        }
        cursor = status + 1

    raw["_batch"] = {
        "command": "batched vtysh snapshot",
        "returncode": returncode,
        "output": "",
        "stderr": stderr,
    }
    return raw


def parse_origin_asns(table_text):
    return parse_vrp_origins(table_text, (PREFIX,))[PREFIX]


def parse_vrp_origins(table_text, prefixes=PREFIXES):
    origins_by_prefix = {prefix: set() for prefix in prefixes}
    for line in table_text.splitlines():
        match = re.match(r"^\s*(\d+\.\d+\.\d+\.\d+)\s+(\d+)\s+-\s+(\d+)\s+(\d+)\s*$", line)
        if match:
            network = f"{match.group(1)}/{match.group(2)}"
            prefix_length = int(match.group(2))
            max_length = int(match.group(3))
            asn = int(match.group(4))
            if network not in origins_by_prefix or max_length != prefix_length:
                continue
            origins_by_prefix[network].add(asn)
    return origins_by_prefix


def parse_accepted_asns(route_text):
    if not re.search(r"Paths:\s*\(\s*[1-9]\d*\s+available", route_text):
        return set()
    return {
        asn
        for asn in (AS_A, AS_B)
        if re.search(rf"(?<![\d.]){asn}(?![\d.])", route_text)
    }


def selected_rib_as(route_text):
    last_asn = None
    for line in route_text.splitlines():
        stripped = line.strip()
        if stripped in (str(AS_A), str(AS_B)):
            last_asn = int(stripped)
        if "best (" in line and last_asn is not None:
            return last_asn
    return None


def selected_fib_as(route_text):
    for asn, address in ((AS_A, "198.18.2.11"), (AS_B, "198.18.2.12")):
        if re.search(rf"(?:\*\s*|via\s+){re.escape(address)}\b", route_text):
            return asn
    return None


def cache_connected(cache_text, address):
    try:
        data = json.loads(cache_text)
    except json.JSONDecodeError:
        data = None

    if data is not None:
        if "error" in data:
            return False
        for connection in data.get("connections", []):
            if connection.get("host") == address:
                state = str(connection.get("state", "")).lower()
                if state == "connected":
                    return True
                if state == "disconnected":
                    return False
                return None
    else:
        for line in cache_text.splitlines():
            if address in line:
                lower = line.lower()
                if any(term in lower for term in ("disconnected", "not connected", "down")):
                    return False
                if any(term in lower for term in ("connected", "established", "up")):
                    return True
    return None


def cache_connected_group(cache_text):
    try:
        data = json.loads(cache_text)
    except json.JSONDecodeError:
        return None
    return data.get("connectedGroup") if isinstance(data, dict) else None


def collect_snapshot():
    commands = {
        "cache": "show rpki cache-connection json",
        "vrps": "show rpki prefix-table",
        "peers": "show bgp neighbors",
    }
    for index, prefix in enumerate(PREFIXES):
        commands[f"bgp_{index}"] = f"show bgp ipv4 unicast {prefix}"
        commands[f"fib_{index}"] = f"show ip route {prefix}"
    script_lines = ["set +e"]
    for key, command in commands.items():
        script_lines.extend(
            (
                f"printf '%s\\n' {shlex.quote(f'__ROV_SNAPSHOT_BEGIN_{key}__')}",
                f"vtysh -c {shlex.quote(command)}",
                "status=$?",
                (
                    "printf '%s%d\\n' "
                    f"{shlex.quote(f'__ROV_SNAPSHOT_STATUS_{key}__=')} "
                    '"$status"'
                ),
            )
        )
    collection_started = time.perf_counter_ns()
    result = compose(
        "exec",
        "-T",
        "dut",
        "sh",
        "-c",
        "\n".join(script_lines),
        check=False,
        timeout=30,
    )
    collection_duration_ms = (
        time.perf_counter_ns() - collection_started
    ) / 1_000_000
    raw = parse_vtysh_batch_output(
        commands, result.stdout, result.stderr, result.returncode
    )
    failed_commands = [
        key for key, command_result in raw.items()
        if key != "_batch" and command_result["returncode"] != 0
    ]
    if failed_commands:
        raise RuntimeError(
            "FRR snapshot commands failed: "
            + ", ".join(
                f"{key}: {raw[key]['output']}" for key in failed_commands
            )
        )
    cache_text = raw["cache"]["output"]
    vrp_text = raw["vrps"]["output"]
    peers_text = raw["peers"]["output"]
    established_peer_count = peers_text.count("BGP state = Established")
    origins_by_prefix = parse_vrp_origins(vrp_text, PREFIXES)
    state_by_prefix = {}
    for index, prefix in enumerate(PREFIXES):
        bgp_text = raw[f"bgp_{index}"]["output"]
        fib_text = raw[f"fib_{index}"]["output"]
        installed_origins = sorted(origins_by_prefix[prefix])
        state_by_prefix[prefix] = {
            "installed_vrp_origins": installed_origins,
            "rov_by_asn": {
                str(asn): (
                    "valid" if asn in installed_origins
                    else "invalid" if installed_origins
                    else "notfound"
                )
                for asn in (AS_A, AS_B)
            },
            "accepted_asns": sorted(parse_accepted_asns(bgp_text)),
            "selected_rib_as": selected_rib_as(bgp_text),
            "selected_fib_as": selected_fib_as(fib_text),
        }
    raw["bgp"] = raw["bgp_0"]
    raw["fib"] = raw["fib_0"]
    first_state = state_by_prefix[PREFIX]
    origins = sorted(
        {asn for state in state_by_prefix.values() for asn in state["installed_vrp_origins"]}
    )
    accepted = set(first_state["accepted_asns"])
    return {
        "type": "snapshot",
        "timestamp_ns": now_ns(),
        "collection_duration_ms": collection_duration_ms,
        "cache_connected_primary": cache_connected(cache_text, "198.18.2.21"),
        "cache_connected_backup": cache_connected(cache_text, "198.18.2.22"),
        "connected_cache_group": cache_connected_group(cache_text),
        "installed_vrp_origins": origins,
        "state_by_prefix": state_by_prefix,
        "rov_as_a": (
            "valid" if AS_A in first_state["installed_vrp_origins"]
            else "invalid" if first_state["installed_vrp_origins"] else "notfound"
        ),
        "rov_as_b": (
            "valid" if AS_B in first_state["installed_vrp_origins"]
            else "invalid" if first_state["installed_vrp_origins"] else "notfound"
        ),
        "accepted_asns": sorted(accepted),
        "accepted_as_a": AS_A in accepted,
        "accepted_as_b": AS_B in accepted,
        "accepted_as_a_by_prefix": {
            prefix: AS_A in state["accepted_asns"]
            for prefix, state in state_by_prefix.items()
        },
        "bgp_sessions_established": established_peer_count >= 2,
        "established_peer_count": established_peer_count,
        "selected_rib_as": first_state["selected_rib_as"],
        "selected_fib_as": first_state["selected_fib_as"],
        "raw": raw,
    }


class SnapshotMonitor:
    def __init__(self, rows):
        self.rows = rows
        self.stop_event = threading.Event()
        self.ready_event = threading.Event()
        self.lock = threading.Lock()
        self.latest_snapshot = None
        self.error = None
        self.thread = threading.Thread(
            target=self._run, name="frr-snapshot-monitor", daemon=True
        )

    def start(self):
        self.thread.start()

    def _run(self):
        startup_deadline = time.monotonic() + 35
        startup_failures = 0
        while not self.stop_event.is_set():
            started = time.monotonic()
            try:
                sample = collect_snapshot()
            except Exception as error:
                if (
                    self.latest_snapshot is None
                    and time.monotonic() < startup_deadline
                ):
                    startup_failures += 1
                    self.rows.append(
                        {
                            "type": "runner",
                            "timestamp_ns": now_ns(),
                            "event": "snapshot_monitor_startup_retry",
                            "attempt": startup_failures,
                            "error": f"{type(error).__name__}: {error}",
                        }
                    )
                    self.stop_event.wait(1)
                    continue
                with self.lock:
                    self.error = error
                self.rows.append(
                    {
                        "type": "runner",
                        "timestamp_ns": now_ns(),
                        "event": "snapshot_monitor_error",
                        "error": f"{type(error).__name__}: {error}",
                    }
                )
                self.ready_event.set()
                return

            with self.lock:
                self.latest_snapshot = sample
            if startup_failures:
                self.rows.append(
                    {
                        "type": "runner",
                        "timestamp_ns": now_ns(),
                        "event": "snapshot_monitor_startup_recovered",
                        "failed_attempts": startup_failures,
                    }
                )
            self.rows.append(sample)
            self.ready_event.set()
            startup_deadline = None
            elapsed = time.monotonic() - started
            self.stop_event.wait(max(0, POLL_SECONDS - elapsed))

    def latest(self):
        if not self.ready_event.wait(timeout=35):
            raise RuntimeError("FRR snapshot monitor produced no initial sample")
        with self.lock:
            if self.error is not None:
                raise RuntimeError(
                    f"FRR snapshot monitor failed: {self.error}"
                ) from self.error
            return self.latest_snapshot

    def stop(self):
        self.stop_event.set()
        self.thread.join(timeout=35)
        if self.thread.is_alive():
            raise RuntimeError("FRR snapshot monitor did not stop within 35 seconds")
        with self.lock:
            if self.error is not None:
                raise RuntimeError(
                    f"FRR snapshot monitor failed: {self.error}"
                ) from self.error


def snapshot():
    monitor = ACTIVE_SNAPSHOT_MONITOR
    if monitor is not None and threading.current_thread() is not monitor.thread:
        return monitor.latest()
    return collect_snapshot()


def append_manual_snapshot(rows, sample):
    if ACTIVE_SNAPSHOT_MONITOR is None:
        rows.append(sample)


def client_status():
    return container_json("client", 8080, "/status")


def last_probe_service():
    latest = client_status().get("latest")
    if latest and latest.get("type") == "probe":
        return latest.get("service")
    return None


def last_probe_services_by_prefix():
    latest = client_status().get("latest_by_prefix", {})
    return {
        prefix: record.get("service")
        for prefix, record in latest.items()
        if record.get("type") == "probe"
    }


def wait_for(predicate, rows, timeout, label, observe=True):
    deadline = time.monotonic() + timeout
    last = None
    while time.monotonic() < deadline:
        last = snapshot() if observe else None
        if last is not None:
            append_manual_snapshot(rows, last)
        if predicate(last):
            return last
        time.sleep(POLL_SECONDS)
    return last


def hold_and_observe(seconds, rows):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        append_manual_snapshot(rows, snapshot())
        time.sleep(POLL_SECONDS)


def update_cache(base_url, asn, rows, label):
    log_event(rows, f"{label}_requested", asn=asn)
    result = container_json(
        base_url,
        8080,
        "/state",
        {
            "vrps": [
                {"prefix": prefix, "maxLength": 24, "asn": asn}
                for prefix in PREFIXES
            ]
        },
    )
    log_event(rows, f"{label}_server_accepted", **result)
    return result


def rtr_state_matches(state, asn):
    expected = {(prefix, 24, asn) for prefix in PREFIXES}
    actual = {
        (vrp["prefix"], int(vrp["maxLength"]), int(vrp["asn"]))
        for vrp in state.get("vrps", [])
    }
    return actual == expected


def cache_events(base_url):
    return container_json(base_url, 8080, "/events").get("events", [])


def probe_events():
    return container_json("client", 8080, "/events").get("events", [])


def expected_as_b_vrp_state(snap):
    return (
        snap is not None
        and snap["bgp_sessions_established"]
        and all(
            state["installed_vrp_origins"] == [AS_B]
            for state in snap["state_by_prefix"].values()
        )
    )


def expected_new_state(snap):
    return (
        expected_as_b_vrp_state(snap)
        and all(
            state["accepted_asns"] == [AS_B]
            and state["selected_rib_as"] == AS_B
            and state["selected_fib_as"] == AS_B
            for state in snap["state_by_prefix"].values()
        )
    )


def expected_stale_backup_data(snap):
    return (
        snap is not None
        and all(
            AS_A in state["installed_vrp_origins"]
            for state in snap["state_by_prefix"].values()
        )
        and snap["bgp_sessions_established"]
    )


def start_stack():
    compose("down", "--remove-orphans", check=False)
    compose("up", "-d", timeout=180)
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        try:
            container_json("rtr-primary", 8080, "/health", timeout=1)
            container_json("rtr-backup", 8080, "/health", timeout=1)
            container_json("client", 8080, "/health", timeout=1)
            break
        except (RuntimeError, TimeoutError, OSError, json.JSONDecodeError):
            time.sleep(1)
    else:
        raise RuntimeError("RTR/control containers did not become ready")

    container_json(
        "client",
        8080,
        "/start",
        {"interval_ms": PROBE_INTERVAL_MS, "timeout_s": 0.4},
    )


def ensure_bgp_and_initial_state(rows):
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        snap = snapshot()
        append_manual_snapshot(rows, snap)
        if (
            snap["bgp_sessions_established"]
            and snap["cache_connected_primary"] is True
            and snap["cache_connected_backup"] is False
            and snap["installed_vrp_origins"] == [AS_A]
            and all(
                state["installed_vrp_origins"] == [AS_A]
                and state["accepted_asns"] == [AS_A]
                and state["selected_rib_as"] == AS_A
                and state["selected_fib_as"] == AS_A
                for state in snap["state_by_prefix"].values()
            )
            and last_probe_service() == "AS-A"
        ):
            log_event(rows, "initial_state_verified")
            return
        time.sleep(POLL_SECONDS)
    raise RuntimeError(
        "initial state was not verified (BGP sessions, primary RTR VRP, "
        "AS-A accepted/FIB-selected, and AS-A probe are all required)"
    )


def duration_ms(samples, start_ns, end_ns, predicate, timestamp_key):
    points = sorted(
        (
            sample.get(timestamp_key),
            bool(predicate(sample)),
        )
        for sample in samples
        if isinstance(sample.get(timestamp_key), int)
        and start_ns <= sample[timestamp_key] <= end_ns
    )
    total = 0
    for index, (timestamp, matches) in enumerate(points):
        next_timestamp = (
            points[index + 1][0] if index + 1 < len(points) else end_ns
        )
        if matches and next_timestamp > timestamp:
            total += next_timestamp - timestamp
    return total / 1_000_000


def analyze_run(rows, probes, scenario, trial_id, repetition, phase):
    events = {
        row["event"]: row["timestamp_ns"]
        for row in rows
        if row.get("type") == "runner" and "timestamp_ns" in row
    }
    primary_installed = phase.get("primary_vrp_installed_ns")
    end_ns = phase.get("measurement_end_ns", now_ns())
    valid = phase.get("scenario_valid", False)
    start_for_metrics = primary_installed or events.get("primary_update_requested")

    accepted_ms = None
    traffic_a_ms = None
    loss_b_ms = None
    if valid and start_for_metrics is not None:
        relevant = [
            row
            for row in rows
            if row.get("type") == "snapshot"
            and row["timestamp_ns"] >= start_for_metrics
        ]
        accepted_ms = duration_ms(
            relevant,
            start_for_metrics,
            end_ns,
            lambda row: row["accepted_as_a"],
            "timestamp_ns",
        )
        probe_start = phase.get("service_b_ready_ns", start_for_metrics)
        probe_samples = [
            row
            for row in probes
            if row.get("type") == "probe" and row["started_ns"] >= probe_start
        ]
        traffic_a_ms = duration_ms(
            probe_samples,
            probe_start,
            end_ns,
            lambda row: row.get("service") == "AS-A",
            "started_ns",
        )
        loss_b_ms = duration_ms(
            probe_samples,
            probe_start,
            end_ns,
            lambda row: row.get("service") != "AS-B",
            "started_ns",
        )

    probe_starts = sorted(
        row["started_ns"]
        for row in probes
        if row.get("type") == "probe" and isinstance(row.get("started_ns"), int)
    )
    probe_gaps_ms = [
        (right - left) / 1_000_000
        for left, right in zip(probe_starts, probe_starts[1:])
    ]
    p95_gap = (
        sorted(probe_gaps_ms)[math.ceil(0.95 * len(probe_gaps_ms)) - 1]
        if probe_gaps_ms
        else None
    )
    snapshots = sorted(
        (
            row
            for row in rows
            if row.get("type") == "snapshot"
            and isinstance(row.get("timestamp_ns"), int)
        ),
        key=lambda row: row["timestamp_ns"],
    )
    snapshot_gaps_ms = [
        (right["timestamp_ns"] - left["timestamp_ns"]) / 1_000_000
        for left, right in zip(snapshots, snapshots[1:])
    ]
    snapshot_gap_p95_ms = (
        sorted(snapshot_gaps_ms)[math.ceil(0.95 * len(snapshot_gaps_ms)) - 1]
        if snapshot_gaps_ms
        else None
    )
    snapshot_collection_ms = [
        row["collection_duration_ms"]
        for row in snapshots
        if isinstance(row.get("collection_duration_ms"), (int, float))
    ]
    snapshot_collection_p95_ms = (
        sorted(snapshot_collection_ms)[
            math.ceil(0.95 * len(snapshot_collection_ms)) - 1
        ]
        if snapshot_collection_ms
        else None
    )
    failover_ns = phase.get("failover_data_verified_ns")
    probe_left_as_b = next(
        (
            probe
            for probe in probes
            if phase.get("service_b_ready_ns") is not None
            and failover_ns is not None
            and probe.get("type") == "probe"
            and probe.get("started_ns", 0) >= failover_ns
            and probe.get("service") not in (None, "AS-B")
        ),
        None,
    )
    detail_snapshot = next(
        (
            row
            for row in rows
            if row.get("type") == "snapshot"
            and failover_ns is not None
            and row["timestamp_ns"] >= failover_ns
        ),
        next((row for row in reversed(rows) if row.get("type") == "snapshot"), {}),
    )
    states = detail_snapshot.get("state_by_prefix", {})
    primary_update_states = phase.get("primary_update_snapshot", {}).get(
        "state_by_prefix", {}
    )

    return {
        "trial_id": trial_id,
        "scenario": scenario,
        "replication": repetition,
        "scenario_valid": valid,
        "failover_verified": phase.get("failover_verified", False),
        "invalid_reason": phase.get("invalid_reason", ""),
        "primary_update_requested_ns": events.get("primary_update_requested"),
        "primary_vrp_installed_ns": primary_installed,
        "service_b_ready_before_failover": (
            phase.get("service_b_ready_ns") is not None
        ),
        "service_b_ready_before_failover_ns": phase.get("service_b_ready_ns"),
        "primary_update_accepted_as_a_by_prefix": json.dumps(
            {
                prefix: AS_A in state["accepted_asns"]
                for prefix, state in primary_update_states.items()
            },
            sort_keys=True,
        ),
        "primary_update_selected_rib_as_by_prefix": json.dumps(
            {
                prefix: state["selected_rib_as"]
                for prefix, state in primary_update_states.items()
            },
            sort_keys=True,
        ),
        "primary_update_selected_fib_as_by_prefix": json.dumps(
            {
                prefix: state["selected_fib_as"]
                for prefix, state in primary_update_states.items()
            },
            sort_keys=True,
        ),
        "primary_rtr_stopped_ns": events.get("primary_rtr_stopped"),
        "failover_data_verified_ns": phase.get("failover_data_verified_ns"),
        "backup_update_requested_ns": events.get("backup_update_requested"),
        "service_b_restored_ns": phase.get("service_b_restored_ns"),
        "measurement_end_ns": end_ns,
        "accepted_as_a_after_withdrawal_ms": accepted_ms,
        "traffic_to_as_a_after_withdrawal_ms": traffic_a_ms,
        "loss_of_service_b_ms": loss_b_ms,
        "probe_interval_ms_configured": PROBE_INTERVAL_MS,
        "probe_gap_p95_ms": p95_gap,
        "probe_gap_max_ms": max(probe_gaps_ms) if probe_gaps_ms else None,
        "probe_count": len(probes),
        "snapshot_interval_ms_configured": int(POLL_SECONDS * 1000),
        "snapshot_gap_p95_ms": snapshot_gap_p95_ms,
        "snapshot_gap_max_ms": max(snapshot_gaps_ms) if snapshot_gaps_ms else None,
        "snapshot_collection_p95_ms": snapshot_collection_p95_ms,
        "snapshot_collection_max_ms": (
            max(snapshot_collection_ms) if snapshot_collection_ms else None
        ),
        "snapshot_count": len(snapshots),
        "tested_prefix_count": PREFIX_COUNT,
        "tested_prefixes": json.dumps(PREFIXES),
        "accepted_as_a_by_prefix": json.dumps(
            {
                prefix: AS_A in state["accepted_asns"]
                for prefix, state in states.items()
            },
            sort_keys=True,
        ),
        "selected_rib_as_by_prefix": json.dumps(
            {prefix: state["selected_rib_as"] for prefix, state in states.items()},
            sort_keys=True,
        ),
        "selected_fib_as_by_prefix": json.dumps(
            {prefix: state["selected_fib_as"] for prefix, state in states.items()},
            sort_keys=True,
        ),
        "probe_left_as_b_ns": (
            probe_left_as_b.get("started_ns") if probe_left_as_b else None
        ),
        "probe_left_as_b_service": (
            probe_left_as_b.get("service") if probe_left_as_b else None
        ),
        "probe_left_as_b_after_backup_ms": (
            (probe_left_as_b["started_ns"] - failover_ns) / 1_000_000
            if probe_left_as_b and failover_ns is not None
            else None
        ),
    }


def run_trial(
    scenario, repetition, hold_seconds, output_dir, failover_wait_seconds=45,
    require_as_b_baseline=False,
):
    global ACTIVE_SNAPSHOT_MONITOR

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    trial_id = f"{stamp}_{scenario}_{repetition:02d}"
    rows = []
    phase = {
        "scenario_valid": False,
        "failover_verified": False,
        "invalid_reason": "",
    }
    probes = []
    primary_stopped = False
    snapshot_monitor = None

    try:
        start_stack()
        snapshot_monitor = SnapshotMonitor(rows)
        snapshot_monitor.start()
        ACTIVE_SNAPSHOT_MONITOR = snapshot_monitor
        primary_initial_state = container_json(RTR_PRIMARY, 8080, "/state")
        backup_initial_state = container_json(RTR_BACKUP, 8080, "/state")
        backup_initial_events = container_json(RTR_BACKUP, 8080, "/events").get(
            "events", []
        )
        log_event(
            rows,
            "rtr_initial_state",
            primary=primary_initial_state,
            backup=backup_initial_state,
            backup_event_count=len(backup_initial_events),
        )
        if not rtr_state_matches(primary_initial_state, AS_A) or not rtr_state_matches(
            backup_initial_state, AS_A
        ):
            raise RuntimeError("both RTR servers must start with the AS-A VRP set")
        ensure_bgp_and_initial_state(rows)
        update_cache(RTR_PRIMARY, AS_B, rows, "primary_update")
        if scenario in EXPIRY_SCENARIOS:
            baseline = wait_for(
                lambda item: item is not None and item["installed_vrp_origins"] == [AS_B],
                rows, 20, "baseline VRP installation",
            )
            if baseline is None or baseline["installed_vrp_origins"] != [AS_B]:
                raise RuntimeError("baseline VRP for AS-B was not installed")
            compose("exec", "-T", "dut", "vtysh", "-c", "clear bgp ipv4 unicast * soft in")
            log_event(rows, "baseline_inbound_refresh")
        snap = wait_for(
            expected_as_b_vrp_state, rows, 20, "primary VRP installation"
        )
        if expected_as_b_vrp_state(snap):
            phase["primary_vrp_installed_ns"] = snap["timestamp_ns"]
            phase["primary_update_snapshot"] = snap
            log_event(
                rows,
                "primary_vrp_installed",
                origins=[AS_B],
                accepted_as_a_by_prefix=snap["accepted_as_a_by_prefix"],
                selected_rib_as_by_prefix={
                    prefix: state["selected_rib_as"]
                    for prefix, state in snap["state_by_prefix"].items()
                },
                selected_fib_as_by_prefix={
                    prefix: state["selected_fib_as"]
                    for prefix, state in snap["state_by_prefix"].items()
                },
            )
        else:
            phase["invalid_reason"] = (
                "primary update did not install the AS-B-only VRP state "
                "while both BGP sessions remained established"
            )

        if phase.get("primary_vrp_installed_ns") is not None:
            data_deadline = time.monotonic() + 8
            while time.monotonic() < data_deadline and last_probe_service() != "AS-B":
                time.sleep(0.1)
            if last_probe_service() == "AS-B":
                phase["service_b_ready_ns"] = now_ns()
                log_event(rows, "service_b_ready_before_failover")
            else:
                log_event(
                    rows,
                    "service_b_not_reached_before_failover",
                    last_probe_service=last_probe_service(),
                )

        if scenario in EXPIRY_SCENARIOS and phase["invalid_reason"]:
            raise RuntimeError(phase["invalid_reason"])
        if scenario in EXPIRY_SCENARIOS:
            log_event(rows, "baseline_bgp_table", **vtysh("show bgp ipv4 unicast"))

        if scenario == "primary-blackhole":
            log_event(rows, "primary_rtr_blackhole_requested")
            compose("exec", "-T", "dut", "tc", "qdisc", "add", "dev", "eth0", "clsact")
            block = ("exec", "-T", "dut", "tc", "filter", "add", "dev", "eth0")
            compose(*block, "egress", "protocol", "ip", "flower", "skip_hw",
                    "dst_ip", "198.18.2.21", "ip_proto", "tcp", "dst_port", "3323", "action", "drop")
            compose(*block, "ingress", "protocol", "ip", "flower", "skip_hw",
                    "src_ip", "198.18.2.21", "ip_proto", "tcp", "src_port", "3323", "action", "drop")
            log_event(rows, "primary_rtr_blackhole_active")

        if scenario == "updated-backup":
            update_cache(RTR_BACKUP, AS_B, rows, "backup_update")

        if require_as_b_baseline:
            expected_backup_origin = AS_A if scenario == "stale-backup" else AS_B
            backup_state = container_json(RTR_BACKUP, 8080, "/state")
            baseline = snapshot()
            if (
                not rtr_state_matches(backup_state, expected_backup_origin)
                or not expected_new_state(baseline)
                or not baseline["cache_connected_primary"]
                or baseline["cache_connected_backup"]
                or phase.get("service_b_ready_ns") is None
                or last_probe_service() != "AS-B"
            ):
                raise RuntimeError("required pre-failover AS-B baseline was not established")
            log_event(
                rows, "controlled_baseline_verified",
                snapshot_timestamp_ns=baseline["timestamp_ns"],
                backup_origin=expected_backup_origin,
            )

        if scenario in ("stale-backup", "updated-backup", "primary-expiry"):
            cut_requested_ns = now_ns()
            log_event(rows, "primary_rtr_stop_requested")
            reply = container_json(RTR_PRIMARY, 8080, "/disconnect", {})
            if reply.get("disconnected") is not True:
                raise RuntimeError("primary RTR listener did not acknowledge disconnection")
            primary_stopped = True
            log_event(
                rows, "primary_rtr_stopped", failover_wait_seconds=failover_wait_seconds
            )

        if scenario in EXPIRY_SCENARIOS:
            log_event(rows, "expiry_observation_started", seconds=hold_seconds)
            hold_and_observe(hold_seconds, rows)
            log_event(rows, "expiry_observation_completed")
            observed = [
                row for row in rows
                if row.get("type") == "snapshot"
                and row["timestamp_ns"] >= phase.get("service_b_ready_ns", float("inf"))
            ]
            phase["scenario_valid"] = (
                not phase["invalid_reason"]
                and bool(observed)
            )
            if scenario == "primary-blackhole":
                counters = {}
                for direction in ("ingress", "egress"):
                    evidence = compose("exec", "-T", "dut", "tc", "-s", "filter",
                                       "show", "dev", "eth0", direction).stdout
                    counters[direction] = evidence
                log_event(rows, "primary_rtr_blackhole_counters", **counters)
                phase["scenario_valid"] &= any(
                    re.search(r"Sent \d+ bytes [1-9]\d* pkt", evidence)
                    for evidence in counters.values()
                )
            else:
                expected_primary = scenario == "expiry-control"
                phase["scenario_valid"] &= all(
                    row["cache_connected_primary"] is expected_primary for row in observed
                )
            if not phase["scenario_valid"] and not phase["invalid_reason"]:
                phase["invalid_reason"] = "RTR primary state was not verified throughout the observation"

        elif scenario in ("stale-backup", "updated-backup"):
            expected_origins = [AS_A] if scenario == "stale-backup" else [AS_B]
            expected_failover_state = (
                expected_stale_backup_data
                if scenario == "stale-backup"
                else expected_as_b_vrp_state
            )
            failover = wait_for(
                lambda item: (
                    item is not None
                    and item["cache_connected_primary"] is False
                    and item["cache_connected_backup"] is True
                    and (
                        (
                            scenario == "stale-backup"
                            and expected_stale_backup_data(item)
                        )
                        or (
                            scenario == "updated-backup"
                            and item["installed_vrp_origins"] == expected_origins
                            and expected_as_b_vrp_state(item)
                        )
                    )
                ),
                rows,
                failover_wait_seconds,
                "RTR backup data use",
            )
            if (
                failover is not None
                and failover["cache_connected_primary"] is False
                and failover["cache_connected_backup"] is True
                and (
                    (
                        scenario == "stale-backup"
                        and expected_stale_backup_data(failover)
                    )
                    or (
                        scenario == "updated-backup"
                        and failover["installed_vrp_origins"] == expected_origins
                        and expected_as_b_vrp_state(failover)
                    )
                )
                and expected_failover_state(failover)
            ):
                backup_events = container_json(
                    RTR_BACKUP, 8080, "/events"
                ).get("events", [])
                new_backup_events = backup_events[len(backup_initial_events):]
                reset_query_seen = any(
                    event.get("event") == "reset_query"
                    and (not require_as_b_baseline or event["timestamp_ns"] >= cut_requested_ns)
                    for event in new_backup_events
                )
                if reset_query_seen:
                    phase["failover_verified"] = True
                    phase["failover_data_verified_ns"] = failover["timestamp_ns"]
                    log_event(
                        rows,
                        "backup_data_use_verified",
                        origins=failover["installed_vrp_origins"],
                        primary_connected=False,
                        backup_connected=True,
                        connected_cache_group=failover["connected_cache_group"],
                        backup_reset_query_seen=True,
                        backup_rtr_events=new_backup_events,
                    )
                elif not phase["invalid_reason"]:
                    phase["invalid_reason"] = (
                        "backup connection and VRP state appeared, but the "
                        "backup RTR log did not show a new Reset Query"
                    )
            elif not phase["invalid_reason"]:
                phase["invalid_reason"] = (
                    "invalid for the research question: FRR did not show the "
                    "primary disconnected, backup connected, and expected "
                    "backup VRPs installed"
                )

            hold_and_observe(hold_seconds, rows)

            if require_as_b_baseline:
                log_event(rows, "backup_exposure_completed")
            if scenario == "stale-backup":
                update_cache(RTR_BACKUP, AS_B, rows, "backup_update")
            restored = wait_for(
                expected_as_b_vrp_state, rows, 20, "AS-B VRP restoration"
            )
            if expected_as_b_vrp_state(restored):
                phase["backup_vrp_installed_ns"] = restored["timestamp_ns"]
                log_event(
                    rows,
                    "as_b_vrps_installed_after_backup_update",
                    origins=restored["installed_vrp_origins"],
                )
                data_deadline = time.monotonic() + 8
                while time.monotonic() < data_deadline and last_probe_service() != "AS-B":
                    time.sleep(0.1)
                if last_probe_service() == "AS-B":
                    phase["service_b_restored_ns"] = now_ns()
                    log_event(rows, "service_b_restored")
                else:
                    log_event(
                        rows,
                        "service_b_not_restored_before_deadline",
                        last_probe_service=last_probe_service(),
                    )
            elif not phase["invalid_reason"]:
                phase["invalid_reason"] = (
                    "backup update did not install the AS-B-only VRP state"
                )

            phase["scenario_valid"] = (
                phase["failover_verified"]
                and not phase["invalid_reason"]
                and phase.get("primary_vrp_installed_ns") is not None
                and phase.get("backup_vrp_installed_ns") is not None
            )
        else:
            hold_and_observe(hold_seconds, rows)
            latest_snapshot = next(
                (
                    row for row in reversed(rows)
                    if row.get("type") == "snapshot"
                ),
                None,
            )
            phase["scenario_valid"] = (
                not phase["invalid_reason"]
                and last_probe_service() == "AS-B"
                and expected_new_state(latest_snapshot)
            )
            if not phase["scenario_valid"] and not phase["invalid_reason"]:
                phase["invalid_reason"] = (
                    "uninterrupted-RTR control did not retain AS-B service"
                )

    except Exception as exc:
        phase["invalid_reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        if snapshot_monitor is not None:
            try:
                snapshot_monitor.stop()
            except Exception as exc:
                phase["scenario_valid"] = False
                if not phase["invalid_reason"]:
                    phase["invalid_reason"] = (
                        f"snapshot monitor shutdown failed: "
                        f"{type(exc).__name__}: {exc}"
                    )
                rows.append(
                    {
                        "type": "runner",
                        "timestamp_ns": now_ns(),
                        "event": "snapshot_monitor_shutdown_error",
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )
            ACTIVE_SNAPSHOT_MONITOR = None
        phase["measurement_end_ns"] = now_ns()
        interval_start = next(
            (
                row["timestamp_ns"]
                for row in rows
                if row.get("type") == "runner"
                and row.get("event") == "primary_rtr_stopped"
            ),
            phase.get("primary_vrp_installed_ns", 0),
        )
        observed_peer_states = [
            row["bgp_sessions_established"]
            for row in rows
            if row.get("type") == "snapshot"
            and row["timestamp_ns"] >= interval_start
        ]
        phase["bgp_sessions_continuous"] = bool(observed_peer_states) and all(
            observed_peer_states
        )
        if not phase["bgp_sessions_continuous"]:
            phase["scenario_valid"] = False
            if not phase["invalid_reason"]:
                phase["invalid_reason"] = (
                    "both BGP sessions were not observed established throughout "
                    "the measured interval"
                )
        try:
            container_json("client", 8080, "/stop", {})
            probes = probe_events()
            if scenario in EXPIRY_SCENARIOS and not any(
                probe["started_ns"] >= phase.get("service_b_ready_ns", float("inf"))
                for probe in probes
            ):
                phase["scenario_valid"] = False
                if not phase["invalid_reason"]:
                    phase["invalid_reason"] = "no HTTP probes recorded in the observation window"
            rows.extend(cache_events(RTR_BACKUP))
            rows.extend(cache_events(RTR_PRIMARY))
        except Exception as exc:
            rows.append(
                {
                    "type": "runner",
                    "timestamp_ns": now_ns(),
                    "event": "evidence_collection_error",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
        try:
            logs = compose(
                "logs",
                "--no-color",
                "--timestamps",
                "rtr-primary",
                "rtr-backup",
                "dut",
                "as-a",
                "as-b",
                "client",
                check=False,
                timeout=15,
            )
            rows.append(
                {
                    "type": "container_logs",
                    "timestamp_ns": now_ns(),
                    "services": [
                        "rtr-primary",
                        "rtr-backup",
                        "dut",
                        "as-a",
                        "as-b",
                        "client",
                    ],
                    "output": logs.stdout + logs.stderr,
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "type": "runner",
                    "timestamp_ns": now_ns(),
                    "event": "container_log_collection_error",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
        if not primary_stopped:
            try:
                compose("stop", "rtr-primary", check=False)
            except Exception:
                pass
        compose("down", "--remove-orphans", check=False)

    raw_path = output_dir / "raw" / f"{trial_id}.jsonl"
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    combined = rows + probes
    combined.sort(key=lambda row: row.get("timestamp_ns", row.get("started_ns", 0)))
    raw_path.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in combined),
        encoding="utf-8",
    )
    summary = analyze_run(rows, probes, scenario, trial_id, repetition, phase)
    print(
        f"{trial_id}: valid={summary['scenario_valid']} "
        f"failover_verified={summary['failover_verified']} "
        f"reason={summary['invalid_reason'] or '-'}"
    )
    return summary


def main():
    parser = argparse.ArgumentParser(
        description="Run isolated FRR/RTR ROV handoff experiments."
    )
    parser.add_argument(
        "--scenario",
        choices=SCENARIOS + EXPIRY_SCENARIOS,
        help="run one scenario; omit to run all three",
    )
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--hold-seconds", type=float, default=8)
    parser.add_argument(
        "--require-as-b-baseline", action="store_true",
        help="require AS-B alone in RIB/FIB and reachable before RTR failover",
    )
    parser.add_argument(
        "--failover-wait-seconds", type=int, default=45,
        help="maximum observation window for evidence of RTR failover (default: 45)",
    )
    args = parser.parse_args()
    if args.require_as_b_baseline and args.scenario not in ("stale-backup", "updated-backup"):
        parser.error("--require-as-b-baseline requires stale-backup or updated-backup")
    if args.repetitions < 1 or args.hold_seconds < 1:
        parser.error("--repetitions and --hold-seconds must be positive")
    if args.failover_wait_seconds < 1:
        parser.error("--failover-wait-seconds must be positive")
    if shutil.which("docker") is None:
        parser.error("Docker CLI not found; install Docker Desktop and enable Linux containers")
    engine = subprocess.run(
        ["docker", "info", "--format", "{{.OSType}}"],
        capture_output=True,
        text=True,
        timeout=15,
        check=False,
    )
    if engine.returncode or engine.stdout.strip() != "linux":
        parser.error(
            "Docker Linux engine is unavailable. Start Docker Desktop and enable "
            "the Linux container engine, then rerun this command."
        )

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = RESULTS / run_id
    output_dir.mkdir(parents=True, exist_ok=False)
    summaries = []
    compose("build", timeout=600)
    for scenario in ([args.scenario] if args.scenario else SCENARIOS):
        for repetition in range(1, args.repetitions + 1):
            summaries.append(
                run_trial(
                    scenario,
                    repetition,
                    args.hold_seconds,
                    output_dir,
                    args.failover_wait_seconds,
                    require_as_b_baseline=args.require_as_b_baseline,
                )
            )
    with (output_dir / "trial_summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerows(summaries)
    print(f"Results: {output_dir}")
    return 0 if all(row["scenario_valid"] for row in summaries) else 2


if __name__ == "__main__":
    sys.exit(main())
