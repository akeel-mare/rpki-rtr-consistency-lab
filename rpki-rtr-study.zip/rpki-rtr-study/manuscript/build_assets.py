"""Build manuscript assets only from a complete, independently audited batch."""
import argparse,csv,json,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse,FancyBboxPatch,FancyArrowPatch

ROOT=Path(__file__).resolve().parent
BLUE='#17658b';RED='#b44432';GREEN='#147d6b';GRAY='#52636d'

def server(ax,x,y,label,color=BLUE):
    ax.add_patch(FancyBboxPatch((x-.31,y-.3),.62,.60,boxstyle='round,pad=.025,rounding_size=.04',fc='#eef4f7',ec=color,lw=1.2,zorder=3))
    for k in range(3):
        yy=y-.19+k*.18
        ax.add_patch(Rectangle((x-.23,yy),.46,.12,fc='white',ec=color,lw=.65,zorder=4));ax.plot(x+.15,yy+.06,'o',ms=2,color=color,zorder=5)
    ax.text(x,y-.49,label,ha='center',va='top',fontsize=7.5,color=color,zorder=6)

def router(ax,x,y,label,color=BLUE):
    ax.add_patch(Rectangle((x-.36,y-.11),.72,.25,fc=color,ec=color,zorder=3))
    ax.add_patch(Ellipse((x,y-.11),.72,.25,fc=color,ec=color,zorder=3))
    ax.add_patch(Ellipse((x,y+.14),.72,.25,fc='#e5f0f4',ec=color,lw=1.2,zorder=4))
    for a,b in [((x-.22,y+.14),(x+.22,y+.14)),((x,y+.05),(x,y+.23))]:ax.add_patch(FancyArrowPatch(a,b,arrowstyle='<->',mutation_scale=7,color=color,lw=.8,zorder=5))
    ax.text(x,y-.41,label,ha='center',va='top',fontsize=7.5,color=color)

def arrow(ax,a,b,color=GRAY,style='-'):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=10,color=color,lw=1.2,linestyle=style,zorder=2))

def topology(dest):
    fig,ax=plt.subplots(figsize=(7.05,3.75));ax.set(xlim=(0,10),ylim=(-.35,5.0));ax.axis('off')
    ax.axhspan(2.2,4.93,color='#f4f7f9',zorder=0)
    ax.text(.12,4.69,'SIGNED AUTHORIZATION AND INDEPENDENT VALIDATION',weight='bold',fontsize=7.5,color=GRAY)
    server(ax,1.05,3.95,'Krill + local\nrsync repository')
    server(ax,4.0,3.95,'Primary RP\ncurrent VRPs: B')
    server(ax,7.65,3.95,'Standby RP\nprevious A / current B')
    arrow(ax,(1.4,4.1),(3.62,4.1));arrow(ax,(1.4,4.47),(7.28,4.47));ax.text(2.5,4.22,'signed ROAs',ha='center',fontsize=7)
    ax.text(8.65,2.72,'Each RP pair uses\nRoutinator or FORT',ha='center',va='top',fontsize=7,color=GRAY)
    router(ax,4,1.55,'DUT: FRR or BIRD\nAS65010')
    arrow(ax,(4,3.00),(4,1.92),BLUE,'--');ax.text(4.13,2.43,'primary\nRTR',ha='left',va='center',fontsize=7)
    arrow(ax,(7.64,2.94),(4.39,1.80),RED,'--');ax.text(6.1,2.23,'standby RTR',rotation=19,fontsize=7,color=RED,bbox=dict(fc='#f4f7f9',ec='none',pad=.7))
    router(ax,7.15,1.78,'Origin A\nAS65001',RED);router(ax,7.15,.28,'Origin B\nAS65002',GREEN)
    server(ax,9.32,1.78,'HTTP: AS-A',RED);server(ax,9.32,.28,'HTTP: AS-B',GREEN)
    arrow(ax,(4.4,1.63),(6.77,1.84),RED);arrow(ax,(4.4,1.38),(6.77,.35),GREEN)
    arrow(ax,(7.55,1.83),(8.97,1.83),RED);arrow(ax,(7.55,.34),(8.97,.34),GREEN)
    ax.add_patch(Rectangle((.67,.97),.79,.49,fc='white',ec=BLUE,lw=1.2));ax.plot([.88,1.24],[.9,.9],color=BLUE)
    ax.text(1.05,.62,'Probe client\nsame destination IP',ha='center',va='top',fontsize=7.5,color=BLUE)
    arrow(ax,(1.5,1.28),(3.6,1.5),BLUE);ax.text(2.47,1.63,'HTTP requests',ha='center',fontsize=7)
    ax.text(.14,2.05,'ROUTING AND SERVICES',weight='bold',fontsize=7,color=GRAY)
    for suffix in ['pdf','svg','png']:
        metadata={'CreationDate':None,'ModDate':None} if suffix=='pdf' else {'Date':None} if suffix=='svg' else None
        fig.savefig(dest/f'topology.{suffix}',bbox_inches='tight',pad_inches=.05,dpi=220,metadata=metadata)
    plt.close(fig)

def main():
    p=argparse.ArgumentParser();p.add_argument('batch',type=Path);a=p.parse_args();batch=a.batch.resolve()
    report=json.loads((batch/'analysis/summary.json').read_text());audit=json.loads((batch/'analysis/raw_evidence_audit.json').read_text())
    assert not report['diagnostic_only'] and audit['passed'] and report['valid_runs']==audit['runs_checked']
    rows=list(csv.DictReader((batch/'analysis/run_metrics.csv').open(newline='',encoding='utf-8')))
    figdir=ROOT/'figures';figdir.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'rpki-rtr-study-v1'})
    topology(figdir)
    for name in ['policy_effect','mitigation_tradeoff','automatic_refresh']:
        for suffix in ['pdf','svg']:shutil.copy2(batch/f'analysis/{name}.{suffix}',figdir/f'{name}.{suffix}')
    for name in ['biographies.tex','author_biographies.json']:
        source=ROOT.parent/'manuscript'/name;target=ROOT/name
        if source.resolve()!=target.resolve():shutil.copy2(source,target)
    for name in ['akeel.png','hamed.png']:
        source=ROOT.parent/'manuscript/figures'/name;target=figdir/name
        if source.resolve()!=target.resolve():shutil.copy2(source,target)
    for name in ['summary.json','run_metrics.csv','raw_evidence_audit.json']:shutil.copy2(batch/'analysis'/name,ROOT/name)
    (ROOT/'experiment_manifest.json').write_text((batch/'manifest.json').read_text(),encoding='utf-8')
    macros={'TotalRuns':len(rows),'ShortRuns':sum(r['scenario']!='natural-refresh' for r in rows),'LongRuns':sum(r['scenario']=='natural-refresh' for r in rows),'MaxSnapshotGapSeconds':f"{max(float(r['snapshot_gap_max_ms']) for r in rows if r['snapshot_gap_max_ms'])/1000:.3f}",'MaxProbeGapSeconds':f"{max(float(r['probe_start_gap_max_ms']) for r in rows if r['probe_start_gap_max_ms'])/1000:.3f}"}
    for router_name,alias in [('patched','Frr'),('bird','Bird')]:
        for rp,rpalias in [('routinator',''),('fort','Fort')]:
            for scenario,scalias in [('stale-backup','Stale'),('updated-backup','Fresh')]:
                selected=[r for r in rows if (r['router'],r['rp'],r['policy'],r['scenario'],r['mechanism'])==(router_name,rp,'prefer-a',scenario,'immediate')]
                prefix=alias+rpalias+scalias
                macros[prefix+'Runs']=len(selected);macros[prefix+'ARuns']=sum(r['redirect_observed']=='True' for r in selected)
                for key in ['A','B','other','attempts']:macros[prefix+{'A':'A','B':'B','other':'Other','attempts':'Attempts'}[key]]=sum(int(r[key]) for r in selected)
    (ROOT/'numbers.tex').write_text('\n'.join('\\newcommand{\\'+key+'}{'+str(value)+'}' for key,value in macros.items())+'\n',encoding='utf-8')
    table=['\\begin{table*}[t]','\\caption{Measured tradeoffs under the previous standby view (Routinator, A-preferred policy). Percentages are means of three run-level fractions using all attempts. Next B is the first successful B request start after the restore trigger, including actual refresh/controller operations; it is not an outage duration when B remains available. Ranges retain runs, with an observed count if censored.}','\\label{tab:mitigation}\\centering\\footnotesize\\setlength{\\tabcolsep}{4pt}','\\begin{tabular}{llrrrrll}','\\toprule','Router & Control & Runs & A (\\%) & B (\\%) & Other (\\%) & Precheck (ms) & Next B (s) \\\\','\\midrule']
    for router_name in ['patched','bird']:
        for mechanism in ['immediate','gate','fail-safe']:
            group=next(g for g in report['groups'] if (g['router'],g['rp'],g['policy'],g['scenario'],g['mechanism'])==(router_name,'routinator','prefer-a','stale-backup',mechanism))
            rs=[r for r in rows if (r['router'],r['rp'],r['policy'],r['scenario'],r['mechanism'])==(router_name,'routinator','prefer-a','stale-backup',mechanism)]
            meanother=np.mean([int(r['other'])/int(r['attempts']) for r in rs])*100
            def interval(key,scale=1):
                values=group[key+'_range'];digits=0 if scale==1 else 3
                count=sum(r[key] not in ['',None] for r in rs)
                value='--' if values is None else f'{values[0]/scale:.{digits}f}--{values[1]/scale:.{digits}f}'
                return value+(f' ({count}/{len(rs)})' if count<len(rs) else '')
            table.append(' & '.join(['FRR patched' if router_name=='patched' else 'BIRD',{'immediate':'Immediate','gate':'Expected-view gate','fail-safe':'Deny on disagreement'}[mechanism],str(group['runs']),f"{100*group['mean_run_A_fraction']:.1f}",f"{100*group['mean_run_B_fraction']:.1f}",f'{meanother:.1f}',interval('preflight_cost_ms'),interval('first_B_request_start_after_update_ms',1000)])+' \\\\')
    table.extend(['\\bottomrule','\\end{tabular}','\\end{table*}'])
    (ROOT/'mitigation_table.tex').write_text('\n'.join(table)+'\n',encoding='utf-8')
    print(json.dumps({'manuscript_assets':str(ROOT),'runs':len(rows),'batch':batch.name},indent=2))

if __name__=='__main__':main()
