"""Compile the article with an installed IEEEtran-capable LaTeX toolchain."""
import os,shutil,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def executable(name):
    found=shutil.which(name)
    if found:return found
    if os.name=='nt':
        candidate=Path(os.environ['LOCALAPPDATA'])/'Programs/MiKTeX/miktex/bin/x64'/(name+'.exe')
        if candidate.is_file():return str(candidate)
    raise RuntimeError('Install a LaTeX toolchain with IEEEtran and make '+name+' available')

def main():
    latex=executable('pdflatex');bibtex=executable('bibtex')
    command=[latex,'-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-jobname=RPKI_IEEE','main.tex']
    for index,args in enumerate([command,[bibtex,'RPKI_IEEE'],command,command],1):
        result=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,errors='replace')
        (ROOT/f'build-pass-{index}.log').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        if result.returncode:raise RuntimeError('Article build failed; inspect '+str(ROOT/f'build-pass-{index}.log'))
    print(ROOT/'RPKI_IEEE.pdf')

if __name__=='__main__':main()
