"""Compare FRR at the PR base and with PR #24131 applied."""

import argparse
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
BASE_COMMIT = "ce548b0d3354bb78f58137b11ed9ce1ebab8259a"
PATCH_COMMIT = "c78f874369aed652fade980cf3f6c4f1b39d912b"
BASE_IMAGE = f"rov-frr-pr24131:base-{BASE_COMMIT[:8]}"
PATCHED_IMAGE = f"rov-frr-pr24131:patched-{PATCH_COMMIT[:8]}"
IMAGE_MANIFEST = ROOT / "tmp" / "pr24131" / "image-manifest.json"
PATCH_FILE = ROOT / "tmp" / "pr24131" / "pr24131.patch"
LAB_FILES = (
    "compose.yaml",
    "Dockerfile",
    "app_server.py",
    "client_agent.py",
    "rtr_server.py",
    "run_lab.py",
    "frr/daemons",
    "frr/dut.conf",
    "frr/as-a.conf",
    "frr/as-b.conf",
)


def command_output(command):
    result = subprocess.run(
        command, capture_output=True, text=True, check=False, cwd=ROOT
    )
    if result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {' '.join(command)}\n"
            f"{result.stdout}{result.stderr}"
        )
    return result.stdout.strip()


def image_id(image):
    return command_output(["docker", "image", "inspect", "--format={{.Id}}", image])


def load_preparation_manifest():
    if not IMAGE_MANIFEST.is_file():
        raise RuntimeError(
            "Image preparation manifest is missing; run .\\prepare_pr24131.ps1 first."
        )
    manifest = json.loads(IMAGE_MANIFEST.read_text(encoding="utf-8-sig"))
    if manifest.get("base_commit") != BASE_COMMIT:
        raise RuntimeError("Prepared base commit does not match the pinned PR base.")
    if manifest.get("patched_commit") != PATCH_COMMIT:
        raise RuntimeError("Prepared patched commit does not match the pinned PR head.")
    if manifest.get("patched_tree_base") != BASE_COMMIT:
        raise RuntimeError("Patched image was not prepared from the pinned base tree.")
    if not manifest.get("pr_branch_merge_base"):
        raise RuntimeError("Prepared manifest is missing the PR branch merge base.")
    if int(manifest.get("shared_rootfs_layer_prefix_count", 0)) < 10:
        raise RuntimeError("Prepared images do not share the expected dependency layers.")
    required = (
        "runtime_dockerfile_sha256",
        "base_builder_image",
        "base_builder_image_id",
        "patched_builder_image",
        "patched_builder_image_id",
    )
    if any(not manifest.get(key) for key in required):
        raise RuntimeError(
            "Preparation manifest predates the FRR runtime startup fix; "
            "rerun .\\prepare_pr24131.ps1."
        )
    runtime_dockerfile = ROOT / "pr24131-runtime" / "Dockerfile"
    runtime_hash = hashlib.sha256(runtime_dockerfile.read_bytes()).hexdigest().upper()
    if runtime_hash != manifest["runtime_dockerfile_sha256"]:
        raise RuntimeError(
            "FRR runtime Dockerfile changed after preparation; "
            "rerun .\\prepare_pr24131.ps1."
        )
    return manifest


def copy_lab(destination, prefix_count):
    for relative_path in LAB_FILES:
        source = ROOT / relative_path
        target = destination / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    if prefix_count == 2:
        for relative_path in ("frr/as-a.conf", "frr/as-b.conf"):
            path = destination / relative_path
            content = path.read_text(encoding="utf-8")
            content = content.replace(
                "ip route 198.18.0.0/24 Null0\n",
                "ip route 198.18.0.0/24 Null0\n"
                "ip route 198.18.1.0/24 Null0\n",
            )
            content = content.replace(
                "  network 198.18.0.0/24\n",
                "  network 198.18.0.0/24\n"
                "  network 198.18.1.0/24\n",
            )
            path.write_text(content, encoding="utf-8", newline="\n")

        dut = destination / "frr/dut.conf"
        content = dut.read_text(encoding="utf-8").replace(
            "ip route 198.18.0.0/24 Null0 254\n",
            "ip route 198.18.0.0/24 Null0 254\n"
            "ip route 198.18.1.0/24 Null0 254\n",
        )
        dut.write_text(content, encoding="utf-8", newline="\n")


def run_case(batch, image, variant, prefix_count, repetition, args, scenario="stale-backup"):
    case_label = scenario if args.compare_backup_freshness else variant
    case_name = f"{case_label}_{prefix_count}prefix_{repetition:02d}"
    case_dir = batch / case_name
    case_dir.mkdir(parents=True, exist_ok=False)
    copy_lab(case_dir, prefix_count)

    environment = os.environ.copy()
    environment["ROV_DUT_IMAGE"] = image
    environment["ROV_PREFIX_COUNT"] = str(prefix_count)
    if args.compare_backup_freshness:
        environment["ROV_COMPOSE_PROJECT"] = f"rov-{batch.name.lower()}"
        dut = case_dir / "frr/dut.conf"
        config = dut.read_text(encoding="utf-8")
        default_policy = "neighbor 198.18.2.11 route-map ROV-IN in"
        if config.count(default_policy) != 1:
            raise RuntimeError("Could not set the controlled AS-A inbound policy")
        config = config.replace(default_policy, default_policy.replace("ROV-IN", "ROV-PREFER-A"))
        config += (
            "\nroute-map ROV-PREFER-A deny 10\n match rpki invalid\n"
            "route-map ROV-PREFER-A permit 20\n set local-preference 200\n"
        )
        dut.write_text(config, encoding="utf-8", newline="\n")
    run_command = [
        sys.executable,
        "-u",
        "run_lab.py",
        "--scenario",
        scenario,
        "--repetitions",
        "1",
        "--hold-seconds",
        str(args.hold_seconds),
        "--failover-wait-seconds",
        str(args.failover_wait_seconds),
    ]
    if args.compare_backup_freshness:
        run_command.append("--require-as-b-baseline")
    print(f"Starting {case_name}", flush=True)
    with (case_dir / "runner.log").open("w", encoding="utf-8") as log:
        result = subprocess.run(
            run_command,
            cwd=case_dir,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )

    summaries = list((case_dir / "results").glob("*/trial_summary.csv"))
    row = {}
    if len(summaries) == 1:
        with summaries[0].open(newline="", encoding="utf-8") as stream:
            row = next(csv.DictReader(stream))
    elif len(summaries) > 1:
        raise RuntimeError(f"Expected one trial summary in {case_dir}")

    row.update(
        scenario=scenario,
        image_variant=variant,
        frr_image=image,
        frr_image_id=image_id(image),
        base_commit=BASE_COMMIT,
        pr_commit=PATCH_COMMIT if variant == "patched" else "",
        prefix_count=prefix_count,
        repetition=repetition,
        runner_exit=result.returncode,
        raw_result_dir=str(summaries[0].parent.relative_to(batch))
        if summaries
        else "",
    )
    print(
        f"{case_name}: valid={row.get('scenario_valid', 'missing')} "
        f"failover={row.get('failover_verified', 'missing')} "
        f"AS-A-probe={row.get('probe_left_as_b_service', '') or '-'}",
        flush=True,
    )
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--hold-seconds", type=float, default=8)
    parser.add_argument("--failover-wait-seconds", type=int, default=45)
    parser.add_argument(
        "--compare-backup-freshness", action="store_true",
        help="compare current and stale RTR backup data on patched FRR with preferred AS-A",
    )
    args = parser.parse_args()
    if args.repetitions < 1 or args.hold_seconds < 1 or args.failover_wait_seconds < 1:
        parser.error("repetitions and time windows must be positive")

    engine = command_output(["docker", "info", "--format={{.OSType}}"])
    if engine != "linux":
        parser.error("Docker Linux engine is required")
    preparation = load_preparation_manifest()
    if image_id(preparation["base_builder_image"]) != preparation["base_builder_image_id"]:
        parser.error("Base builder image changed after preparation; rerun the preparation script.")
    if (
        image_id(preparation["patched_builder_image"])
        != preparation["patched_builder_image_id"]
    ):
        parser.error(
            "Patched builder image changed after preparation; rerun the preparation script."
        )
    base_id = image_id(BASE_IMAGE)
    patched_id = image_id(PATCHED_IMAGE)
    if base_id != preparation.get("base_image_id"):
        parser.error("Base image ID changed after preparation; rebuild the comparison images.")
    if patched_id != preparation.get("patched_image_id"):
        parser.error("Patched image ID changed after preparation; rebuild the comparison images.")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    batch_type = "backup-freshness" if args.compare_backup_freshness else "comparison"
    batch = RESULTS / f"pr24131-{batch_type}-{stamp}"
    batch.mkdir(parents=True, exist_ok=False)
    manifest = {
        "pr": 24131,
        "base_commit": BASE_COMMIT,
        "patched_commit": PATCH_COMMIT,
        "base_image": BASE_IMAGE,
        "base_image_id": base_id,
        "patched_image": PATCHED_IMAGE,
        "patched_image_id": patched_id,
        "patched_tree_base": preparation["patched_tree_base"],
        "pr_branch_merge_base": preparation["pr_branch_merge_base"],
        "patched_changed_files": preparation["patched_changed_files"],
        "patch_sha256": preparation["patch_sha256"],
        "ubuntu_version": preparation["ubuntu_version"],
        "apt_retries": preparation["apt_retries"],
        "enable_lttng": preparation["enable_lttng"],
        "dockerfile_sha256": preparation["dockerfile_sha256"],
        "runtime_dockerfile_sha256": preparation["runtime_dockerfile_sha256"],
        "base_builder_image": preparation["base_builder_image"],
        "base_builder_image_id": preparation["base_builder_image_id"],
        "patched_builder_image": preparation["patched_builder_image"],
        "patched_builder_image_id": preparation["patched_builder_image_id"],
        "shared_rootfs_layer_prefix_count": preparation[
            "shared_rootfs_layer_prefix_count"
        ],
        "base_rootfs_layers": preparation["base_rootfs_layers"],
        "patched_rootfs_layers": preparation["patched_rootfs_layers"],
        "prefixes": ["198.18.0.0/24", "198.18.1.0/24"],
        "scenario": "stale-backup",
        "repetitions": args.repetitions,
        "hold_seconds": args.hold_seconds,
        "failover_wait_seconds": args.failover_wait_seconds,
        "isolation": "Docker internal network; each trial runs serially with compose reset",
    }
    if args.compare_backup_freshness:
        manifest.update(
            prefixes=["198.18.0.0/24"],
            scenario=["updated-backup", "stale-backup"],
            dut_image=PATCHED_IMAGE,
            as_a_local_preference=200,
            require_as_b_baseline=True,
        )
    (batch / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    if PATCH_FILE.is_file():
        shutil.copy2(PATCH_FILE, batch / "pr24131.patch")

    rows = []
    for repetition in range(1, args.repetitions + 1):
        if args.compare_backup_freshness:
            scenarios = ("updated-backup", "stale-backup")
            if repetition % 2 == 0:
                scenarios = scenarios[::-1]
            for scenario in scenarios:
                rows.append(run_case(batch, PATCHED_IMAGE, "patched", 1, repetition, args, scenario))
            continue
        for variant, image in (("base", BASE_IMAGE), ("patched", PATCHED_IMAGE)):
            for prefix_count in (1, 2):
                rows.append(
                    run_case(
                        batch, image, variant, prefix_count, repetition, args
                    )
                )

    fields = list(dict.fromkeys(key for row in rows for key in row))
    with (batch / "comparison_summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Comparison results: {batch}")
    valid_rows = sum(
        str(row.get("scenario_valid", "")).lower() == "true"
        and str(row.get("failover_verified", "")).lower() == "true"
        for row in rows
    )
    if valid_rows != len(rows):
        print(
            f"WARNING: only {valid_rows}/{len(rows)} runs met the scenario checks."
        )
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
