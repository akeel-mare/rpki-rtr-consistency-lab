"""Run the prespecified extension sequentially; retain every failed attempt."""
import argparse,csv,hashlib,json,random,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
def conditions():
    out=[]
    for router in ['patched','bird']:
        for policy in ['prefer-a','equal','prefer-b']:
            for scenario in ['stale-backup','updated-backup','concurrent-inconsistent']:
                out.append(dict(router=router,rp='routinator',policy=policy,scenario=scenario,mechanism='immediate'))
        for scenario in ['no-rtr-outage','blackhole','authorization-empty','authorization-unrelated','route-withdrawal']:
            out.append(dict(router=router,rp='routinator',policy='prefer-a',scenario=scenario,mechanism='immediate'))
        for scenario in ['stale-backup','updated-backup']:
            out.append(dict(router=router,rp='fort',policy='prefer-a',scenario=scenario,mechanism='immediate'))
        for mechanism in ['gate','fail-safe']:
            out.append(dict(router=router,rp='routinator',policy='prefer-a',scenario='stale-backup',mechanism=mechanism))
    for scenario in ['stale-backup','updated-backup']:
        out.append(dict(router='base',rp='routinator',policy='prefer-a',scenario=scenario,mechanism='immediate'))
    return out
def save(batch,results):
    columns=sorted({k for row in results for k in row})
    with (batch/'matrix_summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in row.items()} for row in results)
def main():
    p=argparse.ArgumentParser();p.add_argument('--repetitions',type=int,default=3);p.add_argument('--seed',type=int,default=20261117);p.add_argument('--hold-seconds',type=float,default=8);p.add_argument('--pilot-suite',action='store_true');p.add_argument('--resume',type=Path);args=p.parse_args()
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');batch=ROOT/'results'/('extension-batch-'+stamp);batch.mkdir()
    cs=conditions()
    if args.pilot_suite:cs=[c for c in cs if c['policy']=='prefer-a'];args.repetitions=1
    rng=random.Random(args.seed);schedule=[]
    for rep in range(1,args.repetitions+1):
        block=[dict(c,repetition=rep) for c in cs];rng.shuffle(block);schedule.extend(block)
    if not args.pilot_suite and not args.resume:
        schedule.extend(dict(router=ro,rp='routinator',policy='prefer-a',scenario='natural-refresh',mechanism='immediate',repetition=1,hold_seconds=650) for ro in ['patched','bird'])
    (batch/'schedule.json').write_text(json.dumps(schedule,indent=2))
    manifest={'planned_trials':len(schedule),'seed':args.seed,'repetitions':args.repetitions,'hold_seconds':args.hold_seconds,'pilot_suite':args.pilot_suite,'started_utc':stamp,'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run_extended_study.py','run_extension_batch.py']},'completed':0,'trials':[]}
    results=[];valid_indices=set()
    if args.resume:
        empty_batch=batch;batch=args.resume.resolve();manifest=json.loads((batch/'manifest.json').read_text());schedule=json.loads((batch/'schedule.json').read_text());args.hold_seconds=manifest['hold_seconds']
        if (batch/'EXCLUSION_AMENDMENT.json').exists():raise RuntimeError('This cohort is excluded; start a fresh measurement batch')
        if not manifest.get('pilot_suite') and manifest['source_sha256']['run_extended_study.py']!=hashlib.sha256((ROOT/'run_extended_study.py').read_bytes()).hexdigest():raise RuntimeError('The experimental runner changed; do not mix measurement versions in one cohort')
        for item in manifest['trials']:
            raw=ROOT/'results'/item['case'];row=json.loads((raw/'outcome.json').read_text());row['raw_directory']=str(raw);row['schedule_index']=item['index'];results.append(row)
            if item['valid']:valid_indices.add(item['index'])
        manifest.setdefault('resume_history',[]).append({'utc':stamp,'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run_extended_study.py','run_extension_batch.py']}})
        # The newly reserved empty directory is retained; no previous evidence is deleted.
        (empty_batch/'REDIRECT.txt').write_text('Resumed '+str(batch))
    (batch/'manifest.json').write_text(json.dumps(manifest,indent=2));print('BATCH '+str(batch),flush=True)
    for index,item in enumerate(schedule,1):
        if index in valid_indices:continue
        label=' / '.join(str(v) for v in item.values());print(f'[{index}/{len(schedule)}] {label}',flush=True)
        before={p.name for p in (ROOT/'results').glob('extended-*')};command=[sys.executable,'-u',str(ROOT/'run_extended_study.py'),'--hold-seconds',str(item.get('hold_seconds',args.hold_seconds))]
        for key,value in item.items():
            if key!='hold_seconds':command.extend(['--'+key.replace('_','-'),str(value)])
        proc=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=1200 if item['scenario']=='natural-refresh' else 420)
        attempt=1+sum(t['index']==index for t in manifest['trials'])
        (batch/f'trial-{index:03}-attempt-{attempt:02}.log').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
        created=[d for d in (ROOT/'results').glob('extended-*') if d.name not in before]
        if len(created)!=1 or not(created[0]/'outcome.json').exists():raise RuntimeError('Missing unique trial outcome; stop rather than manufacture a result')
        result=json.loads((created[0]/'outcome.json').read_text());result['raw_directory']=str(created[0]);result['schedule_index']=index;results.append(result);save(batch,results)
        if result['scenario_valid']:valid_indices.add(index)
        manifest['completed']=len(valid_indices);manifest['trials'].append({'index':index,'case':result['case'],'valid':result['scenario_valid'],'reason':result['invalid_reason']});(batch/'manifest.json').write_text(json.dumps(manifest,indent=2))
        print(f"  valid={result['scenario_valid']} A={result.get('http_A')} B={result.get('http_B')} other={result.get('http_other')} reason={result['invalid_reason'] or '-'}",flush=True)
        if not result['scenario_valid']:
            print('STOP: repair the specific invalid condition before the measurement batch. Retained evidence: '+str(created[0]),flush=True);return 2
    print('COMPLETE '+str(batch),flush=True);return 0
if __name__=='__main__':sys.exit(main())
