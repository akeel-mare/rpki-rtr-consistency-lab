# RPKI RTR freshness laboratory

This release contains signed-ROA experiments comparing routing policy, cache-failure conditions, validator implementations, and explicit consistency controls. It includes raw RTR captures, routing and HTTP event streams, exact source/image identifiers, and independent run-level analysis.

## Reproduce saved results

Install the packages in requirements.txt and a LaTeX distribution with IEEEtran, pdflatex, and bibtex, then run `powershell -File reproduce.ps1`. This verifies raw evidence, regenerates figures, the quantitative table and group summaries, then compiles the complete article including the related-work table. It does not rerun containers. For analysis alone, run audit_extension.py and analyze_extension.py with the saved batch path.

## Run new experiments

Use Docker Desktop with Linux containers. Prepare FRR with `prepare_pr24131.ps1`, build BIRD with `docker build -t rov-study-bird:local -f extended-study/Dockerfile.bird extended-study`, and run `python run_extension_batch.py --repetitions 3 --seed 20261117 --hold-seconds 8`. Runs are sequential because the isolated networks share a fixed documentation/test prefix. New timestamped directories preserve existing evidence.

## Interpretation

BIRD handoff is controller-mediated; FRR uses native cache priorities. FORT refresh uses endpoint restart plus explicit cache reselection and its cost is included. Gate controls use operator-supplied expected authorizations and are not a global RTR serial freshness test. An eight-second hold does not measure natural expiry. Exact run-level binomial intervals are conditional model summaries, not Internet prevalence estimates.

## Licensing

At the author's request, no general license is granted for the newly authored laboratory code at this time. Public availability does not itself grant permission to reuse, modify, or redistribute that code. Third-party components retain their respective licenses.

## Third-party source

FRR PR #24131 is implementation evidence, not a peer-reviewed paper or a claim of an upstream merged release. Its patch and original license are in vendor/. The source/build revisions are frozen in the manifest.
