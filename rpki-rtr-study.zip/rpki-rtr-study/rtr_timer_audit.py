"""Validate captured RTR v1 End-of-Data timers against RFC 8210 Section 6."""
import struct
from ipaddress import IPv4Address
from run_signed_roa import read_packets

def end_of_data_timers(path):
    sessions=[];active={}
    for _,source,destination,sport,dport,flags,sequence,payload in read_packets(path):
        if sport!=3323:continue
        key=(source,destination,sport,dport)
        base=(sequence+1)&0xffffffff if flags&2 else sequence
        if key not in active or (flags&2 and active[key]['base']!=base):
            stream={'source':source,'client_port':dport,'base':base,'segments':[]};active[key]=stream;sessions.append(stream)
        if payload:
            stream=active[key];stream['segments'].append(((sequence-stream['base'])&0xffffffff,payload))
    records=[]
    for stream in sessions:
        buffer=bytearray();position=0
        for offset,payload in sorted(stream['segments'],key=lambda item:item[0]):
            if offset>position:raise ValueError('Gap in captured RTR server stream; timer coverage cannot be verified')
            overlap=position-offset
            if overlap<len(payload):buffer.extend(payload[overlap:]);position=offset+len(payload)
        offset=0
        while offset+8<=len(buffer):
            version,kind=buffer[offset:offset+2];length=int.from_bytes(buffer[offset+4:offset+8],'big')
            if length<8 or offset+length>len(buffer):break
            if version==1 and kind==7 and length==24:
                refresh,retry,expire=struct.unpack_from('!III',buffer,offset+12)
                records.append({'source':str(IPv4Address(stream['source'])),'client_port':stream['client_port'],'refresh_seconds':refresh,'retry_seconds':retry,'expire_seconds':expire})
            offset+=length
    return records

def verify_timers(path):
    records=end_of_data_timers(path)
    if not records:raise ValueError('No captured RTR v1 End-of-Data timer set')
    for record in records:
        refresh,retry,expire=(record[k] for k in ['refresh_seconds','retry_seconds','expire_seconds'])
        if not (1<=refresh<=86400 and 1<=retry<=7200 and 600<=expire<=172800 and expire>max(refresh,retry)):
            raise ValueError('RFC 8210 Section 6 timer violation: '+str(record))
    return records
