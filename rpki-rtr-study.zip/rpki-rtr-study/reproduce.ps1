$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
python verify_release.py
if ($LASTEXITCODE -ne 0) { throw 'Artifact integrity verification failed' }
python audit_extension.py results/extension-batch-20261120T033447Z
if ($LASTEXITCODE -ne 0) { throw 'Raw evidence verification failed' }
python analyze_extension.py results/extension-batch-20261120T033447Z
if ($LASTEXITCODE -ne 0) { throw 'Analysis failed' }
python manuscript/build_assets.py results/extension-batch-20261120T033447Z
if ($LASTEXITCODE -ne 0) { throw 'Manuscript figure/table generation failed' }
python manuscript/build_pdf.py
if ($LASTEXITCODE -ne 0) { throw 'Article PDF build failed' }
