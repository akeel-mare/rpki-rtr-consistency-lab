import asyncio
import ipaddress
import json
import os
import struct
from http import HTTPStatus
from time import time_ns


RTR_NAME = os.environ.get("RTR_NAME", "test")
INITIAL_ASN = int(os.environ.get("RTR_INITIAL_ASN", "65001"))
PREFIX = "198.18.0.0/24"
PREFIX_COUNT = int(os.environ.get("RTR_PREFIX_COUNT", "1"))
if PREFIX_COUNT not in (1, 2):
    raise ValueError("RTR_PREFIX_COUNT must be 1 or 2")
PREFIXES = ("198.18.0.0/24", "198.18.1.0/24")[:PREFIX_COUNT]
SESSION_ID = 77


class RtrServer:
    def __init__(self):
        self.serial = 1
        self.vrps = self.make_vrps(INITIAL_ASN)
        self.clients = set()
        self.events = []

    @staticmethod
    def make_vrps(asn):
        return {(prefix, 24, asn) for prefix in PREFIXES}

    def log(self, event, **fields):
        item = {
            "type": "rtr",
            "timestamp_ns": time_ns(),
            "server": RTR_NAME,
            "event": event,
            "serial": self.serial,
            **fields,
        }
        self.events.append(item)
        print(json.dumps(item, separators=(",", ":")), flush=True)

    @staticmethod
    def prefix_pdu(vrp, withdrawal=False):
        prefix, max_length, asn = vrp
        network = ipaddress.ip_network(prefix)
        if network.version != 4:
            raise ValueError("this prototype supports IPv4 VRPs only")
        return struct.pack(
            "!BBHIBBBx4sI",
            1,
            4,
            0,
            20,
            0 if withdrawal else 1,
            network.prefixlen,
            max_length,
            network.network_address.packed,
            asn,
        )

    @staticmethod
    def fixed_pdu(pdu_type, serial=None):
        if serial is None:
            return struct.pack("!BBHI", 1, pdu_type, SESSION_ID, 8)
        return struct.pack("!BBHII", 1, pdu_type, SESSION_ID, 12, serial)

    @staticmethod
    def end_of_data_pdu(serial):
        return struct.pack("!BBHIIIII", 1, 7, SESSION_ID, 24, serial, 1, 2, 600)

    async def send_full(self, writer):
        writer.write(self.fixed_pdu(3))
        for vrp in sorted(self.vrps):
            writer.write(self.prefix_pdu(vrp))
        writer.write(self.end_of_data_pdu(self.serial))
        await writer.drain()

    async def send_delta(self, writer, known):
        writer.write(self.fixed_pdu(3))
        for vrp in sorted(known - self.vrps):
            writer.write(self.prefix_pdu(vrp, withdrawal=True))
        for vrp in sorted(self.vrps - known):
            writer.write(self.prefix_pdu(vrp))
        writer.write(self.end_of_data_pdu(self.serial))
        await writer.drain()

    async def handle_rtr(self, reader, writer):
        peer = str(writer.get_extra_info("peername"))
        known = set()
        self.clients.add(writer)
        self.log("session_open", peer=peer)
        try:
            while True:
                header = await reader.readexactly(8)
                version, pdu_type = header[0], header[1]
                length = struct.unpack("!I", header[4:8])[0]
                if version != 1 or length < 8 or length > 65536:
                    self.log("protocol_reject", peer=peer, version=version, length=length)
                    break
                body = await reader.readexactly(length - 8)
                if pdu_type == 2 and length == 8:
                    self.log("reset_query", peer=peer, version=version)
                    await self.send_full(writer)
                    known = set(self.vrps)
                elif pdu_type == 1 and length == 12:
                    requested_serial = struct.unpack("!I", body)[0]
                    self.log(
                        "serial_query",
                        peer=peer,
                        version=version,
                        requested_serial=requested_serial,
                    )
                    if requested_serial != self.serial:
                        await self.send_delta(writer, known)
                        known = set(self.vrps)
                    else:
                        writer.write(self.fixed_pdu(3))
                        writer.write(self.end_of_data_pdu(self.serial))
                        await writer.drain()
                else:
                    error_fields = {}
                    if pdu_type == 10 and len(body) >= 10:
                        encapsulated_length = struct.unpack("!I", body[:4])[0]
                        text_offset = 4 + encapsulated_length
                        if text_offset + 4 <= len(body):
                            text_length = struct.unpack(
                                "!I", body[text_offset : text_offset + 4]
                            )[0]
                            error_fields = {
                                "error_code": struct.unpack("!H", header[2:4])[0],
                                "error_text": body[
                                    text_offset + 4 : text_offset + 4 + text_length
                                ].decode("utf-8", errors="replace"),
                            }
                    self.log(
                        "unsupported_pdu",
                        peer=peer,
                        pdu_type=pdu_type,
                        body_hex=body[:256].hex(),
                        **error_fields,
                    )
                    break
        except (asyncio.IncompleteReadError, ConnectionError):
            pass
        finally:
            self.clients.discard(writer)
            writer.close()
            try:
                await writer.wait_closed()
            except ConnectionError:
                pass
            self.log("session_close", peer=peer)

    async def update(self, updated_vrps):
        previous = set(self.vrps)
        self.vrps = set(updated_vrps)
        self.serial += 1
        self.log(
            "state_updated",
            origins=sorted(vrp[2] for vrp in self.vrps),
            prefixes=sorted(vrp[0] for vrp in self.vrps),
        )
        notification = self.fixed_pdu(0, self.serial)
        for writer in list(self.clients):
            try:
                writer.write(notification)
                await writer.drain()
            except ConnectionError:
                self.clients.discard(writer)
        return previous


server = RtrServer()


async def handle_control(reader, writer):
    try:
        request_line = await reader.readline()
        if not request_line:
            return
        method, path, _version = request_line.decode("ascii").strip().split(" ", 2)
        headers = {}
        while True:
            line = await reader.readline()
            if line in (b"\r\n", b"\n", b""):
                break
            key, value = line.decode("latin1").split(":", 1)
            headers[key.strip().lower()] = value.strip()
        content_length = int(headers.get("content-length", "0"))
        body = await reader.readexactly(content_length) if content_length else b"{}"
        status = HTTPStatus.OK
        if method == "GET" and path == "/health":
            result = {"ok": True, "server": RTR_NAME}
        elif method == "GET" and path == "/state":
            result = {
                "server": RTR_NAME,
                "serial": server.serial,
                "vrps": [
                    {"prefix": pfx, "maxLength": maxlen, "asn": asn}
                    for pfx, maxlen, asn in sorted(server.vrps)
                ],
            }
        elif method == "GET" and path == "/events":
            result = {"events": list(server.events)}
        elif method == "POST" and path == "/disconnect":
            server.listener.close()
            for peer in list(server.clients):
                peer.close()
            await server.listener.wait_closed()
            server.log("rtr_listener_disabled")
            result = {"disconnected": True}
        elif method == "POST" and path == "/state":
            request = json.loads(body)
            vrps = request.get("vrps")
            if not isinstance(vrps, list) or len(vrps) != len(PREFIXES):
                raise ValueError(f"exactly {len(PREFIXES)} IPv4 VRPs are required")
            updated_vrps = set()
            for vrp in vrps:
                prefix = ipaddress.ip_network(vrp["prefix"], strict=True)
                asn = int(vrp["asn"])
                max_length = int(vrp["maxLength"])
                if prefix.version != 4 or str(prefix) not in PREFIXES:
                    raise ValueError(f"only these prefixes are allowed: {PREFIXES}")
                if not 1 <= asn <= 4294967295 or max_length != 24:
                    raise ValueError("invalid ASN or maxLength")
                updated_vrps.add((str(prefix), max_length, asn))
            if {vrp[0] for vrp in updated_vrps} != set(PREFIXES):
                raise ValueError("one VRP for each configured prefix is required")
            await server.update(updated_vrps)
            result = {
                "updated": True,
                "serial": server.serial,
                "origins": sorted({vrp[2] for vrp in updated_vrps}),
                "prefixes": sorted({vrp[0] for vrp in updated_vrps}),
            }
        else:
            status = HTTPStatus.NOT_FOUND
            result = {"error": "not found"}
    except (ValueError, KeyError, json.JSONDecodeError) as exc:
        status = HTTPStatus.BAD_REQUEST
        result = {"error": str(exc)}
    except asyncio.IncompleteReadError:
        status = HTTPStatus.BAD_REQUEST
        result = {"error": "incomplete request"}
    body = json.dumps(result).encode()
    writer.write(
        (
            f"HTTP/1.1 {status.value} {status.phrase}\r\n"
            "Content-Type: application/json\r\n"
            f"Content-Length: {len(body)}\r\n"
            "Connection: close\r\n\r\n"
        ).encode("ascii")
        + body
    )
    try:
        await writer.drain()
    finally:
        writer.close()
        await writer.wait_closed()


async def main():
    rtr = await asyncio.start_server(server.handle_rtr, "0.0.0.0", 3323)
    server.listener = rtr
    control = await asyncio.start_server(handle_control, "0.0.0.0", 8080)
    server.log("ready", rtr_port=3323, control_port=8080)
    async with rtr, control:
        await control.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
