"""Recompute run-level extension results and export inspectable scientific figures."""
import argparse,csv,json,math
from collections import defaultdict
from pathlib import Path
import numpy as np
from scipy.stats import beta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

FACTORS=['router','rp','policy','scenario','mechanism']
def exact_interval(k,n):
    return [0.0 if k==0 else float(beta.ppf(.025,k,n-k+1)),1.0 if k==n else float(beta.ppf(.975,k+1,n-k))]
def evidence_metrics(out,path):
    e=[json.loads(l) for l in (path/'evidence.jsonl').read_text().splitlines()]
    probes=sorted([x for x in e if x['type']=='probe'],key=lambda x:x['started_ns'])
    snaps=sorted([x for x in e if x['type']=='snapshot'],key=lambda x:x['timestamp_ns'])
    start,end=out['exposure_start_ns'],out['exposure_end_ns'];update=out['recovery_requested_ns']
    pp=[x for x in probes if start<=x['started_ns']<end]
    a=sum(p.get('status')==200 and p.get('service')=='AS-A' for p in pp);b=sum(p.get('status')==200 and p.get('service')=='AS-B' for p in pp);other=len(pp)-a-b
    assert [a,b,other,len(pp)]==[out['http_A'],out['http_B'],out['http_other'],out['http_total']]
    s=[x for x in snaps if start<=x['timestamp_ns']<end];assert s
    after=[p for p in probes if p['started_ns']>=update and p.get('status')==200 and p.get('service')=='AS-B']
    times=[x['timestamp_ns'] for x in s];gaps=[(b-a)/1e6 for a,b in zip(times,times[1:])]
    before=[p for p in probes if p['started_ns']<start and p.get('status')==200 and p.get('service')=='AS-B']
    first_a=next((x for x in snaps if x['timestamp_ns']>=out['intervention_ns'] and 65001 in x['state_by_prefix']['198.18.0.0/24']['accepted_asns']),None)
    clear=next((x for x in snaps if first_a and x['timestamp_ns']>first_a['timestamp_ns'] and 65001 not in x['state_by_prefix']['198.18.0.0/24']['accepted_asns']),None)
    first_ap=next((p for p in probes if p['started_ns']>=out['intervention_ns'] and p.get('service')=='AS-A' and p.get('status')==200),None)
    next_bp=next((p for p in probes if first_ap and p['started_ns']>first_ap['started_ns'] and p.get('service')=='AS-B' and p.get('status')==200),None)
    return {**{k:out[k] for k in FACTORS},'case':out['case'],'repetition':out['repetition'],'A':a,'B':b,'other':other,'attempts':len(pp),'A_fraction_of_attempts':a/len(pp),'B_fraction_of_attempts':b/len(pp),'redirect_observed':a>0,'A_admission_observed':any(65001 in x['state_by_prefix']['198.18.0.0/24']['accepted_asns'] for x in s),'verified_backup_transfer_by_hold_end':bool(out.get('end_of_data_ns') and out['end_of_data_ns']<end),'exposure_seconds':(end-start)/1e9,'preflight_cost_ms':out['preflight_cost_ms'],'snapshot_gap_max_ms':max(gaps) if gaps else None,'backup_transfer_after_cut_ms':(out['end_of_data_ns']-out['cut_ns'])/1e6 if out.get('end_of_data_ns') else None,'first_B_request_start_after_update_ms':(after[0]['started_ns']-update)/1e6 if after else None,'first_B_response_complete_after_update_ms':(after[0]['finished_ns']-update)/1e6 if after else None,'B_success_gap_around_exposure_ms':(after[0]['started_ns']-before[-1]['started_ns'])/1e6 if after and before else None,'A_acceptance_sample_interval_ms':(clear['timestamp_ns']-first_a['timestamp_ns'])/1e6 if first_a and clear else None,'first_B_after_A_relative_to_intervention_ms':(next_bp['started_ns']-out['intervention_ns'])/1e6 if next_bp else None,'A_acceptance_interval_right_censored':bool(first_a and not clear),'state_recovery_right_censored':out.get('state_recovery_censored',False),'handoff_right_censored':out.get('handoff_right_censored',False),'baseline_manual_replay':out.get('operator_baseline_revalidation',False)}

def duration_metrics(out,path):
    evidence=[json.loads(line) for line in (path/'evidence.jsonl').read_text().splitlines()]
    start=out['intervention_ns']; end=out['recovery_observation_end_ns']
    probes=sorted((e for e in evidence if e['type']=='probe'),key=lambda e:e['started_ns'])
    successes=[p for p in probes if p.get('status')==200 and p.get('service')=='AS-B']
    prior=[p for p in successes if p['started_ns']<start]
    relevant=([prior[-1]] if prior else [])+[p for p in successes if start<=p['started_ns']<=end]
    gaps=[(b['started_ns']-a['started_ns'])/1e6 for a,b in zip(relevant,relevant[1:])]
    observed=[p for p in probes if out['exposure_start_ns']<=p['started_ns']<out['exposure_end_ns']]
    probe_gaps=[(b['started_ns']-a['started_ns'])/1e6 for a,b in zip(observed,observed[1:])]
    transition=[p for p in probes if start<=p['started_ns']<out['exposure_start_ns']]
    ta=sum(p.get('status')==200 and p.get('service')=='AS-A' for p in transition)
    tb=sum(p.get('status')==200 and p.get('service')=='AS-B' for p in transition)
    restoration=[p for p in probes if out['recovery_requested_ns']<=p['started_ns']<=end]
    ra=sum(p.get('status')==200 and p.get('service')=='AS-A' for p in restoration)
    rb=sum(p.get('status')==200 and p.get('service')=='AS-B' for p in restoration)
    # Conservative sensitivity to any constant guest-minus-host offset in +/-250 ms.
    lower=out['exposure_start_ns'];upper=out['exposure_end_ns'];margin=250_000_000
    a_inner=any(lower+margin<=p['started_ns']<upper-margin and p.get('status')==200 and p.get('service')=='AS-A' for p in probes)
    a_expanded=any(lower-margin<=p['started_ns']<upper+margin and p.get('status')==200 and p.get('service')=='AS-A' for p in probes)
    a_nominal=any(p.get('status')==200 and p.get('service')=='AS-A' for p in observed)
    hold_snaps=[s for s in evidence if s['type']=='snapshot' and lower<=s['timestamp_ns']<upper]
    states=[s['state_by_prefix']['198.18.0.0/24'] for s in hold_snaps]
    first_a=next((p for p in probes if p['started_ns']>=start and p.get('status')==200 and p.get('service')=='AS-A'),None)
    def since(value,reference):return (value-reference)/1e6 if value is not None and reference is not None else None
    return {'max_observed_gap_between_successful_B_request_starts_ms':max(gaps) if gaps else None,
            'B_success_gap_right_censored':not any(p['started_ns']>=out['recovery_requested_ns'] for p in successes),
            'probe_start_gap_max_ms':max(probe_gaps) if probe_gaps else None,
            'probe_start_gap_p95_ms':float(np.percentile(probe_gaps,95)) if probe_gaps else None,
            'controller_to_exposure_start_ms':(out['exposure_start_ns']-start)/1e6,
            'activation_interval_A_responses':ta,'activation_interval_B_responses':tb,
            'activation_interval_other_outcomes':len(transition)-ta-tb,
            'restoration_interval_A_responses':ra,'restoration_interval_B_responses':rb,
            'restoration_interval_other_outcomes':len(restoration)-ra-rb,
            'A_presence_stable_under_250ms_phase_offset':a_inner if a_nominal else not a_expanded,
            'hold_vrp_origin_sets':json.dumps(sorted({tuple(s['installed_vrp_origins']) for s in states})),
            'hold_accepted_origin_sets':json.dumps(sorted({tuple(s['accepted_asns']) for s in states})),
            'hold_selected_fib_origins':json.dumps(sorted({s['selected_fib_as'] for s in states if s['selected_fib_as'] is not None})),
            'first_A_admission_after_intervention_ms':since(out.get('first_A_accept_ns'),start),
            'first_A_admission_after_verified_cut_ms':since(out.get('first_A_accept_ns'),out.get('cut_ns')),
            'first_A_successful_request_start_after_intervention_ms':since(first_a['started_ns'] if first_a else None,start),
            'first_backup_connection_after_intervention_ms':since(out.get('first_backup_connected_ns'),start),
            'primary_close_after_intervention_ms':since(out.get('cut_ns'),start),
            'observer_error_count':sum(e.get('event')=='observer_error' for e in evidence)}

def main():
    p=argparse.ArgumentParser();p.add_argument('batch',type=Path);p.add_argument('--output',type=Path);p.add_argument('--diagnostic',action='store_true');a=p.parse_args();batch=a.batch.resolve();manifest=json.loads((batch/'manifest.json').read_text());dest=a.output or batch/'analysis';dest.mkdir(parents=True,exist_ok=True)
    if not a.diagnostic and (manifest.get('pilot_suite') or manifest['completed']!=manifest['planned_trials']):raise RuntimeError('Submission analysis requires a complete non-pilot batch')
    rows=[];invalid=[];hashes=set();seen=set()
    for item in manifest['trials']:
        raw=batch.parent/item['case'];out=json.loads((raw/'outcome.json').read_text())
        if not out['scenario_valid']:invalid.append({'case':item['case'],'reason':out['invalid_reason']});continue
        if item['index'] in seen:continue
        seen.add(item['index']);hashes.add(json.dumps(out.get('source_sha256',{}),sort_keys=True));row=evidence_metrics(out,raw);row.update(duration_metrics(out,raw));rows.append(row)
    if not a.diagnostic and len(hashes)!=1:raise RuntimeError('Measurement runner changed within the submission batch')
    with (dest/'run_metrics.csv').open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    grouped=defaultdict(list)
    for r in rows:grouped[tuple(r[k] for k in FACTORS)].append(r)
    summary=[]
    for key,rs in sorted(grouped.items()):
        n=len(rs);k=sum(r['redirect_observed'] for r in rs);admitted=sum(r['A_admission_observed'] for r in rs)
        result={**dict(zip(FACTORS,key)),'runs':n,'runs_with_redirect':k,'runs_with_A_admission':admitted,'redirect_run_fraction':k/n,'binomial_95_interval':exact_interval(k,n),'A_responses':sum(r['A'] for r in rs),'B_responses':sum(r['B'] for r in rs),'other_outcomes':sum(r['other'] for r in rs),'mean_run_A_fraction':float(np.mean([r['A_fraction_of_attempts'] for r in rs])),'mean_run_B_fraction':float(np.mean([r['B_fraction_of_attempts'] for r in rs]))}
        handoffs=[r for r in rs if r['verified_backup_transfer_by_hold_end']]
        result['A_admission_run_fraction']=admitted/n
        result['A_admission_binomial_95_interval']=exact_interval(admitted,n)
        if result['scenario']=='natural-refresh':
            result['binomial_95_interval']=None;result['A_admission_binomial_95_interval']=None
            result['statistics_scope']='Single descriptive long-horizon observation; not an inferential replication cell'
        result['runs_with_verified_transfer_by_hold_end']=len(handoffs)
        result['redirect_runs_among_verified_transfers']=sum(r['redirect_observed'] for r in handoffs)
        result['restoration_interval_A_responses']=sum(r['restoration_interval_A_responses'] for r in rs)
        result['runs_with_A_during_restoration']=sum(r['restoration_interval_A_responses']>0 for r in rs)
        result['runs_with_stable_A_presence_under_250ms_phase_offset']=sum(r['A_presence_stable_under_250ms_phase_offset'] for r in rs)
        for metric in ['first_B_request_start_after_update_ms','B_success_gap_around_exposure_ms','max_observed_gap_between_successful_B_request_starts_ms','probe_start_gap_max_ms','controller_to_exposure_start_ms','A_acceptance_sample_interval_ms','preflight_cost_ms','backup_transfer_after_cut_ms','snapshot_gap_max_ms','first_A_admission_after_intervention_ms','first_A_admission_after_verified_cut_ms','first_A_successful_request_start_after_intervention_ms','first_backup_connection_after_intervention_ms','primary_close_after_intervention_ms']:
            v=[r[metric] for r in rs if r[metric] is not None];result[metric+'_range']=[min(v),max(v)] if v else None
        summary.append(result)
    report={'batch':batch.name,'diagnostic_only':a.diagnostic,'valid_runs':len(rows),'invalid_attempts':invalid,'groups':summary,'statistics_note':'Exact Clopper-Pearson run-level intervals assume independent Bernoulli laboratory replications. They do not estimate Internet prevalence. Requests are never independent trial replicates.','timing_note':'HTTP start and completion timestamps are distinct. Missing recovery and handoff events are right-censored, not zero latency.'}
    (dest/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'rpki-rtr-study-v1'})
    def save(fig,name):
        if a.diagnostic:fig.suptitle('DIAGNOSTIC — incomplete, not submission results',fontsize=9,color='#8b3f26')
        fig.savefig(dest/(name+'.pdf'),bbox_inches='tight',metadata={'CreationDate':None,'ModDate':None});fig.savefig(dest/(name+'.svg'),bbox_inches='tight',metadata={'Date':None});plt.close(fig)
    # Each point is a separate newly initialized run; never pool request counts into CIs.
    core=[r for r in rows if r['rp']=='routinator' and r['scenario'] in ['stale-backup','concurrent-inconsistent'] and r['mechanism']=='immediate' and r['router'] in ['patched','bird']]
    fig,ax=plt.subplots(figsize=(7.0,2.6));groups=[(ro,po) for ro in ['patched','bird'] for po in ['prefer-a','equal','prefer-b']]
    for i,(ro,po) in enumerate(groups):
        for scenario,shift,color,marker,label in [('stale-backup',-.11,'#b44432','x','Stale standby'),('concurrent-inconsistent',.11,'#17658b','o','Concurrent inconsistent sources')]:
            rs=[r for r in core if r['router']==ro and r['policy']==po and r['scenario']==scenario]
            for j,r in enumerate(rs):ax.scatter(i+shift+(j-(len(rs)-1)/2)*.045,100*r['A_fraction_of_attempts'],color=color,marker=marker,s=25,label=label if i==0 and j==0 else None)
    router_label={'patched':'FRR (patched)','bird':'BIRD'};policy_label={'prefer-a':'A preferred','equal':'Equal preference','prefer-b':'B preferred'}
    ax.set_xticks(range(6),[router_label[r]+'\n'+policy_label[p] for r,p in groups]);ax.set_ylim(-3,103);ax.set_ylabel('Requests reaching A (%)');ax.grid(axis='y',alpha=.2);ax.legend(loc='upper center',bbox_to_anchor=(.5,1.25),ncol=2,frameon=False);save(fig,'policy_effect')
    mitig=[r for r in rows if r['router'] in ['patched','bird'] and r['rp']=='routinator' and r['policy']=='prefer-a' and r['scenario']=='stale-backup']
    fig,ax=plt.subplots(figsize=(7.0,2.7));groups=[(ro,me) for ro in ['patched','bird'] for me in ['immediate','gate','fail-safe']]
    for i,(ro,me) in enumerate(groups):
        rs=[r for r in mitig if r['router']==ro and r['mechanism']==me]
        for j,r in enumerate(rs):
            x=i+(j-(len(rs)-1)/2)*.1;ax.scatter(x-.035,100*r['A_fraction_of_attempts'],color='#b44432',marker='x',s=26);ax.scatter(x+.035,100*r['B_fraction_of_attempts'],color='#147d6b',marker='o',facecolors='none',s=26)
    ax.scatter([],[],marker='x',color='#b44432',label='A responses');ax.scatter([],[],marker='o',facecolors='none',edgecolors='#147d6b',label='B responses');ax.legend(loc='upper center',bbox_to_anchor=(.5,1.25),ncol=2,frameon=False);ax.set_xticks(range(6),[router_label[r]+'\n'+{'immediate':'Immediate','gate':'Gate','fail-safe':'Deny'}[m] for r,m in groups]);ax.set_ylim(-3,103);ax.set_ylabel('Fraction of attempted requests (%)');ax.grid(axis='y',alpha=.2);save(fig,'mitigation_tradeoff')
    long_runs=[r for r in rows if r['scenario']=='natural-refresh']
    if long_runs:
        fig,ax=plt.subplots(figsize=(7.0,2.5))
        for i,row in enumerate(long_runs):
            raw=batch.parent/row['case'];out=json.loads((raw/'outcome.json').read_text())
            events=[json.loads(line) for line in (raw/'evidence.jsonl').read_text().splitlines()]
            probes=[p for p in events if p['type']=='probe' and out['intervention_ns']<=p['started_ns']<out['exposure_end_ns']]
            for service,color,marker in [('AS-A','#b44432','x'),('AS-B','#147d6b','o'),('Other','#555555','|')]:
                if service=='Other':selected=[p for p in probes if p.get('status')!=200 or p.get('service') not in ['AS-A','AS-B']]
                else:selected=[p for p in probes if p.get('status')==200 and p.get('service')==service]
                ax.scatter([(p['started_ns']-out['intervention_ns'])/1e9 for p in selected],[i]*len(selected),s=4,marker=marker,color=color,label=service if i==0 else None)
        ax.set_yticks(range(len(long_runs)),[router_label[r['router']] for r in long_runs]);ax.set_xlabel('Seconds after primary-stop request');ax.set_ylabel('Router deployment');ax.set_ylim(-.6,len(long_runs)-.4);ax.legend(loc='upper center',bbox_to_anchor=(.5,1.22),ncol=3,frameon=False);ax.grid(axis='x',alpha=.2);save(fig,'automatic_refresh')
    print(json.dumps({'analysis':str(dest),'valid_runs':len(rows),'groups':len(summary),'invalid_attempts':len(invalid),'diagnostic_only':a.diagnostic},indent=2))
if __name__=='__main__':main()
