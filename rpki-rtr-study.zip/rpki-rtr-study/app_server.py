import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from time import time_ns


SERVICE_ID = os.environ["SERVICE_ID"]


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = json.dumps(
            {"service": SERVICE_ID, "received_at_ns": time_ns()}
        ).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format, *_args):
        return


ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
