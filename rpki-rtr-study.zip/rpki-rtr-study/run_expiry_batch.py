"""Run three paired RTR-expiry observations on isolated Docker networks."""

import argparse
import csv
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LAB_FILES = (
    "compose.yaml", "Dockerfile", "run_lab.py", "client_agent.py",
    "rtr_server.py", "app_server.py", "frr/daemons", "frr/dut.conf",
    "frr/as-a.conf", "frr/as-b.conf",
)


def run_job(batch, index, scenario, replication, seconds, extra_route=None):
    variant = "" if extra_route is None else ("_two-prefixes" if extra_route else "_one-prefix")
    job = batch / f"{scenario}{variant}_{replication:02d}"
    project = f"rov-expiry-{batch.name.removeprefix('expiry-').lower()}-{index}"
    subnet_start = index * 16
    for name in LAB_FILES:
        content = (ROOT / name).read_text(encoding="utf-8")
        content = (
            content.replace("198.18.0.0/16", f"198.19.{subnet_start}.0/20")
            .replace("198.18.0.", f"198.19.{subnet_start}.")
            .replace("198.18.2.", f"198.19.{subnet_start + 2}.")
            .replace("rov-rtr-handoff", project)
        )
        if name == "frr/dut.conf":
            peer = f"198.19.{subnet_start + 2}.11"
            content = content.replace(
                f"neighbor {peer} route-map ROV-IN in",
                f"neighbor {peer} route-map ROV-PREFER-A in",
            )
            content += (
                "\nroute-map ROV-PREFER-A deny 10\n match rpki invalid\n"
                "route-map ROV-PREFER-A permit 20\n set local-preference 200\n"
            )
        if extra_route and name == "frr/as-b.conf":
            extra_prefix = f"198.19.{subnet_start + 1}.0/24"
            content = content.replace(
                "router bgp 65002", f"ip route {extra_prefix} Null0\n!\nrouter bgp 65002"
            ).replace(" exit-address-family", f"  network {extra_prefix}\n exit-address-family")
        destination = job / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content, encoding="utf-8", newline="\n")

    print(f"Started {job.name}", flush=True)
    with (job / "runner.log").open("w", encoding="utf-8") as log:
        proc = subprocess.run(
            [sys.executable, "-u", "run_lab.py", "--scenario", scenario,
             "--repetitions", "1", "--hold-seconds", str(seconds)],
            cwd=job, stdout=log, stderr=subprocess.STDOUT,
        )
    summary = next(job.glob("results/*/trial_summary.csv"), None)
    row = {}
    if summary:
        with summary.open(newline="", encoding="utf-8") as stream:
            row = next(csv.DictReader(stream))
    row.update(
        scenario=scenario, replication=replication, runner_exit=proc.returncode,
        source=str(summary.relative_to(batch)) if summary else "",
    )
    if extra_route is not None:
        row["prefixes"] = 2 if extra_route else 1
    print(f"Finished {job.name}: valid={row.get('scenario_valid', 'missing')}", flush=True)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=int, default=660)
    parser.add_argument("--compare-failure-modes", action="store_true",
                        help="compare closure and blackhole with one or two BGP prefixes")
    args = parser.parse_args()
    if args.seconds <= 600:
        parser.error("the observation must exceed the 600-second VRP expiry")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    batch = ROOT / "results" / f"expiry-{stamp}"
    batch.mkdir(parents=True, exist_ok=False)
    if args.compare_failure_modes:
        jobs = [
            (scenario, replication, extra_route)
            for replication in range(1, 3)
            for scenario in ("primary-expiry", "primary-blackhole")
            for extra_route in (False, True)
        ]
    else:
        jobs = [
            (scenario, replication, None)
            for replication in range(1, 4)
            for scenario in ("primary-expiry", "expiry-control")
        ]
    with ThreadPoolExecutor(max_workers=len(jobs)) as executor:
        futures = [
            executor.submit(run_job, batch, index, scenario, replication, args.seconds, extra_route)
            for index, (scenario, replication, extra_route) in enumerate(jobs)
        ]
        rows = [future.result() for future in futures]
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with (batch / "batch_summary.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(batch, flush=True)
    return 0 if all(row.get("scenario_valid") == "True" for row in rows) else 2


if __name__ == "__main__":
    sys.exit(main())
